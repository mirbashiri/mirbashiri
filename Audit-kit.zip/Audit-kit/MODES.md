# Modes — ready-made jobs (shortcuts)

Say to any agent: **"Use Audit-kit mode `<name>` on `<target>`."** The agent reads `modes/<name>.md` (a complete job description: inputs, steps, output format, done criteria) and needs nothing else from you.
The core stays fully manual: every mode is only `tools/*.js` + `audit.config.json` + a written procedure. You can ignore modes and run the tools yourself with your own settings.

| mode | job | target | output | changes your code? |
|---|---|---|---|---|
| `quick-scan` | small errors on ONE page: fonts, colours, spacing, radii, contrast, tap size, a11y | a page (file/URL) | `quick-scan.md` fix list with exact element, current value, expected value | no |
| `app-sweep` | the whole app: audit all pages, rank them, find cross-page inconsistency | start URL, folder, or list.txt | `sweep-out/app-audit.md` + `summary.md` | no |
| `layout-redesign` | audit the layout, build an improved version, prove it with numbers, deliver an edited page image | a page + its data | `before-after.png`, `after/index.html`, `redesign-report.md` | no (mockup) unless you say "apply" and give the source |
| `chart-review` | judge every chart: form, palette (validated), marks, interaction | a page with charts | `chart-review.md` | no |

## One-line prompts
- `Use Audit-kit mode quick-scan on https://app/trades.`
- `Use Audit-kit mode app-sweep on https://app (depth 2, exclude /admin).`
- `Use Audit-kit mode layout-redesign on ./pages/analytics.html with data ./data.json.`
- `Use Audit-kit mode chart-review on ./pages/dashboard.html.`

## Setting things by hand (manual use of the core)
- Thresholds, themes, tokens file, spacing grid: `audit.config.json` (or `--config my.json`).
- Single page: `node tools/audit.js <page> [--mode name] --out DIR`
- Many pages: `node tools/sweep.js <url|folder|list.txt> --out DIR [--exclude REGEX]`
- One screenshot: `node tools/shot.js <page> out.png --theme dark --full` · before/after image: `node tools/compare.js before.png after.png out.png`
- Palette check: `node tools/validate_palette.mjs "#hex,#hex" --mode dark --surface "#hex"`

## Adding your own mode
Copy `modes/quick-scan.md` → `modes/<name>.md`, change goal/steps/output. Optional `modes/<name>.json` with `{"config": {...}}` overrides `audit.config.json` when run with `--mode <name>`.

## Not built (ideas, derived from past work)
Theme variants (propose N themes and render them on the page), handoff prompt writer (build prompt + palette for another agent), skill A/B test (same task with and without a skill, shared metrics), RTL/Persian check as its own mode, interaction test (swipe/keyboard scripts). Say if you want any.
