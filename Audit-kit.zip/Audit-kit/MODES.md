# Modes — ready-made jobs (shortcuts)

Tell any agent: **"Use Audit-kit mode `<name>` on `<target>`. Folder: `<path>`."** The agent runs the command below and follows the generated `RUNBOOK.md`; you never re-explain the job.
Every mode = one JSON file in `modes/` (inputs, automatic steps, steps, checklist, deliverables, limits, skills to read). The core is still fully manual: ignore `kit.js` and call `tools/*.js` with your own settings and `audit.config.json`.

## The command (same for every mode)
```
node tools/kit.js list                                  # all modes
node tools/kit.js show <mode>                           # full job description + checklist
node tools/kit.js run <mode> <target> [--out DIR] [--arg key=value ...]      # automatic steps on the target -> DIR/RUNBOOK.md
node tools/kit.js verify <mode> <built-file> [--out DIR] [--arg key=value ...]   # verification of what was built
```
`RUNBOOK.md` = results of the automatic steps (status per step, report excerpts) + the mode's remaining steps and checklist (`- [ ]` items) + deliverables + limits. A step with status **ISSUES FOUND** means the check ran and found problems (read its log); **FAILED** means the tool itself broke.

## 22 modes in 5 groups
| mode | group | job | inputs | auto steps | deliverables |
|---|---|---|---|---|---|
| `quick-scan` | 1 Audit (read-only) | Find small concrete defects on ONE page: font sizes/families, off-token colours, contrast, spacing grid, radii, tap size, a11y basics. | target, RULES.md / tokensFile | 2 | quick-scan.md: fix list table (category | where | now | should be | confidence | effort); audit/report.md + PNGs |
| `app-sweep` | 1 Audit (read-only) | Audit all pages of an app, rank them, and find problems shared across pages (drifting fonts/radii/colours, repeated defects). | target, --arg exclude=REGEX | 1 | app-audit.md (worst first | shared problems | page ranking | per-page top 3 | not verified); sweep/summary.md + per-page reports |
| `chart-review` | 1 Audit (read-only) | Judge every chart on a page: right form for the question, validated palette, mark specs, labels, tooltip/keyboard/table twin. | target | 3 | chart-review.md; audit/report.md, validator output |
| `rtl-check` | 1 Audit (read-only) | Find bidi, direction, spacing, digit and font problems in RTL text. | target | 2 | rtl-check.md; rtl/rtl.png |
| `interaction-test` | 1 Audit (read-only) | Audit buttons, links, toggles, inputs: keyboard reachability, tab order, focus indicator, hover feedback, state screenshots. | target | 1 | interaction-test.md; interact/report.md, states-sheet.png |
| `mobile-check` | 1 Audit (read-only) | Find what makes a web page feel like a website on a phone: zoom lock, inputs under 16px, 100vh, ungated :hover, safe-area, missing viewport meta. | target | 2 | mobile-check.md; mobile/report.md, mobile.png |
| `motion-review` | 1 Audit (read-only) | List everything that animates and check it against measurable motion rules: transition:all, layout properties, ease-in, >300ms, scale(0), reduced-motion, ungated hover. | target | 2 | motion-review.md (Before | After | Why table + verdict); motion/report.md |
| `break-test` | 1 Audit (read-only) | Feed the page realistic worst-case data (long names, odd emails, 0/1/1,000 items, huge numbers, missing fields) and list what breaks versus the demo data. | target, data, hook | 3 | break-test.md (Part 1 / Part 2 / Part 3); data/*.json + manifest.md (the regression fixture: keep it) |
| `polish-check` | 1 Audit (read-only) | Measure the typographic and generic-AI tells a redesign pass looks for (tabular numbers, line length, orphans, cliche/placeholder copy, dead # links, wrapped CTAs) and whether an agent's output is visibly cut short. | target | 2 | polish-check.md; audit/report.md, completeness output |
| `layout-redesign` | 2 Build / redesign | Audit a page's layout, build an improved separate version with the same data, prove with metrics it is not worse, deliver a before/after image. | target, data, --arg built=path | 6 | before-after-dark.png (+light/mobile); after/index.html (mockup unless user said apply + gave source) |
| `site-build` | 2 Build / redesign | Design and build a new page or small site (landing, marketing, docs page) from a brief, then verify on all themes and widths. | target, --arg built=path | 4 | site/index.html; desktop.png, mobile.png |
| `theme-variants` | 2 Build / redesign | Create several colour themes (as CSS variable sets), render the same page in each, measure contrast, deliver a contact sheet. | target, --arg themes=themes.json | 1 | themes/sheet.png; themes/summary.md |
| `controls-review` | 2 Build / redesign | Review reusable controls: every state (default/hover/focus/active/disabled/loading/error), size, label clarity, consistency of the set. | target | 2 | controls-review.md; interact/states-sheet.png |
| `prototype-variants` | 2 Build / redesign | Build 2-5 genuinely different versions of one UI piece, put them behind a flat one-at-a-time switcher, and compare their measurements; the choice stays with the user. | target, built | 2 | variants.json, one HTML file per variant; variants/picker.html, variants.md, sheet.png |
| `poster` | 3 Static graphics | Design a poster or single visual from a message and brand, render to exact pixel size, verify text size/contrast/overlap. | target, --arg built=path, --arg w=1080 --arg h=1350 | 2 | poster.png (@2x); poster.html |
| `infographic` | 3 Static graphics | Turn facts into an infographic or data graphic: structure first, then chart forms, then style; verify labels and numbers against the source. | target, --arg built=path, --arg w=1200 --arg h=1600 | 4 | infographic.png (@2x); infographic.html |
| `diagram` | 3 Static graphics | Draw a diagram that shows the real mechanism, with bidi-safe labels; verify no overlaps. | target, --arg built=path, --arg w=1400 --arg h=900 | 3 | diagram.svg/html; diagram.png (@2x) |
| `deck` | 3 Static graphics | Build or review an HTML slide deck; render every slide, check per-slide text size/overflow, deliver a contact sheet. | target, --arg next=ArrowRight|ArrowLeft | 1 | slides/*.png, slides/sheet.png; deck-report.md |
| `generative-art` | 3 Static graphics | Create seeded generative art (canvas/SVG), render several seeds, check reproducibility and legibility. | target, --arg built=path | 5 | sketch.html; seed renders + sheet.png |
| `brand-kit` | 4 Brand & handoff | Validate and document a brand palette: contrast matrix, tokens CSS, pairing rules; for logos, verify on light/dark tiles. | target, --arg surface=#hex, --arg series=#hex,#hex | 4 | brand-kit.md (roles, pairings, matrix); tokens.css (from css step) |
| `handoff-writer` | 4 Brand & handoff | Write a self-contained build/redesign prompt (goal, reading list, spec, acceptance criteria, open decisions) plus palette/tokens so an agent without your context can do the work. | target, --arg palette=palette.json | 2 | PROMPT.md; palette.json + tokens.css |
| `skill-ab` | 5 Meta | Evidence for 'skill X is better': same brief and data, one build without the skill and one with it, compared on shared metrics. | target, --arg a=path, --arg b=path | 3 | compare table; ab-notes.md in the style of examples/example-ab-test.md |

## Exact commands (copy/paste)
| mode | command |
|---|---|
| quick-scan | `node tools/kit.js run quick-scan <page> --out out/qs` |
| app-sweep | `node tools/kit.js run app-sweep <url\|folder\|list.txt> --arg exclude='template\|partial' --out out/sweep` |
| chart-review | `node tools/kit.js run chart-review <page> --out out/charts` |
| rtl-check | `node tools/kit.js run rtl-check <page> --out out/rtl` |
| interaction-test | `node tools/kit.js run interaction-test <page> --out out/ix` |
| layout-redesign | `node tools/kit.js run layout-redesign <page> --out out/lr` → build `out/lr/after/index.html` → `node tools/kit.js verify layout-redesign out/lr/after/index.html --arg run=out/lr --out out/lr/verify` |
| site-build | write brief + page → `node tools/kit.js verify site-build <built.html> --out out/site` |
| theme-variants | `node tools/kit.js run theme-variants <page> --arg themes=<themes.json> --out out/themes` |
| mobile-check | `node tools/kit.js run mobile-check <page> --out out/mobile` |
| motion-review | `node tools/kit.js run motion-review <page> --out out/motion` |
| break-test | `node tools/kit.js run break-test <page> --arg data=<fixture.json> --out out/break` (page reads `window.__AK_DATA__`; without `--arg data` only the text run executes) |
| polish-check | `node tools/kit.js run polish-check <page> --out out/polish` |
| controls-review | `node tools/kit.js run controls-review <page> --out out/controls` |
| prototype-variants | build variants + `variants.json` → `node tools/kit.js verify prototype-variants <variants.json> --out out/variants` |
| poster | build → `node tools/kit.js verify poster <poster.html> --arg w=1080 --arg h=1350 --out out/poster` |
| infographic | build → `node tools/kit.js verify infographic <file.html> --arg w=1200 --arg h=1600 --out out/info` |
| diagram | build → `node tools/kit.js verify diagram <file.html\|svg> --arg w=1400 --arg h=900 --out out/diagram` |
| deck | `node tools/kit.js run deck <deck.html> [--arg next=ArrowLeft] --out out/deck` |
| generative-art | build → `node tools/kit.js verify generative-art <sketch.html> --out out/art` |
| brand-kit | `node tools/kit.js run brand-kit <palette.json> --arg series=#hex,#hex --arg surface=#hex --out out/brand` |
| handoff-writer | `node tools/kit.js run handoff-writer <reference-page> --arg palette=<palette.json> --out out/handoff` |
| skill-ab | build A and B → `node tools/kit.js verify skill-ab <A.html> --arg a=<A.html> --arg b=<B.html> --out out/ab` |

## Which modes only audit, which build
- **Read-only audits:** quick-scan, app-sweep, chart-review, rtl-check, interaction-test, mobile-check, motion-review, break-test, polish-check, controls-review. They change nothing (break-test only injects data into a throw-away render).
- **Builds (a separate new file, original untouched):** layout-redesign, site-build, theme-variants, prototype-variants, poster, infographic, diagram, deck (build/review), generative-art, brand-kit, handoff-writer. For these the agent does the creative work following the mode steps; the kit supplies the render, measurement, comparison and checklist.
- **Meta:** skill-ab.

## Adding your own mode
Copy any `modes/<name>.json`, edit; `node tools/kit.js list` picks it up. Fields: `name, group, order, title, summary, inputs[], skills[], defaults{}, auto[], steps[], verify[], checklist[], deliverables[], limits[]`; commands may use `{target} {built} {out} {kit}` and any `--arg key=value`. `check:true` on a step marks "exit 1 = issues found".
`modes/<name>.json` may also hold `"config": {...}` overrides for `audit.config.json` used with `audit.js --mode <name>`.
