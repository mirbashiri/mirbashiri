# Prompt — paste to any agent

**Shortcut form (preferred):**
> Use Audit-kit mode `<quick-scan | app-sweep | layout-redesign | chart-review>` on `<target>`. Folder: `<path to Audit-kit>`.

Then the agent must: read `README.md`, `MODES.md`, `RULES.md`, `modes/<mode>.md` and follow that mode exactly (inputs → steps → output format → done criteria).

**Free-form (custom job):** read `README.md`, `RULES.md`, `AUDIT-CHECKLIST.md`; run `sh tools/selftest.sh`; use `tools/audit.js`, `tools/sweep.js`, `tools/validate_palette.mjs`, `tools/check-labels.js`, `tools/shot.js`, `tools/compare.js` as needed; write the result with `AUDIT-TEMPLATE.md`.

**Always:**
- Measure first, judge second; look at every screenshot you cite.
- Tag claims [certain]/[likely]/[guess]; unpleasant finding first; end with "Not verified".
- Audit-only unless the mode says it builds something (layout-redesign builds a *separate* page). Never overwrite the original; never change brand colours/logos unless asked.
- If a tool cannot run, say which and do not invent numbers.
