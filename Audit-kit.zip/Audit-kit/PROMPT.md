# Prompt — paste to any agent

**Shortcut form (preferred):**
> Use Audit-kit mode `<name>` on `<target>`. Folder: `<path to Audit-kit>`.
> Names: quick-scan, app-sweep, chart-review, rtl-check, interaction-test, layout-redesign, site-build, theme-variants, controls-review, poster, infographic, diagram, deck, generative-art, brand-kit, handoff-writer, skill-ab.

Then the agent must: read `README.md`, `MODES.md`, `RULES.md`; run `node tools/kit.js show <mode>` and `node tools/kit.js run <mode> <target> --out <dir>` (or `verify` after building); then follow the generated `RUNBOOK.md` exactly: every checklist item answered, deliverables produced, limits stated.

**Free-form (custom job):** read `README.md`, `RULES.md`, `AUDIT-CHECKLIST.md`; run `sh tools/selftest.sh`; use `tools/audit.js`, `tools/sweep.js`, `tools/validate_palette.mjs`, `tools/check-labels.js`, `tools/shot.js`, `tools/compare.js` as needed; write the result with `AUDIT-TEMPLATE.md`.

**Editing the kit itself? Read `IRON-RULES.md` first** (every committed edit adds 0.01 to the version: `node tools/bump-version.js --note "..."`; selftest must be ALL OK).

**Always:**
- Measure first, judge second; look at every screenshot you cite.
- Tag claims [certain]/[likely]/[guess]; unpleasant finding first; end with "Not verified".
- Audit-only unless the mode says it builds something (layout-redesign builds a *separate* page). Never overwrite the original; never change brand colours/logos unless asked.
- If a tool cannot run, say which and do not invent numbers.
