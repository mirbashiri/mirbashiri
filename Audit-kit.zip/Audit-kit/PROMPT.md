# Prompt — paste this to any agent

You are auditing an app's pages for quality. The folder `Audit-kit/` is everything you need for the method; do not rely on outside material. Read `README.md`, `RULES.md` and `AUDIT-CHECKLIST.md` first.

**Pages to audit:** <list files / URLs / screenshots>
**Context:** <real app or static copy · themes · language/direction · real or sample data>

Do exactly this:
1. Capture + measure: `NODE_PATH=$(npm root -g) node tools/audit.js <pages> --out audit-out` (edit `audit.config.json` thresholds first if the app differs from the defaults). Look at every PNG.
2. Run mechanical checks M1–M11 from `AUDIT-CHECKLIST.md`. For chart colours run `tools/validate_palette.js` on the colours audit.js prints, per theme.
3. Do the judgement checks using `references/` and the app's `RULES.md`. If `RULES.md` is unfilled, use generic best practice and say so.
4. Write the audit with `AUDIT-TEMPLATE.md` → `audit-out/audit.md`. Unpleasant finding first. Tag every claim [certain]/[likely]/[guess]. End with "Not verified".
5. Audit only. Do not change code, brand colours or logos unless asked.
6. If a tool cannot run (no network, no browser), say which; never invent measurements.
