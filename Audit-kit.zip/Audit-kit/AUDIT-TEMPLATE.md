# Audit — <page name> — <date>

**Scope:** pages/URLs/screens audited · real app or static copy? · themes + widths checked · data real or sample?
**Method:** `tools/audit.js` + `validate_palette.js` (+ `check-labels.js` if SVG labels) + screenshots viewed. Rules used: `RULES.md` (filled / unfilled → generic). Confidence tags: [certain] [likely] [guess].

## 0. The unpleasant truth first
One to three sentences: the worst problem, stated plainly.

## 1. Measured results (paste from report.md)
| check | result | pass? |
|---|---|---|
| Smallest text (px) | | |
| Low-contrast texts (dark / light) | | |
| Style-rule violations (flat etc., if defined) | | |
| Horizontal scroll @390 | | |
| Tap targets < 24px | | |
| a11y basics | | |
| Chart palette validation (dark / light) | | |
| RTL/Persian (if any) | | |
| Page errors | | |

## 2. Findings (highest impact first)
| # | Finding | Evidence | Confidence | Fix | Risk of the fix |
|---|---|---|---|---|---|
| 1 | | | | | |

## 3. Per-page table (when auditing several pages)
| page | top 3 problems | one-line redesign direction |
|---|---|---|

## 4. Not verified
- 

## 5. Recommended order of work
1. 
