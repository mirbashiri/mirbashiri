# CHANGES vs original kit (/home/user/synek/Audit-kit)

Computed with `diff -rq /home/user/synek/Audit-kit /tmp/ak-int/Audit-kit`. The original was not touched.

## Added (21 paths; directories listed once)
- Audit-kit/docs/skills-integration.md
- Audit-kit/examples/break-demo-bad.html
- Audit-kit/examples/break-demo-good.html
- Audit-kit/examples/break-demo.json
- Audit-kit/examples/checks-bad.html
- Audit-kit/examples/checks-good.html
- Audit-kit/examples/variants
- Audit-kit/modes/break-test.json
- Audit-kit/modes/mobile-check.json
- Audit-kit/modes/motion-review.json
- Audit-kit/modes/polish-check.json
- Audit-kit/modes/prototype-variants.json
- Audit-kit/references/skills/11-emilkowalski
- Audit-kit/references/skills/12-taste-skill
- Audit-kit/tools/break-data.js
- Audit-kit/tools/completeness.js
- Audit-kit/tools/lib
- Audit-kit/tools/mobile-check.js
- Audit-kit/tools/motion-check.js
- Audit-kit/tools/variants.js
- Audit-kit/tools/worst-case.js
  - `Audit-kit/references/skills/11-emilkowalski/` contains: LICENSE, SOURCE.md, performance-cheatsheet.md, and the skill folders break-ui, mobile-native, review-animations, improve-animations, find-animation-opportunities, emil-design-eng, prototype (text only)
  - `Audit-kit/references/skills/12-taste-skill/` contains: LICENSE, SOURCE.md, redesign-skill, output-skill (+ research-laziness/), taste-skill, minimalist-skill, brutalist-skill (text only)
  - `Audit-kit/tools/lib/` contains: checks.js, run-checks.js
  - `Audit-kit/examples/variants/` contains: toast-quiet.html, toast-editorial.html, toast-playful.html, toast-quiet-teal.html, variants.json, variants-bad.json, variants-converged.json

## Changed (26 files)
- `Audit-kit/AUDIT-CHECKLIST.md`
- `Audit-kit/MODES.md` : index regenerated (22 modes), command table + groups synced
- `Audit-kit/README.md`
- `Audit-kit/audit.config.json` : new keys staticChecks, minInputPx, maxUiMotionMs, maxMeasureCh, copyBanned, banEmDash
- `Audit-kit/docs/README.md`
- `Audit-kit/docs/configuration.md`
- `Audit-kit/docs/evidence.md`
- `Audit-kit/docs/getting-started.md`
- `Audit-kit/docs/limits-and-faq.md`
- `Audit-kit/docs/modes.md` : title 22 modes; 5 new mode sections with real-run examples
- `Audit-kit/docs/tools.md`
- `Audit-kit/modes/brand-kit.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/controls-review.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/deck.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/diagram.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/generative-art.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/handoff-writer.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/infographic.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/layout-redesign.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/poster.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/site-build.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/skill-ab.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/modes/theme-variants.json` : only the `order` number (renumbered so the 22 modes list coherently)
- `Audit-kit/references/skills/README.md` : rewritten for 12 packs
- `Audit-kit/tools/audit.js` : static-check rows, `checks.*` in report.json, new --fail-on keys, new config defaults (additive; existing metrics unchanged)
- `Audit-kit/tools/selftest.sh` : steps 5-8 added; sweep step excludes the new fixtures

Not changed (follow-up): `docs/index.html` still says 17 modes (lines 103, 136, 172, 179, 192, 197); see docs/skills-integration.md.

## Commands run and results
Environment: `export NODE_PATH=$(npm root -g)`, run from `/tmp/ak-int/Audit-kit`. Outputs are in `/tmp/ak-int/runs/<mode>/<target>/`.

### kit.js runs (log: /tmp/ak-int/runs/commands.log)
```
$ node tools/kit.js run mobile-check examples/checks-good.html --out /tmp/ak-int/runs/mobile-check/good
[mobile-check] mobile: phone emulation (390x844, touch): viewport meta, input font size, 100vh, :hover gating, safe area, layout width, tap size ... ok (1.2s)
[mobile-check] audit: standard audit incl. mobile viewport, tap targets, horizontal scroll ... ok (2.6s)

RUNBOOK: /tmp/ak-int/runs/mobile-check/good/RUNBOOK.md  (2 ok, 0 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run mobile-check /tmp/flaw.html --out /tmp/ak-int/runs/mobile-check/flaw
[mobile-check] mobile: phone emulation (390x844, touch): viewport meta, input font size, 100vh, :hover gating, safe area, layout width, tap size ... ISSUES FOUND (see runs/mobile-check/flaw/log/mobile.txt)
[mobile-check] audit: standard audit incl. mobile viewport, tap targets, horizontal scroll ... ok (2.3s)

RUNBOOK: /tmp/ak-int/runs/mobile-check/flaw/RUNBOOK.md  (1 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run mobile-check examples/checks-bad.html --out /tmp/ak-int/runs/mobile-check/bad
[mobile-check] mobile: phone emulation (390x844, touch): viewport meta, input font size, 100vh, :hover gating, safe area, layout width, tap size ... ISSUES FOUND (see runs/mobile-check/bad/log/mobile.txt)
[mobile-check] audit: standard audit incl. mobile viewport, tap targets, horizontal scroll ... ok (2.4s)

RUNBOOK: /tmp/ak-int/runs/mobile-check/bad/RUNBOOK.md  (1 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run mobile-check /tmp/ak-int/targets/13-dashboard-redesign/c-refined/index.html --out /tmp/ak-int/runs/mobile-check/dashboard
[mobile-check] mobile: phone emulation (390x844, touch): viewport meta, input font size, 100vh, :hover gating, safe area, layout width, tap size ... ISSUES FOUND (see runs/mobile-check/dashboard/log/mobile.txt)
[mobile-check] audit: standard audit incl. mobile viewport, tap targets, horizontal scroll ... ok (2.8s)

RUNBOOK: /tmp/ak-int/runs/mobile-check/dashboard/RUNBOOK.md  (1 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run mobile-check /tmp/ak-int/targets/05-frontend-design-landing/index.html --out /tmp/ak-int/runs/mobile-check/landing
[mobile-check] mobile: phone emulation (390x844, touch): viewport meta, input font size, 100vh, :hover gating, safe area, layout width, tap size ... ISSUES FOUND (see runs/mobile-check/landing/log/mobile.txt)
[mobile-check] audit: standard audit incl. mobile viewport, tap targets, horizontal scroll ... ok (3.8s)

RUNBOOK: /tmp/ak-int/runs/mobile-check/landing/RUNBOOK.md  (1 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run motion-review examples/checks-good.html --out /tmp/ak-int/runs/motion-review/good
[motion-review] motion: static CSSOM rules + observed hover transitions + a second render with prefers-reduced-motion: reduce ... ok (2.5s)

RUNBOOK: /tmp/ak-int/runs/motion-review/good/RUNBOOK.md  (1 ok, 0 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run motion-review examples/checks-bad.html --out /tmp/ak-int/runs/motion-review/bad
[motion-review] motion: static CSSOM rules + observed hover transitions + a second render with prefers-reduced-motion: reduce ... ISSUES FOUND (see runs/motion-review/bad/log/motion.txt)

RUNBOOK: /tmp/ak-int/runs/motion-review/bad/RUNBOOK.md  (0 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run motion-review /tmp/ak-int/targets/05-frontend-design-landing/index.html --out /tmp/ak-int/runs/motion-review/landing
[motion-review] motion: static CSSOM rules + observed hover transitions + a second render with prefers-reduced-motion: reduce ... ISSUES FOUND (see runs/motion-review/landing/log/motion.txt)

RUNBOOK: /tmp/ak-int/runs/motion-review/landing/RUNBOOK.md  (0 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run motion-review /tmp/ak-int/targets/15-positions-carousel/index.html --out /tmp/ak-int/runs/motion-review/carousel
[motion-review] motion: static CSSOM rules + observed hover transitions + a second render with prefers-reduced-motion: reduce ... ok (2.1s)

RUNBOOK: /tmp/ak-int/runs/motion-review/carousel/RUNBOOK.md  (1 ok, 0 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run break-test examples/break-demo-bad.html --arg data=examples/break-demo.json --out /tmp/ak-int/runs/break-test/bad
[break-test] data: generate worst/empty/one/huge fixtures + manifest from the demo fixture ... ok (0.1s)
[break-test] hook: render the page with each fixture through window.__AK_DATA__ at 1440/720/320px and diff against demo ... ISSUES FOUND (see runs/break-test/bad/log/hook.txt)
[break-test] text: no fixture needed: rewrite visible text to worst-case shapes (heuristic) and clone/remove list rows ... ISSUES FOUND (see runs/break-test/bad/log/text.txt)

RUNBOOK: /tmp/ak-int/runs/break-test/bad/RUNBOOK.md  (1 ok, 2 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run break-test examples/break-demo-good.html --arg data=examples/break-demo.json --out /tmp/ak-int/runs/break-test/good
[break-test] data: generate worst/empty/one/huge fixtures + manifest from the demo fixture ... ok (0.1s)
[break-test] hook: render the page with each fixture through window.__AK_DATA__ at 1440/720/320px and diff against demo ... ok (19.7s)
[break-test] text: no fixture needed: rewrite visible text to worst-case shapes (heuristic) and clone/remove list rows ... ISSUES FOUND (see runs/break-test/good/log/text.txt)

RUNBOOK: /tmp/ak-int/runs/break-test/good/RUNBOOK.md  (2 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run break-test /tmp/ak-int/targets/13-dashboard-redesign/c-refined/index.html --arg data=/tmp/ak-int/targets/13-dashboard-redesign/data.json --out /tmp/ak-int/runs/break-test/dashboard
[break-test] data: generate worst/empty/one/huge fixtures + manifest from the demo fixture ... ok (0.1s)
[break-test] hook: render the page with each fixture through window.__AK_DATA__ at 1440/720/320px and diff against demo ... FAILED (see runs/break-test/dashboard/log/hook.txt)
[break-test] text: no fixture needed: rewrite visible text to worst-case shapes (heuristic) and clone/remove list rows ... ISSUES FOUND (see runs/break-test/dashboard/log/text.txt)

RUNBOOK: /tmp/ak-int/runs/break-test/dashboard/RUNBOOK.md  (1 ok, 1 with issues found (the check ran; read the log), 1 failed (tool error), 0 skipped)

$ node tools/kit.js run polish-check examples/checks-good.html --out /tmp/ak-int/runs/polish-check/good
[polish-check] audit: audit with the typography and copy rows; exit 1 if either has findings ... ok (2.5s)
[polish-check] completeness: placeholder/truncation patterns and structural truncation in the source file ... ok (0.1s)

RUNBOOK: /tmp/ak-int/runs/polish-check/good/RUNBOOK.md  (2 ok, 0 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run polish-check examples/checks-bad.html --out /tmp/ak-int/runs/polish-check/bad
[polish-check] audit: audit with the typography and copy rows; exit 1 if either has findings ... ISSUES FOUND (see runs/polish-check/bad/log/audit.txt)
[polish-check] completeness: placeholder/truncation patterns and structural truncation in the source file ... ok (0.1s)

RUNBOOK: /tmp/ak-int/runs/polish-check/bad/RUNBOOK.md  (1 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run polish-check /tmp/ak-int/targets/21-fresh-agent-site-build/index.html --out /tmp/ak-int/runs/polish-check/site-build
[polish-check] audit: audit with the typography and copy rows; exit 1 if either has findings ... ISSUES FOUND (see runs/polish-check/site-build/log/audit.txt)
[polish-check] completeness: placeholder/truncation patterns and structural truncation in the source file ... ok (0.1s)

RUNBOOK: /tmp/ak-int/runs/polish-check/site-build/RUNBOOK.md  (1 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run polish-check /tmp/ak-int/targets/16-pages-redesign/analytics/index.html --out /tmp/ak-int/runs/polish-check/analytics
[polish-check] audit: audit with the typography and copy rows; exit 1 if either has findings ... ISSUES FOUND (see runs/polish-check/analytics/log/audit.txt)
[polish-check] completeness: placeholder/truncation patterns and structural truncation in the source file ... ok (0.1s)

RUNBOOK: /tmp/ak-int/runs/polish-check/analytics/RUNBOOK.md  (1 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js verify prototype-variants examples/variants/variants.json --out /tmp/ak-int/runs/prototype-variants/good
[prototype-variants] variants: validate the set, build and test the picker, measure each variant, check divergence ... ok (14.5s)

RUNBOOK: /tmp/ak-int/runs/prototype-variants/good/RUNBOOK.md  (1 ok, 0 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js verify prototype-variants examples/variants/variants-converged.json --out /tmp/ak-int/runs/prototype-variants/converged
[prototype-variants] variants: validate the set, build and test the picker, measure each variant, check divergence ... ok (10.6s)

RUNBOOK: /tmp/ak-int/runs/prototype-variants/converged/RUNBOOK.md  (1 ok, 0 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js verify prototype-variants examples/variants/variants-bad.json --out /tmp/ak-int/runs/prototype-variants/bad
[prototype-variants] variants: validate the set, build and test the picker, measure each variant, check divergence ... ISSUES FOUND (see runs/prototype-variants/bad/log/variants.txt)

RUNBOOK: /tmp/ak-int/runs/prototype-variants/bad/RUNBOOK.md  (0 ok, 1 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

$ node tools/kit.js run prototype-variants /tmp/ak-int/targets/13-dashboard-redesign/c-refined/index.html --out /tmp/ak-int/runs/prototype-variants/run
[prototype-variants] baseline: measure the current UI (tokens, fonts, spacing) the variants must stand on ... ok (2.9s)

RUNBOOK: /tmp/ak-int/runs/prototype-variants/run/RUNBOOK.md  (1 ok, 0 with issues found (the check ran; read the log), 0 failed (tool error), 0 skipped)

```

Mode / target legend: mobile-check {good,bad}=examples/checks-{good,bad}.html, flaw=/tmp/flaw.html, dashboard=targets/13-dashboard-redesign/c-refined, landing=targets/05; motion-review {good,bad,landing,carousel(15)}; break-test {bad,good}=examples/break-demo-*.html with examples/break-demo.json, dashboard=13 c-refined with its data.json (hook step FAILED = exit 2, page never reads window.__AK_DATA__: expected); polish-check {good,bad,site-build(21),analytics(16)}; prototype-variants verify {good,converged,bad}=examples/variants/variants*.json (bad = INVALID set, exit 1 as intended; converged exits 0 with a convergence note).

### Other commands (selected) and results
- `node tools/audit.js examples/checks-bad.html --no-mobile --fail-on mobile,motion,typography,copy` -> exit 1; mobile=7, motion=11, typography=8, copy=7 per theme.
- `node tools/audit.js examples/checks-good.html --no-mobile --fail-on mobile,hoverGate,motion,reducedMotion,typography,copy` -> exit 0.
- `node tools/mobile-check.js` bad/clean -> 1/0; no-viewport page -> 3 ISSUE rows (layout 980px vs 390px).
- `node tools/motion-check.js` bad/clean -> 1/0 (9 of 9 rules vs 0 of 9).
- `node tools/completeness.js` on a truncated html -> exit 1 (6 findings); on checks-good.html -> 0.
- `node tools/break-data.js examples/break-demo.json --out DIR --rows 8`; `node tools/worst-case.js examples/break-demo-bad.html --fixtures DIR --out DIR2` -> exit 1 (3 Broken, 4 Ugly, 2 Fragile); `... break-demo-good.html` -> exit 0 (Fragile DOM-size only); against a page that never reads the hook -> exit 2 "HOOK NOT USED".
- `node tools/worst-case.js targets/13-dashboard-redesign/c-refined/index.html --how text --states worst` -> exit 1 (2 Broken, 4 Ugly).
- `node tools/variants.js examples/variants/variants.json --out DIR` -> exit 0, picker 6 ok / 0 failed; `variants-converged.json` -> convergence flagged; `variants-bad.json` -> exit 1 invalid.
- `node tools/audit.js` (static rows) on targets 05, 13 c-refined, 15, 16 analytics, 21 -> used to find and fix the false positives listed in docs/skills-integration.md.
- `node tools/kit.js list` -> 22 modes, 5 groups.
- `sh tools/selftest.sh` -> steps 1-8 OK, final line `ALL OK` (log: /tmp/ak-int/runs/selftest.log).
- `node tools/kit.js index` -> pasted into MODES.md.

## Not verified
See the "Not verified" section of Audit-kit/docs/skills-integration.md (real phones, motion feel, hook on a real app, route method, RTL worst case, fresh agents, upstream commit hashes, external stylesheet fallback, index.html not edited).
