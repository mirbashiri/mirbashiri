# Limits & FAQ

## What it cannot do
- Judge hierarchy, taste, or what a colour *means*. The checklist makes the agent justify these from screenshots; a weak agent can still be shallow.
- Click, submit forms, swipe, use a screen reader or real touch. It reports what it did not exercise.
- Contrast on text over images or semi-transparent layers (computed colours on solid backgrounds only).
- Log in. Give it a list or folder of saved pages for protected screens.
- Redesign or change your code: audit modes are read-only; build modes create a **separate** new file and never overwrite the original.
- Guarantee the quality of a build: it catches measurable defects.

## New checks (mobile, motion, typography, copy, worst-case data): what they cannot do
- They read CSS and the rendered DOM; they do not reproduce sticky hover, tap delay, rubber-banding, the URL-bar effect on `vh`, safe-area insets or the software keyboard (Chromium emulation cannot; the mobile-native skill says "real hardware is the bar").
- Motion: they cannot know how often something is used, whether it is justified, whether a popover's origin is right, or how it feels. The thresholds (ease-out, 300ms) are one author's craft standard; override `maxUiMotionMs` or ignore the key if your `RULES.md` differs.
- Copy checks are English word lists and will flag a company that is really called "Acme". Set `copyBanned`.
- `worst-case.js --how text` cannot tell data from fixed UI copy and stresses both (use `--only`). Its `hook` run only means something if the page reads `window.__AK_DATA__` (it says so and exits 2 if not).
- `completeness.js` proves nothing is visibly cut short, not that content is right.
- Several skill recommendations (translucent shadows, glass, grain, gradients, background photos) contradict a flat design rule and are not applied by the kit; see the decision table in `skills-integration.md`.

## FAQ
**Does it need my app's source?** No. A page file, a URL, or screenshots-as-pages are enough; with source you can run the same modes on the built output.

**Why are my light and dark rows identical?** The page ignores the theme mechanism the kit tried. Look for the WARNING in the report, then set `themeStrategies`, `themeClassMap` or `themeStorageKey` in `audit.config.json`.

**Why are hundreds of spacing values "off-grid"?** The default grid is 4px. If your app uses 6px/10px, set `spacingBase` to your base, or 0 to turn it off.

**Posters and decks fail the 12px rule.** Use a separate config (`--config poster.json`) with the floor that fits the output size.

**Why does `kit.js run break-test` say FAILED on the hook step?** Exit code 2 from `worst-case.js` means the page never read `window.__AK_DATA__`, so the fixtures were not applied. Wire the page (one line) or rely on the `text` step.

**An `ISSUES FOUND` step: is the kit broken?** No. The check ran and found problems; read the step's log. `FAILED` means the tool itself broke.

**<a id="offline"></a>Offline / no network.** Run `sh tools/setup.sh` once with network. Without it, point `NODE_PATH` at a global Playwright and `CHROMIUM_PATH` at an existing Chromium. With no browser at all, `audit.js` cannot run; the validator (`validate_palette.mjs`) and `palette-tools.js` still work, and the agent must say the measuring step was not done.

**Licences.** `tools/validate_palette.*` and `references/dataviz/` come from the `dataviz` skill bundled with Claude Code; `references/skills/` holds the text of twelve open-source design skill packs (ten originals, emilkowalski/skills, taste-skill; MIT/Apache licence files kept) (each folder's `SOURCE.md` and licence file). Check licences before redistributing the kit publicly.
