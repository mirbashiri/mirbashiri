# Limits & FAQ

## What it cannot do
- Judge hierarchy, taste, or what a colour *means*. The checklist makes the agent justify these from screenshots; a weak agent can still be shallow.
- Click, submit forms, swipe, use a screen reader or real touch. It reports what it did not exercise.
- Contrast on text over images or semi-transparent layers (computed colours on solid backgrounds only).
- Log in. Give it a list or folder of saved pages for protected screens.
- Redesign or change your code: audit modes are read-only; build modes create a **separate** new file and never overwrite the original.
- Guarantee the quality of a build: it catches measurable defects.

## FAQ
**Does it need my app's source?** No. A page file, a URL, or screenshots-as-pages are enough; with source you can run the same modes on the built output.

**Why are my light and dark rows identical?** The page ignores the theme mechanism the kit tried. Look for the WARNING in the report, then set `themeStrategies`, `themeClassMap` or `themeStorageKey` in `audit.config.json`.

**Why are hundreds of spacing values "off-grid"?** The default grid is 4px. If your app uses 6px/10px, set `spacingBase` to your base, or 0 to turn it off.

**Posters and decks fail the 12px rule.** Use a separate config (`--config poster.json`) with the floor that fits the output size.

**An `ISSUES FOUND` step: is the kit broken?** No. The check ran and found problems; read the step's log. `FAILED` means the tool itself broke.

**<a id="offline"></a>Offline / no network.** Run `sh tools/setup.sh` once with network. Without it, point `NODE_PATH` at a global Playwright and `CHROMIUM_PATH` at an existing Chromium. With no browser at all, `audit.js` cannot run; the validator (`validate_palette.mjs`) and `palette-tools.js` still work, and the agent must say the measuring step was not done.

**Licences.** `tools/validate_palette.*` and `references/dataviz/` come from the `dataviz` skill bundled with Claude Code; `references/skills/` holds the text of ten open-source design skills (each folder's `SOURCE.md` and licence file). Check licences before redistributing the kit publicly.
