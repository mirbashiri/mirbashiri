# Evidence: what was tested

Tests live in the Synek repo under `skills-lab/tests/`. "Fresh agent" = a new agent given only the one-line prompt and an isolated copy of the kit.

| test | what | result |
|---|---|---|
| 18 | all 17 modes run through `kit.js` on real targets | 16 of 17 tool runs clean; the 17th (generative-art) correctly reported a template that ignored `?seed=`. It also exposed three tool bugs (label-collision false positives on transformed SVGs, `#` in `--arg` swallowed by the shell, tint colours treated as chart series), all fixed |
| 19 | fresh agent, `poster` | minimum text 18px, accent contrast 6.13:1 (we computed), numbers match brief |
| 20 | fresh agent, `layout-redesign` on a 7-card dashboard | 0 metric regressions; light-theme contrast failures 7→0; off-grid spacing 203→4; original file untouched. "No invented data" **not** independently verified |
| 21 | fresh agent, `site-build` | first build failed three checks and was fixed; the Copy button was confirmed working by us |
| 22 | five fresh agents in parallel: `infographic`, `diagram`, `deck`, `generative-art`, `theme-variants` | all completed without tool errors; we re-checked metrics, numbers, seed reproducibility and theme contrast ourselves |
| 23 | fresh agent built this landing page (`docs/index.html`) with `site-build` from a brief + the docs | verify green (min text 14px, 0 low-contrast, no horizontal scroll, 0 off-grid). We then edited it by hand: bigger cards, a "Real run" line per mode, an image lightbox (tested: opens by click and keyboard, closes with Esc), replaced a link to a file that does not exist. The agent did not look at the light theme or mobile in detail; our own check was automated metrics plus desktop screenshots |
| 17 | skill A/B (chart with vs without the dataviz skill) | equal on mechanical checks; one build had more content and better accessibility, the other more consistent spacing; n = 1 per side |

## Pattern across fresh agents
Agents caught and fixed **measurable** defects (overflow, contrast, off-grid spacing, disallowed numbers). They left **behavioural** and **source-fidelity** claims unverified (clicks, theme toggles, whether box labels match the code) and said so in "Not verified". Verify those yourself.

## What was not tested
- 9 of 17 modes were run through the tools but not by a fresh agent: quick-scan, app-sweep, chart-review, rtl-check, interaction-test, controls-review, brand-kit, handoff-writer, skill-ab.
- The GitHub workflows in [github.md](github.md) were validated as YAML and their commands run locally, not on GitHub Actions.
- Crawling a live URL, pages behind login, real touch devices, screen readers, other browsers.
- One run per mode (n = 1): anecdote, not proof of reliability.
