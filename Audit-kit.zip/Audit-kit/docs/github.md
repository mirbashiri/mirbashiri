# Connect Audit-kit to GitHub

Four levels, from least to most automation. Everything here is a plain file you copy; nothing is switched on until you add it.

## 1. Keep it in the repo
Commit `Audit-kit/` with your project. `Audit-kit.zip` is not needed in the repo; it is only for sending the kit elsewhere. Each agent session that clones the repo has the kit.

## 2. Ask an agent from a PR or issue
Comment on the PR/issue: *"Use Audit-kit mode `quick-scan` on `build/dashboard.html`. Folder: `Audit-kit`."* An agent with repo access follows `RUNBOOK.md` and posts the audit.

## 3. Run it on every pull request (CI)
Copy [`examples/github-actions-audit.yml`](examples/github-actions-audit.yml) to `.github/workflows/audit.yml`. It checks out the repo, installs the kit, audits your built pages, **fails the check if a listed metric is above zero**, and uploads the report and screenshots as a build artifact.
Edit three things: the folder of built pages, the `--fail-on` list, and the Node/build steps for your project.
Start with a short list (`lowContrast,hScroll,errors`) and widen it once those stay green. Then make the check required in *Settings → Branches → branch protection*.
**[untested]** The workflow file was validated as YAML and its commands were run locally, but not on GitHub Actions itself.

## 4. Pre-commit
[`examples/pre-commit.sh`](examples/pre-commit.sh) audits staged `.html` files and blocks the commit if `--fail-on` metrics fail. Install: `cp Audit-kit/docs/examples/pre-commit.sh .git/hooks/pre-commit && chmod +x .git/hooks/pre-commit`.

## Publish the landing page
`docs/index.html` is a single file. GitHub Pages can serve only `/` or `/docs` of the repo root, so for a kit inside a subfolder use the workflow [`examples/github-pages.yml`](examples/github-pages.yml): it publishes `Audit-kit/docs` as the site. Steps: copy it to `.github/workflows/pages.yml`, then in *Settings → Pages* choose **Source: GitHub Actions**. A private repo needs a plan that allows Pages; a Pages site is public by default on most plans, so check what you are publishing (the landing page contains only text from this kit and screenshots of the test runs, which show Synek page names and sample data).

## Keep the kit versioned (iron rule)
The kit starts at version 1.00 and **every committed edit adds 0.01** ([IRON-RULES.md](../IRON-RULES.md)). Two pieces enforce it:
- **Local hook:** `sh Audit-kit/tools/install-hooks.sh` once per clone sets `core.hooksPath`. A commit that touches `Audit-kit/` is bumped automatically (with an auto-note) if you forgot; a commit whose `VERSION` is not exactly +0.01 is refused. Prefer `node Audit-kit/tools/bump-version.js --note "what changed"` before committing so the changelog entry reads well. Tested in a scratch repository: auto-bump, manual bump and refusal of a wrong version all behaved as described. The hook is local and `git commit --no-verify` skips it.
- **CI:** copy [`examples/version-check.yml`](examples/version-check.yml) to `.github/workflows/version-check.yml`. It runs `bump-version.js --check` and fails a pull request whose `VERSION` is not the base version + 0.01 per commit that touched `Audit-kit/`. **[untested]** on GitHub Actions itself.

## Fail-on cheat sheet
`lowContrast` text below contrast · `underMin` text below min font · `tap` small controls · `hScroll` horizontal scroll · `errors` page errors · `offGrid` spacing off the grid · `offToken` colours outside your tokens · `flat` gradients/rgba/shadows · `placeholders` dash/empty cards · `a11y` missing alt/labels/lang/title · `themeSwitch` theme switch had no effect.
