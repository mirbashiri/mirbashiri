# Skills integration: emilkowalski/skills and taste-skill

Two open-source skill packs were read in full (READMEs, every SKILL.md, catalogs, research notes) and judged on four questions: does it add a capability the kit lacks (measurable or checklist-able), is it app-agnostic, does it fit the kit's rules (flat design is a per-app option; the kit's own defaults and examples stay flat), and does it need tools the kit does not have (image generation, Figma, Stitch, Swift, React Native). Statements about a skill below come from its text; statements about a tool come from our runs (section "What was tested"). Uncertain items are tagged [likely]/[guess].

## Decision table

INTEGRATE = built into the kit as a mode and/or automatic check. ADAPT = used in part, or reshaped to fit the kit. SKIP = not used (text not copied unless stated).

### emilkowalski/skills (MIT)
| skill | decision | one-line reason |
|---|---|---|
| break-ui | **INTEGRATE** | worst-case data is a capability the kit lacked and the catalog is concrete; built as `break-test` + `break-data.js` + `worst-case.js` |
| mobile-native | **INTEGRATE** | most rules are statically detectable (input < 16px, 100vh, ungated hover, zoom lock, safe area); `mobile-check` + audit rows |
| review-animations (+STANDARDS) | **INTEGRATE** | ten standards, several measurable (transition: all, layout properties, ease-in, > 300ms, scale(0), reduced motion); `motion-review` + `motion-check.js` + audit rows |
| improve-animations (AUDIT, PLAN-TEMPLATE) | **ADAPT** | its audit categories are the same rules as review-animations; used as the manual checklist and an optional plan format in `motion-review`; the subagent/plan workflow is not built |
| find-animation-opportunities | **ADAPT** | the four-question Gate (frequency, purpose, speed, function) and the required "rejected candidates" list are used as manual steps; nothing to measure |
| emil-design-eng | **ADAPT** | reference text behind the motion rules; copied for traceability, not automated; its "semi-transparent shadow instead of border" advice is optional for flat apps |
| prototype (PICKER) | **ADAPT** | variants + switcher + divergence rule kept as `prototype-variants` + `variants.js`; the skill's picker is a translucent pill (rgba, backdrop blur, shadow) so it was rebuilt flat |
| animation-vocabulary | SKIP | a naming glossary for prompting; nothing to audit |
| apple-design | SKIP | gesture/spring behaviour is not statically checkable; its materials/translucency section conflicts with the flat default; no new measurable rule [likely: some typography ideas overlap what we already check] |
| animate | SKIP | builds animations from recipes (libraries); the kit audits, it does not generate motion |
| animate-expo | SKIP | React Native / Expo: needs a toolchain the kit does not have |
| write-swift | SKIP | Swift: not a web page, no tool |
| pick-ui-library | SKIP | dependency choice; the kit is dependency-free by design |
| ask-sonner | SKIP | support for one toast library |

### taste-skill (MIT)
| skill | decision | one-line reason |
|---|---|---|
| redesign-skill | **ADAPT** | typography and content audit became audit rows (tabular-nums, measure, orphans, placeholder/cliche copy, `100vh`); its shadow, gradient, grain, glass and background-photo advice contradicts flat design and is **not** applied |
| output-skill | **ADAPT** | the banned-pattern list became `completeness.js`, applied to the built file instead of promised in a prompt; used in `polish-check` |
| taste-skill (main) | **ADAPT** | only the mechanical items used (measure 65ch, CTA label on one line, "Jane Doe" names, optional em-dash ban); dials, brief inference, block library and hero rules are taste, not measurable; the text recommends gradients and GSAP libraries |
| minimalist-skill, brutalist-skill | **ADAPT** (reference only) | optional style directions for `prototype-variants` / `site-build`; nothing measures fidelity; minimalist's own text recommends rgba borders, shadows and radial gradients, brutalist bans them |
| research/laziness | **ADAPT** (reference only) | copied under `output-skill/research-laziness/`; the useful, checkable part is the banned-pattern list. The quoted effect sizes (tip, "deep breath", seasonal output) are **not** used: they are cited without sources we could check and we did not reproduce them |
| taste-skill-v1, gpt-tasteskill | SKIP | superseded / duplicate of the main skill; GSAP-heavy "Awwwards" style |
| soft-skill | SKIP | a "soft, expensive" look built on depth and shadows: conflicts with the flat default, not measurable |
| image-to-code-skill, imagegen-frontend-web, imagegen-frontend-mobile, brandkit | SKIP | need image generation |
| stitch-skill | SKIP | needs Google Stitch |

## What was built

| piece | what | file |
|---|---|---|
| shared checks | one in-page function: mobile/touch, motion, typography, copy | `tools/lib/checks.js`, `tools/lib/run-checks.js` |
| audit rows | 8 new rows + `checks.*` in `report.json`; new `--fail-on` keys `mobile hoverGate motion reducedMotion typography copy`; new config keys `staticChecks minInputPx maxUiMotionMs maxMeasureCh copyBanned banEmDash` (safe defaults, info-only unless in `--fail-on`) | `tools/audit.js`, `audit.config.json` |
| mobile-check | phone emulation + the mobile-native rules | `tools/mobile-check.js`, mode `mobile-check` |
| motion-review | static + observed motion, second render under reduced motion | `tools/motion-check.js`, mode `motion-review` |
| break-test | fixture generator + page injection + diff | `tools/break-data.js`, `tools/worst-case.js`, mode `break-test` |
| polish-check | typography/copy rows + completeness | mode `polish-check`, `tools/completeness.js` |
| prototype-variants | flat switcher, picker test, per-variant measurements, divergence | `tools/variants.js`, mode `prototype-variants` |
| fixtures | clean/bad pairs the checks must pass/fail | `examples/checks-*.html`, `examples/break-demo*.{html,json}`, `examples/variants/` |
| selftest | steps 5-8 (bad must fail, clean must pass) | `tools/selftest.sh` |
| references | skill text + licences + SOURCE.md | `references/skills/11-emilkowalski/`, `references/skills/12-taste-skill/` |

Modes are now 22 (was 17): `mobile-check`, `motion-review`, `break-test`, `polish-check` in group 1 (orders 6-9; later modes renumbered), `prototype-variants` in group 2 (order 14).

## What was tested (our runs; commands and exit codes in `CHANGES.md` next to the kit folder)

**Checks can fail and pass.** `checks-bad.html` (every flaw on purpose) fails all four families (`--fail-on mobile,motion,typography,copy`: 7 / 11 / 8 / 7 findings per theme); `checks-good.html` passes with all six keys. `mobile-check` and `motion-check` exit 1 on the bad fixture and 0 on the clean one; `completeness.js` exits 1 on a truncated file and 0 on the clean one. `break-demo-bad.html` (no `min-width: 0`, no `flex-shrink: 0`, raw numbers, hard-coded plural, `undefined` role) fails the worst-case run with 3 Broken, 4 Ugly and 2 Fragile rows; `break-demo-good.html` has no Broken/Ugly row. `variants.js` passes a 3-variant set (picker 6/6), flags a colour-only pair as one direction and rejects "Option A/B". `sh tools/selftest.sh`: ALL OK.

**Real targets** (from `skills-lab/tests`):
| target | what the new checks found |
|---|---|
| `/tmp/flaw.html` (known flawed) | mobile-check: no viewport meta, layout 980px on a 390px phone, scrollWidth 980px |
| 05 landing page | motion: 9 transitions on layout properties (`width`, `height`), 3 over 300ms; 3 ungated `:hover` rules; a reduced-motion rule exists and under `reduce` the running animations drop from 2 to 0 |
| 13 dashboard (c-refined) | 3 ungated `:hover`; 3 SVG axis labels without tabular-nums; 7 nav links `href="#"` (a mock-up); text-mode worst case: 2 Broken (nav pushed off-screen at 720/320px, page 1565px wide at 1440px), 4 Ugly |
| 15 positions carousel | motion: 0 findings; 6 ungated `:hover` |
| 16 analytics | a 157ch footnote paragraph, 1 orphan, 7 `href="#"` links, 5 em-dashes (info) |
| 21 site build | 6 orphaned last words in paragraphs/list items, re-measured independently with a separate script: all real; 3 ungated `:hover` |
| `sample-page.html` (the kit's known-good page) | unchanged existing metrics (selftest step 3 still OK) |

**False positives found on real pages and fixed:** (1) `scaleX(0)` draw-on lines on the landing page counted as `scale(0)` entrances: now only uniform `scale(0)`; (2) calendar-cell buttons on the analytics page counted as wrapped CTAs: buttons inside tables/grids or with block children are skipped; (3) list items whose text sits in block children counted as orphans: only leaf text blocks are measured; (4) a paragraph containing a button counted as an orphan: excluded; (5) a spinner counted as "movement under reduced motion": loops are listed but not counted; (6) responsive SVG charts counted as squished: squish only for media <= 128px; (7) `break-data` replaced ticker `SOL` and side `S` with 30-character labels (implausible): short upper-case codes and low-cardinality enums are now kept realistic, numeric series get one outlier instead of money-like values.

**Remaining false-positive sources (not fixed):** English-only copy list; `href="#"` links in single-page apps with click handlers; ungated `:hover` is reported for every rule even when the effect is harmless on touch; `worst-case --how text` stresses fixed UI copy (on our "good" page it flagged a `nowrap` badge given a 44-character label: a design decision, not a bug); orphans depend on font loading and viewport.

## What changes for users
Nothing existing changed behaviour except: (a) `audit.js` reports gain rows and `report.json` gains `checks.*` (additive); (b) existing mode `order` values moved to keep the list coherent; (c) `sweep` selftest now excludes the new fixtures.

## Not verified
- Behaviour on real phones: sticky hover, tap delay, safe-area insets, URL-bar `vh`, keyboard, rubber-banding.
- Whether the motion thresholds (ease-out, 300ms) suit any given app, how motion feels, frequency and purpose of animations.
- Hook run on a real app (only our two demo pages read `window.__AK_DATA__`); `--how route` was implemented but not run against a real API.
- Images/404 avatars, loading/error states, locale formats, real browser zoom, RTL worst-case (`--rtl` implemented, not run on a real target), dark mode in the worst-case tool.
- Fresh-agent use of any of the five new modes; all test inputs for the pass/fail pairs were written by us.
- External stylesheets: the CSSOM fallback that reads local `<link>` files from disk was implemented but not exercised (our targets are single-file pages); the landing page reported one unreadable stylesheet [likely a font link].
- Upstream commit hashes of both packs (the copies had no git metadata).
- `docs/index.html` (landing page) was not edited; it still says 17 modes. Follow-up lines: 103 (`17 modes` nav link), 136 (`17 jobs, one command`), 172 and 179 (evidence bullets quoting 16 of 17 / 9 of 17), 192 (`The 17 modes` card), 197 (licence sentence "ten"), plus the mode cards for the five new modes and a skills-integration link.

## Licences
Both packs are MIT. `references/skills/11-emilkowalski/LICENSE` (Copyright (c) 2026 Emil Kowalski) and `references/skills/12-taste-skill/LICENSE` (Copyright (c) 2026 Leonxlnx) are kept verbatim; each folder's `SOURCE.md` states what was copied and omitted. The tools in `tools/` are original to the kit; they implement ideas and rule lists from the skill text and do not copy skill code.
