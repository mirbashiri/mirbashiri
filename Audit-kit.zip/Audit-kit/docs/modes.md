# The 22 modes

Each mode is a ready-made job. You tell an agent **"Use Audit-kit mode `<name>` on `<target>`"**; the agent runs the command shown, reads the generated `RUNBOOK.md`, and follows its checklist. Images below are real outputs from our own test runs (see [evidence](evidence.md)).

Status: **fresh agent** = a new agent built/ran it from the one-line prompt alone; **tool run** = we ran the tools directly on real targets but no fresh agent was tried.

## Audit (read-only)

### `quick-scan`
![quick-scan example](img/quick-scan.jpg)

**What it does.** Small errors on one page: fonts, colours, spacing, radii, contrast, tap size.  
**Example from a real run.** On a dashboard we built ourselves it found 152 spacing values off the 4px grid and 3 different corner radii, although every font and contrast check passed.  
**Status.** tool run

```
node tools/kit.js run quick-scan <page> --out out/qs
```

**Checklist (excerpt):**
- [ ] Fonts: nothing under min size; <=5-6 distinct sizes; <=2 families; same role = same size
- [ ] Colours: every text >= contrast; no off-token hex; no near-duplicate greys; meaning-colours not decorative
- [ ] Spacing: off-grid values listed with elements; same-role elements share padding; repeated lists have even gaps
- [ ] Radii: <=2-3 distinct values

**Deliverables:** quick-scan.md: fix list table (category | where | now | should be | confidence | effort); audit/report.md + PNGs

**Limits:** Static render only: no clicks, no hover/focus states (use interaction-test); Off-grid depends on spacingBase; set 0 if the app has no grid

### `app-sweep`
![app-sweep example](img/app-sweep.jpg)

**What it does.** Every page of the app, ranked, plus problems that repeat across pages.  
**Example from a real run.** On five pages it listed fonts and radii per page and showed which pages drift. Caveat: when every page hits the off-grid cap the ranking says little.  
**Status.** tool run

```
node tools/kit.js run app-sweep <url|folder|list.txt> --arg exclude='template|partial' --out out/sweep
```

**Checklist (excerpt):**
- [ ] Pages found/audited/skipped listed, with reasons
- [ ] Shared problems each cite >= 2 pages
- [ ] Font families / radii / colour counts across the app stated
- [ ] Login-protected pages explicitly marked not covered

**Deliverables:** app-audit.md (worst first | shared problems | page ranking | per-page top 3 | not verified); sweep/summary.md + per-page reports

**Limits:** Crawler does not log in; give a list/folder for protected pages; Score is a rough ranking, not severity (off-grid is capped)

### `chart-review`
![chart-review example](img/chart-review.jpg)

**What it does.** Is each chart the right form, is its palette valid, are marks and labels clean.  
**Example from a real run.** On a chart page the validator rejected the amber/red pair in the light theme (colour-blind distance 2.8 where 8 is the floor) and flagged amber's lightness in dark.  
**Status.** tool run

```
node tools/kit.js run chart-review <page> --out out/charts
```

**Checklist (excerpt):**
- [ ] Form chosen before colour for every chart
- [ ] Palette validated per theme; FAIL with CVD 6-8 only if secondary encoding exists
- [ ] No gradients/rgba/shadow where the app is flat
- [ ] Direct labels or legend whenever CVD distance is low

**Deliverables:** chart-review.md; audit/report.md, validator output

**Limits:** validate-report is heuristic about which colours are series; confirm by eye; canvas charts expose no SVG colours: read hexes from source; check-labels reads the FIRST svg only

### `rtl-check`
![rtl-check example](img/rtl-check.jpg)

**What it does.** Right-to-left text: direction, bidi, letter-spacing, digits, small fonts.  
**Example from a real run.** On a Persian diagram it found nine texts at 11.5px, one letter-spaced headline, one middle dot and four Latin runs not isolated.  
**Status.** tool run

```
node tools/kit.js run rtl-check <page> --out out/rtl
```

**Checklist (excerpt):**
- [ ] html dir and lang set
- [ ] RTL text renders rtl, right-aligned
- [ ] Latin runs/IDs isolated (bdi / dir=ltr / unicode-bidi)
- [ ] No letter-spacing on RTL text; no '·' separators; comparison signs not mirrored wrongly

**Deliverables:** rtl-check.md; rtl/rtl.png

**Limits:** Heuristics; no human Persian reader — a native reader should confirm wording and bidi

### `interaction-test`
![interaction-test example](img/interaction-test.jpg)

**What it does.** Keyboard, focus, hover and control states.  
**Example from a real run.** On a carousel page: 20 controls, no keyboard trap, every control showed focus, two had no hover feedback. Cropped state images are saved.  
**Status.** tool run

```
node tools/kit.js run interaction-test <page> --out out/ix
```

**Checklist (excerpt):**
- [ ] Every interactive element reachable by Tab, visible focus indicator
- [ ] No keyboard trap; tab order follows reading order
- [ ] Hover and focus feedback exist for all controls (active nav item may be exempt)
- [ ] Disabled controls look disabled and are not focusable

**Deliverables:** interaction-test.md; interact/report.md, states-sheet.png

**Limits:** Does not click or submit; no screen reader, no touch gestures

### `mobile-check`
*(no example image yet)*

**What it does.** Phone and touch problems read from the page: zoom lock, small inputs, 100vh, ungated hover, safe area.  
**Example from a real run.** On a known-flawed fixture it reported a missing viewport meta (the page laid out at 980px on a 390px phone, scrollWidth 980). On our dashboard and landing targets it found 3 `:hover` rules outside `@media (hover: hover)` each and nothing else; the clean fixture had 0 issues, the bad fixture 7. Caveat: we tapped a hover-styled element in Chromium touch emulation and `:hover` did not stick, so that finding is a CSS-reading rule, not a reproduced bug.  
**Status.** tool run (ours; no fresh agent tried it)

```
node tools/kit.js run mobile-check <page> --out out/mobile
```

**Checklist (excerpt):**
- [ ] Viewport meta present with width=device-width; zoom NOT disabled (fix the input font size instead)
- [ ] Inputs, textarea, select >= 16px (or 16px under (pointer: coarse))
- [ ] No 100vh for app shells (100dvh) or heroes (100svh)
- [ ] Every :hover rule inside @media (hover: hover) and (pointer: fine); touch users get :active feedback

**Deliverables:** mobile-check.md; mobile/report.md, mobile.png

**Limits:** Chromium emulation does not reproduce sticky hover, tap delay, rubber-banding, URL-bar/vh behaviour, the software keyboard or safe-area insets: the skill itself says real hardware is the bar; Ungated-hover, 100vh and safe-area findings are CSS-reading rules, not reproduced bugs; Stylesheets that cannot be read through the CSSOM (cross-origin) make CSS-rule findings incomplete (the report says so)

### `motion-review`
*(no example image yet)*

**What it does.** What animates, checked against the skill's measurable motion rules, plus what still moves under reduced motion.  
**Example from a real run.** On the landing target it found 9 transitions on layout properties (`width`, `height`) and 3 durations over 300ms; the carousel and the clean fixture had none; the bad fixture broke all 9 rules (transition:all, ease-in, scale(0), width keyframes, no reduced-motion rule). It cannot say whether the animations are justified or how they feel.  
**Status.** tool run (ours; no fresh agent tried it)

```
node tools/kit.js run motion-review <page> --out out/motion
```

**Checklist (excerpt):**
- [ ] No `transition: all`; no transitions/keyframes on width/height/margin/padding/top/left
- [ ] No ease-in on UI; strong ease-out for enter/exit
- [ ] UI durations <= 300ms (infinite loaders excluded); press feedback 100-160ms
- [ ] No scale(0) entrances (start at 0.9-0.97 + opacity); popovers origin-aware

**Deliverables:** motion-review.md (Before | After | Why table + verdict); motion/report.md

**Limits:** Cannot know frequency of use, purpose, origin correctness, interruptibility or feel: those are judged by the agent and marked [likely]/[guess]; JS-driven motion (rAF, script-started Web Animations) is only seen if running at load; The skill's rules are one author's craft standard (ease-out, <300ms); a per-app RULES.md can override them (set maxUiMotionMs in audit.config.json)

### `break-test`
*(no example image yet)*

**What it does.** Worst-case data (long names, odd emails, 0/1/1,000 items, huge numbers, missing fields) against the page, diffed against the demo render at 1440/720/320px.  
**Example from a real run.** On a deliberately fragile member list it found 3 Broken (menu pushed off-screen at 320px, `undefined` rendered for a missing role, page scroll widening from 352px to 421px), 4 Ugly (squished avatars, spilled text, "1 members") and 2 Fragile (no empty state, 8,011 DOM nodes at 1,000 rows); the robust twin had no regression (only the DOM-size note). With `--how text` on our dashboard target (no code change) it listed 2 Broken and 4 Ugly, but that run also stresses fixed UI copy, so treat it as a lead. On the robust page the text run flagged a nowrap status badge given a 44-character label: a real design decision, exaggerated by the heuristic.  
**Status.** tool run (ours; no fresh agent tried it)

```
node tools/kit.js run break-test <page> --arg data=fixture.json --out out/break
```

**Checklist (excerpt):**
- [ ] Every rendered value in the Phase 1 table, with a source and a limit or 'unbounded'
- [ ] Worst case mixes failures across rows (not stacked in row 1); empty, one and 1,000-row states covered
- [ ] Checked at the component's real container width, 320px and the widest layout; 200% zoom; dark/RTL if supported
- [ ] Truncated text has a way to read it; numbers/amounts/dates never truncated; no raw NaN/undefined/null

**Deliverables:** break-test.md (Part 1 / Part 2 / Part 3); data/*.json + manifest.md (the regression fixture: keep it)

**Limits:** The 'text' run cannot tell data from fixed UI copy and stresses both: use --only on the data region; Kind inference of fixture fields is a guess: check manifest.md; Not exercised: image 404s, loading/error states, locale formats, relative time, real browser zoom; Needs the page to read window.__AK_DATA__ for the hook run; without it use the text run or --route for network data

### `polish-check`
*(no example image yet)*

**What it does.** Typography and generic-AI tells (tabular numbers, line length, orphans, cliche copy, dead # links, wrapped CTAs) plus a completeness scan of the source file.  
**Example from a real run.** On a built site page it found 6 paragraphs ending in a single word (we re-measured them independently: all 6 real) and nothing else; on an analytics page a 157ch footnote and 7 `href="#"` nav links. It once flagged calendar-cell buttons as "wrapped CTAs" (false positive, fixed: buttons inside tables/grids or with block children are now skipped).  
**Status.** tool run (ours; no fresh agent tried it)

```
node tools/kit.js run polish-check <page> --out out/polish
```

**Checklist (excerpt):**
- [ ] Numbers in data tables/KPIs use tabular figures (font-variant-numeric: tabular-nums or a mono face)
- [ ] Body text measure <= ~65ch (the kit flags only above maxMeasureCh, default 80)
- [ ] No single-word last lines on headings/paragraphs (text-wrap: balance / pretty)
- [ ] No lorem ipsum, 'John Doe', 'Acme', 'Elevate/Seamless/Unleash/Next-Gen/Game-changer/Delve' copy (English-only list; set copyBanned for your app)

**Deliverables:** polish-check.md; audit/report.md, completeness output

**Limits:** Copy checks are English-only string lists; a legitimate word (a company called Acme) is a false positive: confirm; Measure is computed in ch of the paragraph's own font; font loading can shift it; Orphan detection needs >= 4 words and >= 2 lines; it reads rendered line boxes at each viewport; Completeness is regex + syntax checks: it shows nothing is visibly cut short, not that the content is right

## Build / redesign

### `layout-redesign`
![layout-redesign example](img/layout-redesign.jpg)

**What it does.** Audit the layout, rebuild it as a separate page, prove it with numbers, get a before/after image.  
**Example from a real run.** A fresh agent turned a 7-card dashboard into one with Net PnL as the primary figure: light-theme contrast failures 7→0, off-grid spacing 203→4, no metric worse.  
**Status.** fresh agent

```
node tools/kit.js run layout-redesign <page> --out out/lr
# build out/lr/after/index.html, then:
node tools/kit.js verify layout-redesign out/lr/after/index.html --arg run=out/lr --out out/lr/verify
```

**Checklist (excerpt):**
- [ ] One primary element; it is the largest/first
- [ ] Repeated identical rows grouped; no-data states one line
- [ ] No invented data; missing data stated on the page
- [ ] Metrics comparison has 0 unexplained WORSE rows

**Deliverables:** before-after-dark.png (+light/mobile); after/index.html (mockup unless user said apply + gave source); plan.md, redesign-report.md

**Limits:** A mockup is not the app: routing/state/API not implemented or tested; More content can raise off-grid/colour counts: judge WORSE rows, do not obey blindly

### `site-build`
![site-build example](img/site-build.jpg)

**What it does.** Build a landing or docs page from a brief, then verify on every theme and width.  
**Example from a real run.** A fresh agent built this kit's landing page: the first build failed three checks (mobile scroll, a 4.41:1 label, one off-grid padding), all fixed before verify went green.  
**Status.** fresh agent

```
# write the page from your brief, then:
node tools/kit.js verify site-build <built.html> --out out/site
```

**Checklist (excerpt):**
- [ ] One primary action visible without scrolling
- [ ] Type scale <=5-6 sizes, spacing on a grid, <=3 radii
- [ ] Contrast >= 4.5 in every theme; no horizontal scroll at 390
- [ ] All controls keyboard-reachable with visible focus

**Deliverables:** site/index.html; desktop.png, mobile.png; plan.md, site-report.md

**Limits:** Static build; no backend; fonts fall back if not embedded

### `theme-variants`
![theme-variants example](img/theme-variants.jpg)

**What it does.** Try several colour themes on the same page and measure each.  
**Example from a real run.** A fresh agent proposed four themes for the landing page; all four measured zero low-contrast texts. On another page one hard-coded chip colour stayed at 1.22:1 in a light theme.  
**Status.** fresh agent

```
node tools/kit.js run theme-variants <page> --arg themes=<themes.json> --out out/themes
```

**Checklist (excerpt):**
- [ ] Every theme overrides the same variables (no half-themed page)
- [ ] Text contrast >= 4.5 in every theme
- [ ] Status colours (good/bad/warn) still distinguishable and meaning preserved
- [ ] Chart palette validated per theme

**Deliverables:** themes/sheet.png; themes/summary.md; theme-report.md

**Limits:** Only variables the page actually uses change; hard-coded colours stay

### `controls-review`
![controls-review example](img/controls-review.jpg)

**What it does.** Buttons, toggles and menus in every state, and whether the set is consistent.  
**Example from a real run.** Produces default/hover/focus crops for each control plus a list of controls with no hover or focus feedback.  
**Status.** tool run

```
node tools/kit.js run controls-review <page> --out out/controls
```

**Checklist (excerpt):**
- [ ] Same role = same size/radius/padding across the app
- [ ] Visible focus ring on every control
- [ ] Disabled looks disabled; loading prevents double submit
- [ ] Touch size >= min; icon-only buttons have accessible names

**Deliverables:** controls-review.md; interact/states-sheet.png

**Limits:** Active/loading/error states need manual triggering

### `prototype-variants`
*(no example image yet)*

**What it does.** 2-5 genuinely different versions of one UI piece behind a flat switcher, measured side by side.  
**Example from a real run.** On three toast variants (Quiet, Editorial, Playful) the picker passed 6 of 6 click/key checks and every variant measured clean (min font 14px, 0 low-contrast, 0 page errors). A set differing only in accent colour was flagged as one direction; a set named "Option A/B" with the same axis was rejected as invalid.  
**Status.** tool run (ours; no fresh agent tried it)

```
node tools/kit.js verify prototype-variants variants.json --out out/variants
```

**Checklist (excerpt):**
- [ ] 2-5 variants, descriptive names (never Option A/B/C), each with a distinct stated axis
- [ ] Every variant fully works (interactions, motion, realistic content) and has no page errors
- [ ] Picker test green: one variant visible at a time at full size, keys 1-N, arrows, R, hash
- [ ] Variants measured in the same table; no variant regresses min font/contrast/tap size without a reason

**Deliverables:** variants.json, one HTML file per variant; variants/picker.html, variants.md, sheet.png

**Limits:** The picker is a flat adaptation of the skill's translucent pill (kit flat default); behaviour and keys are the skill's; Divergence is a layout-occupancy heuristic, not a judgement of design intent; Choosing the winner, the feel of motion, promotion and cleanup are manual

## Static graphics

### `poster`
![poster example](img/poster.jpg)

**What it does.** Design a poster at exact pixel size and verify its text.  
**Example from a real run.** A fresh agent made a 1080×1350 poster: minimum text 18px, accent contrast 6.13:1, no invented numbers.  
**Status.** fresh agent

```
node tools/kit.js verify poster <poster.html> --arg w=1080 --arg h=1350 --out out/poster
```

**Checklist (excerpt):**
- [ ] One focal point; reading order obvious in 3 seconds
- [ ] Text >= readable size at final size; contrast >= 4.5
- [ ] No clipped/overlapping text
- [ ] Brand colours/logo as specified; no invented claims

**Deliverables:** poster.png (@2x); poster.html; philosophy note

**Limits:** Fonts not installed render as fallback; check the PNG

### `infographic`
![infographic example](img/infographic.jpg)

**What it does.** Turn facts into an infographic; check chart forms, labels and every number against the source.  
**Example from a real run.** A fresh agent built a 1200×1600 infographic: minimum text 20px, label collisions clean, every number checked against the brief. Its first render overflowed to 1726px and was fixed.  
**Status.** fresh agent

```
node tools/kit.js verify infographic <file.html> --arg w=1200 --arg h=1600 --out out/info
```

**Checklist (excerpt):**
- [ ] Every number equals the source (spot-check all)
- [ ] One headline claim; hierarchy readable
- [ ] Chart forms fit the data; palette validated
- [ ] No label overlaps; text >= min; contrast ok

**Deliverables:** infographic.png (@2x); infographic.html; number cross-check table

**Limits:** Skill templates/fonts omitted in this kit; see SOURCE.md to fetch

### `diagram`
![diagram example](img/diagram.jpg)

**What it does.** A diagram that shows the mechanism; checks for overlapping or clipped labels.  
**Example from a real run.** A fresh agent drew this kit's own architecture: label-collision check clean, only kit.js carries the accent colour. Names in the boxes come from the brief and were not checked against the code.  
**Status.** fresh agent

```
node tools/kit.js verify diagram <file.html> --arg w=1400 --arg h=900 --out out/diagram
```

**Checklist (excerpt):**
- [ ] Shows mechanism/relationships, not a list in boxes
- [ ] Arrow direction and reading order unambiguous
- [ ] No overlapping or clipped labels
- [ ] Text >= min; colours carry one meaning each

**Deliverables:** diagram.svg/html; diagram.png (@2x)

**Limits:** check-labels reads the first <svg> only

### `deck`
![deck example](img/deck.jpg)

**What it does.** Render every slide of an HTML deck with per-slide checks and a contact sheet.  
**Example from a real run.** A fresh agent built a 6-slide deck: minimum text 22px, no text outside the slide box. It caught and removed a headline number the brief did not allow.  
**Status.** fresh agent

```
node tools/kit.js run deck <deck.html> [--arg next=ArrowLeft] --out out/deck
```

**Checklist (excerpt):**
- [ ] One message per slide, headline states it
- [ ] Min font on every slide >= threshold (slides/report.md)
- [ ] No text outside slide box
- [ ] Consistent margins, title position, colour roles across slides

**Deliverables:** slides/*.png, slides/sheet.png; deck-report.md

**Limits:** Default key is ArrowRight; RTL decks need --arg next=ArrowLeft; PDF export not produced by this kit

### `generative-art`
![generative-art example](img/generative-art.jpg)

**What it does.** Seeded generative art with a reproducibility check.  
**Example from a real run.** A fresh agent built a 17-cell grid of instrument marks. We re-rendered seed 1 twice (identical files) and seeds 3 and 7 (different). Earlier, the same check caught a template that ignored ?seed=.  
**Status.** fresh agent

```
node tools/kit.js verify generative-art <sketch.html> --out out/art
```

**Checklist (excerpt):**
- [ ] seed-1.png and seed-1b.png are identical (compare file hashes: md5sum)
- [ ] Different seeds look different but belong to one family
- [ ] Composition has a focal area; no accidental empty/over-dense regions
- [ ] Palette from the brand/tokens

**Deliverables:** sketch.html; seed renders + sheet.png; philosophy note

**Limits:** Real p5.js not available offline; test only the build you ship

## Brand & handoff

### `brand-kit`
![brand-kit example](img/brand-kit.jpg)

**What it does.** A palette's contrast matrix, CSS tokens and chart-series validation.  
**Example from a real run.** Produced a 40-colour contrast matrix and confirmed a four-colour chart palette passes all validator checks in dark.  
**Status.** tool run

```
node tools/kit.js run brand-kit <palette.json> --arg series=#hex,#hex --arg surface=#hex --out out/brand
```

**Checklist (excerpt):**
- [ ] Every text/background pair used in UI >= 4.5 (graphics >= 3)
- [ ] One accent colour per app; status colours reserved
- [ ] Series colours pass validator per theme (or labelled)
- [ ] Tokens exported (css) and equal to palette.json

**Deliverables:** brand-kit.md (roles, pairings, matrix); tokens.css (from css step)

**Limits:** Does not choose a brand for you; palette changes need the owner

### `handoff-writer`
![handoff-writer example](img/handoff-writer.jpg)

**What it does.** A self-contained prompt for another agent, with acceptance criteria taken from real measurements.  
**Example from a real run.** Measures the reference page first, so 'done' means numbers (minimum font, contrast, no horizontal scroll), not taste.  
**Status.** tool run

```
node tools/kit.js run handoff-writer <reference-page> --arg palette=<palette.json> --out out/handoff
```

**Checklist (excerpt):**
- [ ] Prompt is self-contained (no 'as discussed')
- [ ] Every referenced file exists and is included
- [ ] Acceptance criteria are measurable (use audit numbers)
- [ ] Open decisions listed separately

**Deliverables:** PROMPT.md; palette.json + tokens.css; README with file index

**Limits:** Real app code is not known to the agent unless included

## Meta

### `skill-ab`
![skill-ab example](img/skill-ab.jpg)

**What it does.** Same brief with and without a skill, compared on the same metrics.  
**Example from a real run.** Showed that a chart built with the dataviz skill had more content and more consistent accessibility but less consistent spacing than one built without it. One run each: anecdote, not proof.  
**Status.** tool run

```
node tools/kit.js verify skill-ab <A.html> --arg a=<A.html> --arg b=<B.html> --out out/ab
```

**Checklist (excerpt):**
- [ ] Same brief, data, tokens, time budget
- [ ] A did not read the skill
- [ ] Mechanical metrics compared AND screenshots compared
- [ ] Extra content (tables, notes) accounted for when reading WORSE rows

**Deliverables:** compare table; ab-notes.md in the style of examples/example-ab-test.md

**Limits:** One run per side is anecdote; Metrics miss hierarchy/aesthetics
