# Configuration

## RULES.md — your app's rules (human-written)
The audit judges against this file. Fill: themes and tokens file, colour meaning (e.g. green = profit), flat design yes/no, minimum text size, language/direction, banned words, data caveats. An agent finding it unfilled audits against generic best practice and says so.

## audit.config.json — thresholds (machine-read)
| key | default | meaning |
|---|---|---|
| `minFontPx` | 12 | text below this is reported (also applies to SVG and RTL text) |
| `minTapPx` | 24 | clickable controls smaller than this are reported |
| `contrastNormal` / `contrastLarge` | 4.5 / 3 | WCAG text contrast thresholds |
| `flatDesign` | false | true: gradients, rgba and shadows count as failures |
| `themes` | `["dark","light"]` | theme names rendered |
| `themeStrategies` | query, attribute, class, emulate | how themes are switched (also `storage`) |
| `themeQueryParam` / `themeAttribute` | theme / data-theme | names used by the page |
| `themeClassTarget` / `themeClassMap` | html, body / null | class-based themes, e.g. `{"dark":"theme-night"}` |
| `themeStorageKey` / `themeStorageValues` | null | localStorage key and values per theme |
| `viewports` | desktop 1440×900, mobile 390×844 | |
| `mobile` | true | include the mobile viewport |
| `spacingBase` | 4 | spacing values not multiples of this are flagged (0 = off) |
| `tokensFile` / `tokenColors` | null | allowed palette: a CSS file (hex colours are read from it) or a list; colours outside are reported |

Different thresholds per kind of output: pass `--config my.json` (posters and decks need a lower or higher font floor than UI).

**Theme-switch safety net:** if the page background is identical in every theme, the report prints a WARNING that the light/dark rows are the same page. Fix `themeStrategies` or audit each theme by hand.

## Modes — `modes/<name>.json`
One file per mode. Fields: `name, group, order, title, summary, inputs[], skills[], defaults{}, auto[], steps[], verify[], checklist[], deliverables[], limits[], config{}`.
- `auto[]` runs on `kit.js run`; `verify[]` on `kit.js verify`. A step is `{ "id", "desc", "cmd", "check"?, "failOn"? }`.
- Placeholders in `cmd`: `{target}` `{built}` `{out}` `{kit}` and any `--arg key=value` (as `{key}`); `defaults` supplies fallbacks. A step with an unset placeholder is skipped and listed.
- `check: true` means exit code 1 = "issues found", not a tool failure.
- `config` overrides `audit.config.json` when used as `audit.js --mode <name>`.

**Add your own:** copy a JSON file, edit, run `node tools/kit.js list`.

## Profiles
`profiles/example-synek/` is a worked example of a filled-in app profile: rules, tokens, palette. Copy its structure for your app.
