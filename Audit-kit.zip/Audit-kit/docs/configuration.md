# Configuration

## RULES.md — your app's rules (human-written)
The audit judges against this file. Fill: themes and tokens file, colour meaning (e.g. green = profit), flat design yes/no, minimum text size, language/direction, banned words, data caveats. An agent finding it unfilled audits against generic best practice and says so.

## audit.config.json — thresholds (machine-read)
| key | default | meaning |
|---|---|---|
| `minFontPx` | 12 | text below this is reported (also applies to SVG and RTL text) |
| `minTapPx` | 24 | clickable controls smaller than this are reported |
| `contrastNormal` / `contrastLarge` | 4.5 / 3 | WCAG text contrast thresholds |
| `flatDesign` | false | true: gradients, rgba and shadows count as failures |
| `themes` | `["dark","light"]` | theme names rendered |
| `themeStrategies` | query, attribute, class, emulate | how themes are switched (also `storage`) |
| `themeQueryParam` / `themeAttribute` | theme / data-theme | names used by the page |
| `themeClassTarget` / `themeClassMap` | html, body / null | class-based themes, e.g. `{"dark":"theme-night"}` |
| `themeStorageKey` / `themeStorageValues` | null | localStorage key and values per theme |
| `viewports` | desktop 1440×900, mobile 390×844 | |
| `mobile` | true | include the mobile viewport |
| `spacingBase` | 4 | spacing values not multiples of this are flagged (0 = off) |
| `tokensFile` / `tokenColors` | null | allowed palette: a CSS file (hex colours are read from it) or a list; colours outside are reported |
| `staticChecks` | true | add the mobile / motion / typography / copy rows to `audit.js` (info only unless named in `--fail-on`) |
| `minInputPx` | 16 | inputs/textarea/select below this font size are reported (iOS Safari zooms into inputs under 16px) |
| `maxUiMotionMs` | 300 | finite UI transitions/animations longer than this are reported; infinite loops (spinners) are not |
| `maxMeasureCh` | 80 | paragraphs (>= 160 chars) wider than this many `ch` are reported; the taste-skill target is about 65ch, 80 is the kit's tolerance |
| `copyBanned` | null | cliche/placeholder phrases to report in visible text; null = built-in English list (lorem ipsum, John/Jane Doe, Acme, elevate, seamless, unleash, next-gen, game-changer, delve, tapestry, "in the world of", "oops!"), `[]` = off |
| `banEmDash` | false | true: em/en dashes in visible text count as copy findings (taste-skill bans them; most apps do not) |

Different thresholds per kind of output: pass `--config my.json` (posters and decks need a lower or higher font floor than UI).

**Theme-switch safety net:** if the page background is identical in every theme, the report prints a WARNING that the light/dark rows are the same page. Fix `themeStrategies` or audit each theme by hand.

**Skills that conflict with your rules.** The imported skill packs recommend things a flat-design app forbids (shadows, translucent borders, glass, gradients, grain, background photos). The kit's checks never ask for those; where a skill's advice contradicts `RULES.md`, `RULES.md` wins and the finding should be reported as optional or dropped.

## Modes — `modes/<name>.json`
One file per mode. Fields: `name, group, order, title, summary, inputs[], skills[], defaults{}, auto[], steps[], verify[], checklist[], deliverables[], limits[], config{}`.
- `auto[]` runs on `kit.js run`; `verify[]` on `kit.js verify`. A step is `{ "id", "desc", "cmd", "check"?, "failOn"? }`.
- Placeholders in `cmd`: `{target}` `{built}` `{out}` `{kit}` and any `--arg key=value` (as `{key}`); `defaults` supplies fallbacks. A step with an unset placeholder is skipped and listed.
- `check: true` means exit code 1 = "issues found", not a tool failure.
- `config` overrides `audit.config.json` when used as `audit.js --mode <name>`.

**Add your own:** copy a JSON file, edit, run `node tools/kit.js list`.

## Profiles
`profiles/example-synek/` is a worked example of a filled-in app profile: rules, tokens, palette. Copy its structure for your app.
