#!/bin/sh
# Blocks a commit if staged .html files fail the chosen Audit-kit metrics.
# Install: cp Audit-kit/docs/examples/pre-commit.sh .git/hooks/pre-commit && chmod +x .git/hooks/pre-commit
FILES=$(git diff --cached --name-only --diff-filter=ACM | grep -E '\.html?$' | grep -v -E 'partial|template')
[ -z "$FILES" ] && exit 0
ROOT=$(git rev-parse --show-toplevel)
for f in $FILES; do
  node "$ROOT/Audit-kit/tools/audit.js" "$ROOT/$f" --no-mobile --out "${TMPDIR:-/tmp}/audit-precommit" --fail-on lowContrast,errors >/dev/null 2>&1 || { echo "Audit-kit: $f failed (lowContrast/errors). Run: node Audit-kit/tools/audit.js $f"; exit 1; }
done
