# Tools reference

All tools are plain Node scripts in `tools/`. Run from the `Audit-kit/` folder. Playwright must be installed (`sh tools/setup.sh`); set `CHROMIUM_PATH` to use an existing Chromium.

## kit.js — run a mode
```
node tools/kit.js list                              # all modes
node tools/kit.js show <mode>                       # full job description + checklist
node tools/kit.js index                             # markdown index of modes
node tools/kit.js run <mode> <target> [--out DIR] [--arg key=value ...]
node tools/kit.js verify <mode> <built-file> [--out DIR] [--arg key=value ...]
```
Writes `DIR/RUNBOOK.md` and `DIR/log/<step>.txt`. Step status: **OK**, **ISSUES FOUND** (the check ran and found problems), **FAILED** (the tool broke), **SKIPPED** (a needed `--arg` is missing).

## audit.js — measure one page
`node tools/audit.js <page|url> [more pages] --out DIR`
| flag | meaning |
|---|---|
| `--config FILE` | thresholds (default `audit.config.json`) |
| `--mode NAME` | apply `modes/NAME.json` `config` overrides |
| `--vars vars.json` | override CSS custom properties before measuring (theme experiments) |
| `--fail-on a,b,c` | exit 1 if any listed metric is above 0 (CI). Keys: `lowContrast underMin tap hScroll errors offGrid offToken flat placeholders a11y themeSwitch` and the static-check keys `mobile hoverGate motion reducedMotion typography copy` |
| `--no-mobile` | skip the mobile viewport |
| `--wait MS` | wait after load (async rendering) |
Also (config `staticChecks`, on by default; code in `tools/lib/checks.js`): mobile/touch rows (viewport zoom lock, inputs < `minInputPx`, `100vh` rules, `:hover` not inside `@media (hover: hover)`, safe-area vs `viewport-fit`), motion rows (`transition: all`, layout-property transitions, ease-in, > `maxUiMotionMs`, keyframes on layout properties, `scale(0)`, hover motion, missing `prefers-reduced-motion`), typography rows (numeric cells without `tabular-nums`, paragraph measure, orphaned last words) and copy rows (cliche/placeholder words, dead `#` links, wrapped CTAs, em-dashes). All are **heuristics read from the CSSOM and rendered DOM**; they add rows and `report.json` fields (`checks.*`) but never change the exit code unless named in `--fail-on`.

Measures per theme × viewport: font sizes, text contrast, gradient/rgba/shadow, horizontal scroll, tap targets, accessibility basics, placeholders, spacing grid, colour/radius/font inventory against your tokens, SVG colours, RTL text. Writes `report.md`, `report.json` and full-page PNGs.

## sweep.js — many pages
`node tools/sweep.js <start-url | folder | list.txt> [--depth 2] [--max 30] [--exclude REGEX] [--out DIR]`
Crawls same-origin links (URL), or takes every `.html` in a folder, or one path/URL per line (list). Runs `audit.js` per page, ranks them, and reports cross-page drift (font families, radii, colours). It does not log in.

## mobile-check.js — phone and touch rules (emilkowalski mobile-native)
`node tools/mobile-check.js <page|url> --out DIR [--width 390 --height 844]` — emulated phone (touch, DPR 3): viewport meta, layout width vs device, zoom lock, input font size, `100vh`, ungated `:hover`, `user-select:none` on body, safe area, horizontal scroll, tap size (info: 44px). Exit 1 = issues. Cannot reproduce sticky hover, tap delay, URL-bar/vh, keyboard (we tapped a hover-styled element in Chromium emulation and `:hover` did not stick); say what needs a real phone.

## motion-check.js — what animates (emilkowalski review-animations)
`node tools/motion-check.js <page|url> --out DIR [--max-ms 300] [--hover 25] [--clicks 12] [--click]` — static rules, observed hover behaviour, and a DRIVEN phase (arrow keys, scroll, clicks on up to `--clicks` safe controls; clicks are off for live URLs unless `--click`) that records transitions/animations that really start, including ones set by JavaScript at runtime: hovers up to `--hover` elements that have a transition and lists the transitions that really start (property, duration, easing); re-renders with `prefers-reduced-motion: reduce` and lists one-shot movement that remains (looping animations are listed separately, not counted). Exit 1 = findings. Frequency of use, purpose, origin, interruptibility and feel are not judged.

## break-data.js / worst-case.js — worst-case data (emilkowalski break-ui)
```
node tools/break-data.js <fixture.json | schema.json> --out DIR [--rows N] [--huge 1000] [--only a,b] [--skip nav,meta]
node tools/worst-case.js <page|url> --out DIR [--fixtures DIR] [--how hook|route|text] [--states worst,empty,one,huge] [--widths 1440,720,320]
                         [--route "GLOB=file.json|dotted.key"] [--only CSS] [--repeat CSS] [--times 1000] [--rtl]
```
`break-data.js` writes `demo/worst/empty/one/huge.json` and `manifest.md` (field, inferred kind, limit, values used, what they break) from the break-ui catalog; deterministic, `example.com` domains only. A schema (`{"fields": {"name": {"kind":"name","max":255}}}`) gives exact limits.
`worst-case.js` renders the page at each width and state and lists what is worse than the demo render: sideways scroll, clipped/truncated text, text spilling out of its box, controls pushed off-screen, squished avatars, wrapped badges, raw `NaN/undefined/null`, "1 members", missing empty state, DOM size. **Hook:** before page scripts run it defines `window.__AK_DATA__ = { state, data }`; your page reads it at its fixture boundary: `const data = (window.__AK_DATA__ && window.__AK_DATA__.data) || demoData;` (keep it dev-only). If the page never reads it the tool exits 2 instead of reporting a false "no findings". `--how route` answers network requests; `--how text` rewrites visible text with no code change (heuristic, stresses fixed UI copy too: use `--only`). Exit 1 = Broken or Ugly found (Fragile alone does not fail).

## variants.js — prototype switcher (emilkowalski prototype)
`node tools/variants.js <variants.json> --out DIR [--no-mobile]` — validates the set (2-5 variants, descriptive names, distinct axes), writes `picker.html` (flat one-at-a-time switcher, keys 1-5 / arrows / R / `#v=N`), tests it in Chromium, runs `audit.js` on every variant into one table and flags variants that occupy the same space (heuristic). Exit 1 = invalid set, broken picker or page error.

## completeness.js — was the output cut short? (taste-skill output-skill)
`node tools/completeness.js <file...> [--json] [--allow regex]` — placeholder comments (`// ...`, `// rest of code`, `<!-- ... -->`, TODO in comments), truncation prose ("for brevity"), `[PAUSED`, lorem ipsum, and structural truncation (no `</html>`, unbalanced tags/braces, inline script that does not compile). No browser needed. Exit 1 = findings.

## shot.js / compare.js / contact-sheet.js / md-card.js — images
```
node tools/shot.js <page> out.png [--theme dark|light] [--width N --height N] [--full] [--scale 2] [--selector CSS] [--vars vars.json]
node tools/compare.js before.png after.png out.png [--label-before X --label-after Y]
node tools/contact-sheet.js out.png a.png b.png … [--cols 3] [--labels a,b,c]
node tools/md-card.js report.md out.png [--title T] [--lines 3-24] [--light]    # markdown excerpt → clean image
```

## interact.js — keyboard, focus, hover, states
`node tools/interact.js <page> --out DIR [--tabs 60] [--states] [--theme dark|light]`
Tab order, keyboard traps, focus indicator, hover feedback, clickable-but-unreachable elements, and `--states` crops (default / hover / focus). Does not click or submit.

## rtl-check.js — right-to-left text
`node tools/rtl-check.js <page> --out DIR` — direction, bidi isolation, letter-spacing, middle dots, digit systems, small fonts. Heuristics; look at `rtl.png`.

## slides.js — decks
`node tools/slides.js <deck.html> --out DIR [--selector CSS] [--next-key ArrowRight|ArrowLeft] [--width 1920 --height 1080]` — renders every slide, per-slide min font and overflow, contact sheet. Handles decks that show one slide at a time.

## themes.js — theme variants
`node tools/themes.js <page> <themes.json> --out DIR` — themes.json = `{ "Name": {"--bg": "#…", …}, … }` (same variables in each). Renders and measures each theme, writes `summary.md` and `sheet.png`.

## Palettes and charts
```
node tools/validate_palette.mjs "#hex,#hex,…" --mode dark|light --surface "#hex" [--pairs all] [--ordinal]
node tools/validate-report.js DIR/report.json      # run the validator on SVG colours found by audit.js
node tools/palette-tools.js matrix|css|list <palette.json> [--max 24]
node tools/check-labels.js <page-with-svg.html>    # text overlap / overflow in every <svg>
node tools/compare-metrics.js before/report.json after/report.json [--labels A,B]
```
`validate_palette.mjs` checks lightness band, chroma, colour-blind distance (protan/deutan/tritan), normal-vision distance and contrast. `validate-report.js` guesses which SVG colours are chart series (drops greys and very light/dark tints); confirm by eye.

## Setup and checks
`sh tools/setup.sh` (install) · `sh tools/selftest.sh` (verifies tools run here).
