# Tools reference

All tools are plain Node scripts in `tools/`. Run from the `Audit-kit/` folder. Playwright must be installed (`sh tools/setup.sh`); set `CHROMIUM_PATH` to use an existing Chromium.

## kit.js — run a mode
```
node tools/kit.js list                              # all modes
node tools/kit.js show <mode>                       # full job description + checklist
node tools/kit.js index                             # markdown index of modes
node tools/kit.js run <mode> <target> [--out DIR] [--arg key=value ...]
node tools/kit.js verify <mode> <built-file> [--out DIR] [--arg key=value ...]
```
Writes `DIR/RUNBOOK.md` and `DIR/log/<step>.txt`. Step status: **OK**, **ISSUES FOUND** (the check ran and found problems), **FAILED** (the tool broke), **SKIPPED** (a needed `--arg` is missing).

## audit.js — measure one page
`node tools/audit.js <page|url> [more pages] --out DIR`
| flag | meaning |
|---|---|
| `--config FILE` | thresholds (default `audit.config.json`) |
| `--mode NAME` | apply `modes/NAME.json` `config` overrides |
| `--vars vars.json` | override CSS custom properties before measuring (theme experiments) |
| `--fail-on a,b,c` | exit 1 if any listed metric is above 0 (CI). Keys: `lowContrast underMin tap hScroll errors offGrid offToken flat placeholders a11y themeSwitch` |
| `--no-mobile` | skip the mobile viewport |
| `--wait MS` | wait after load (async rendering) |
Measures per theme × viewport: font sizes, text contrast, gradient/rgba/shadow, horizontal scroll, tap targets, accessibility basics, placeholders, spacing grid, colour/radius/font inventory against your tokens, SVG colours, RTL text. Writes `report.md`, `report.json` and full-page PNGs.

## sweep.js — many pages
`node tools/sweep.js <start-url | folder | list.txt> [--depth 2] [--max 30] [--exclude REGEX] [--out DIR]`
Crawls same-origin links (URL), or takes every `.html` in a folder, or one path/URL per line (list). Runs `audit.js` per page, ranks them, and reports cross-page drift (font families, radii, colours). It does not log in.

## shot.js / compare.js / contact-sheet.js / md-card.js — images
```
node tools/shot.js <page> out.png [--theme dark|light] [--width N --height N] [--full] [--scale 2] [--selector CSS] [--vars vars.json]
node tools/compare.js before.png after.png out.png [--label-before X --label-after Y]
node tools/contact-sheet.js out.png a.png b.png … [--cols 3] [--labels a,b,c]
node tools/md-card.js report.md out.png [--title T] [--lines 3-24] [--light]    # markdown excerpt → clean image
```

## interact.js — keyboard, focus, hover, states
`node tools/interact.js <page> --out DIR [--tabs 60] [--states] [--theme dark|light]`
Tab order, keyboard traps, focus indicator, hover feedback, clickable-but-unreachable elements, and `--states` crops (default / hover / focus). Does not click or submit.

## rtl-check.js — right-to-left text
`node tools/rtl-check.js <page> --out DIR` — direction, bidi isolation, letter-spacing, middle dots, digit systems, small fonts. Heuristics; look at `rtl.png`.

## slides.js — decks
`node tools/slides.js <deck.html> --out DIR [--selector CSS] [--next-key ArrowRight|ArrowLeft] [--width 1920 --height 1080]` — renders every slide, per-slide min font and overflow, contact sheet. Handles decks that show one slide at a time.

## themes.js — theme variants
`node tools/themes.js <page> <themes.json> --out DIR` — themes.json = `{ "Name": {"--bg": "#…", …}, … }` (same variables in each). Renders and measures each theme, writes `summary.md` and `sheet.png`.

## Palettes and charts
```
node tools/validate_palette.mjs "#hex,#hex,…" --mode dark|light --surface "#hex" [--pairs all] [--ordinal]
node tools/validate-report.js DIR/report.json      # run the validator on SVG colours found by audit.js
node tools/palette-tools.js matrix|css|list <palette.json> [--max 24]
node tools/check-labels.js <page-with-svg.html>    # text overlap / overflow in every <svg>
node tools/compare-metrics.js before/report.json after/report.json [--labels A,B]
```
`validate_palette.mjs` checks lightness band, chroma, colour-blind distance (protan/deutan/tritan), normal-vision distance and contrast. `validate-report.js` guesses which SVG colours are chart series (drops greys and very light/dark tints); confirm by eye.

## Setup and checks
`sh tools/setup.sh` (install) · `sh tools/selftest.sh` (verifies tools run here).
