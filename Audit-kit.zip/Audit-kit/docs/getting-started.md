# Getting started

## 1. Put the folder in your project
Copy `Audit-kit/` anywhere (repo root is fine). It needs nothing else from your repo.

## 2. Install the one dependency
```
cd Audit-kit
sh tools/setup.sh      # installs Playwright + Chromium next to the kit (needs network once)
sh tools/selftest.sh   # must end with: ALL OK
```
Node 18 or newer. No network? See [Limits & FAQ](limits-and-faq.md#offline).

## 3. Tell it your rules (5 minutes)
Open `RULES.md` and write what "correct" means for your app (theme, colour meaning, minimum text size, banned words). Put your design tokens file path in `audit.config.json` (`tokensFile`) so colours outside your palette are reported. Skipping this still works, but agents then judge against generic best practice and must say so.

## 4. Run your first mode
```
node tools/kit.js run quick-scan path/to/page.html --out out/qs
```
Open `out/qs/RUNBOOK.md`: automatic results first, then the checklist the agent (or you) completes. Screenshots are in `out/qs/audit/`.

## 5. Hand a job to an agent
Paste to any agent:
> Use Audit-kit mode `layout-redesign` on `<page>`. Folder: `<path to Audit-kit>`.

The agent reads `README.md`, `MODES.md`, `RULES.md`, runs `kit.js`, follows the RUNBOOK and returns the deliverables listed for that mode. Pick a mode in [The 17 modes](modes.md).

## What a run looks like
`kit.js run` → tools render every theme and viewport → measured report + screenshots → `RUNBOOK.md` (results + checklist) → agent writes the audit, claims tagged `[certain]` / `[likely]` / `[guess]`, ends with "Not verified".
