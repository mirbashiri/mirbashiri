# Audit-kit documentation

Audit-kit measures the quality of any app's pages (fonts, contrast, spacing, accessibility, charts, RTL…) and gives agents ready-made jobs for audits, redesigns and graphics. **Measure first, judge second.**

| read | when |
|---|---|
| [Getting started](getting-started.md) | first 10 minutes: install, check, first run |
| [The 17 modes](modes.md) | what each job does, with a real example image and the exact command |
| [Tools reference](tools.md) | every command-line tool and flag |
| [Configuration](configuration.md) | `RULES.md`, `audit.config.json`, token files, writing your own mode |
| [Connect it to GitHub](github.md) | run it on every pull request, fail the build on regressions, publish the landing page |
| [Evidence](evidence.md) | what was tested, with what result, and what was not |
| [Limits & FAQ](limits-and-faq.md) | what it cannot do |

Landing page: `index.html` in this folder (open locally, or publish with [GitHub Pages](github.md#publish-the-landing-page)).
