#!/usr/bin/env node
// Audit-kit versioning: starts at 1.00, every committed edit adds 0.01 (1.99 -> 2.00).
//   node tools/bump-version.js --note "what changed"      bump VERSION, add a CHANGELOG entry, update README/docs version markers
//   node tools/bump-version.js --check                    exit 1 if VERSION, CHANGELOG top entry, README and docs/index.html disagree
//   node tools/bump-version.js --verify-increment OLD     exit 1 unless VERSION == OLD + 0.01 (used by the pre-commit hook)
//   node tools/bump-version.js --show                     print the current version
// Markers updated: README.md and docs/README.md "<!-- ak-version -->vX.YY<!-- /ak-version -->", docs/index.html "<!--ak-version-->vX.YY<!--/ak-version-->" (any number of them).
const fs = require("fs"), path = require("path"), KIT = path.resolve(__dirname, ".."), a = process.argv.slice(2), opt = n => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : null; };
const rd = f => fs.readFileSync(path.join(KIT, f), "utf8"), wr = (f, s) => fs.writeFileSync(path.join(KIT, f), s), cents = v => { const m = String(v).trim().match(/^(\d+)\.(\d{2})$/); if (!m) { console.error(`bad version "${v}" (expected N.NN)`); process.exit(2); } return +m[1] * 100 + +m[2]; }, fmt = c => (Math.floor(c / 100)) + "." + String(c % 100).padStart(2, "0");
const markers = [["README.md", /(<!-- ak-version -->)v\d+\.\d{2}(<!-- \/ak-version -->)/g], ["docs/README.md", /(<!-- ak-version -->)v\d+\.\d{2}(<!-- \/ak-version -->)/g], ["docs/index.html", /(<!--ak-version-->)v\d+\.\d{2}(<!--\/ak-version-->)/g]];
const cur = rd("VERSION").trim();
if (a.includes("--show")) { console.log(cur); process.exit(0); }
if (a.includes("--verify-increment")) { const old = opt("--verify-increment"); if (cents(cur) === cents(old) + 1) { console.log(`version ${old} -> ${cur} ok`); process.exit(0); } console.error(`VERSION must be ${fmt(cents(old) + 1)} (+0.01 over ${old}), found ${cur}`); process.exit(1); }
if (a.includes("--check")) { let bad = []; const top = (rd("CHANGELOG.md").match(/^## v(\d+\.\d{2}) /m) || [])[1]; if (top !== cur) bad.push(`CHANGELOG top entry is ${top}, VERSION is ${cur}`); for (const [f, re] of markers) { const t = rd(f), found = [...t.matchAll(/v(\d+\.\d{2})<!--\s?\/ak-version\s?-->/g)].map(m => m[1]); if (!found.length) bad.push(`${f}: no version marker`); else if (found.some(v => v !== cur)) bad.push(`${f}: shows ${found.join(",")}, VERSION is ${cur}`); } if (bad.length) { console.error("version check FAILED:\n - " + bad.join("\n - ")); process.exit(1); } console.log(`version ${cur} consistent (VERSION, CHANGELOG, README, docs)`); process.exit(0); }
const note = opt("--note"); if (!note) { console.error('usage: node tools/bump-version.js --note "what changed" | --check | --show | --verify-increment OLD'); process.exit(2); }
const nv = fmt(cents(cur) + 1), day = new Date().toISOString().slice(0, 10);
wr("VERSION", nv + "\n");
let cl = rd("CHANGELOG.md"); const i = cl.search(/^## v/m); cl = cl.slice(0, i) + `## v${nv} — ${day} — ${note.replace(/\n/g, " ")}\n\n` + cl.slice(i); wr("CHANGELOG.md", cl);
const clItems = [...cl.matchAll(/^## v(\d+\.\d{2}) — (\d{4}-\d{2}-\d{2}) — (.*)$/gm)].slice(0, 8).map(m => `<li><b>v${m[1]}</b> ${m[2]}: ${m[3].replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</li>`).join("");
{ const t = rd("docs/index.html"); wr("docs/index.html", t.replace(/<!--ak-changelog-->[\s\S]*?<!--\/ak-changelog-->/, `<!--ak-changelog-->${clItems}<!--/ak-changelog-->`)); }
for (const [f, re] of markers) { if (!fs.existsSync(path.join(KIT, f))) continue; const t = rd(f); wr(f, t.replace(re, `$1v${nv}$2`)); }
console.log(`${cur} -> ${nv}`);
