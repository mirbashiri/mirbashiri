#!/usr/bin/env node
// Render a page/element to PNG.
// Usage: node tools/shot.js <page.html|url> <out.png> [--theme dark|light] [--width 1440] [--height 900] [--full] [--scale 2] [--selector CSS] [--vars vars.json] [--config FILE]
const path = require("path"), fs = require("fs"); let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found: sh tools/setup.sh"); process.exit(2); }
const a = process.argv.slice(2), opt = (n, d) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : d; }, [pg, out] = a.filter((x, i) => !x.startsWith("--") && !["--theme", "--width", "--height", "--config", "--scale", "--selector", "--vars"].includes(a[i - 1]));
if (!pg || !out) { console.error("usage: node tools/shot.js <page|url> <out.png> [--theme dark|light] [--width N] [--height N] [--full] [--scale N] [--selector CSS] [--vars vars.json]"); process.exit(2); }
let cfg = { themeStrategies: ["query", "attribute", "class", "emulate"], themeQueryParam: "theme", themeAttribute: "data-theme" }; try { cfg = { ...cfg, ...JSON.parse(fs.readFileSync(opt("--config", path.join(__dirname, "..", "audit.config.json")), "utf8")) }; } catch {}
let vars = {}; if (opt("--vars")) vars = JSON.parse(fs.readFileSync(opt("--vars"), "utf8"));
(async () => { const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}), theme = opt("--theme", null), p = await b.newPage({ viewport: { width: +opt("--width", 1440), height: +opt("--height", 900) }, deviceScaleFactor: +opt("--scale", 1) });
  let url = /^https?:\/\//.test(pg) ? pg : "file://" + path.resolve(pg); if (theme) { if (cfg.themeStrategies.includes("emulate")) await p.emulateMedia({ colorScheme: theme }); if (cfg.themeStrategies.includes("query")) url += (url.includes("?") ? "&" : "?") + cfg.themeQueryParam + "=" + theme; }
  await p.goto(url, { waitUntil: "load" }); await p.waitForTimeout(300);
  if (theme) { await p.evaluate(([S, at, th]) => { if (S.includes("attribute")) document.documentElement.setAttribute(at, th); if (S.includes("class")) [document.documentElement, document.body].forEach(e => { e.classList.remove("dark", "light"); e.classList.add(th); }); }, [cfg.themeStrategies, cfg.themeAttribute, theme]); }
  if (Object.keys(vars).length) await p.evaluate(v => { for (const el of [document.documentElement, document.body]) for (const [k, val] of Object.entries(v)) el.style.setProperty(k.startsWith("--") ? k : "--" + k, val); }, vars);
  await p.waitForTimeout(150); await p.evaluate(() => document.fonts && document.fonts.ready); fs.mkdirSync(path.dirname(path.resolve(out)), { recursive: true });
  if (opt("--selector")) { const el = await p.$(opt("--selector")); if (!el) { console.error("selector not found: " + opt("--selector")); await b.close(); process.exit(1); } await el.screenshot({ path: out }); } else await p.screenshot({ path: out, fullPage: process.argv.includes("--full") });
  await b.close(); console.log("saved " + out); })();
