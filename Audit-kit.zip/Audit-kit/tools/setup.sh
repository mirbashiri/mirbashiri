#!/bin/sh
# One-time setup: installs Playwright next to the kit (no global install needed) and Chromium.
# Needs network once. Offline? See README -> "Offline / no network".
set -e
cd "$(dirname "$0")/.."
node -e "process.exit(+process.versions.node.split('.')[0] >= 18 ? 0 : 1)" || { echo "Node >= 18 required (found $(node --version))"; exit 1; }
if node -e "require('playwright')" 2>/dev/null; then echo "playwright: already available"; else echo "installing playwright into $(pwd)/node_modules ..."; if ! npm install --no-audit --no-fund --fetch-timeout=20000 --fetch-retries=1 playwright; then echo "FAILED: npm could not install playwright (no network?). Offline options: see README -> Offline / no network"; exit 1; fi; fi
if [ -n "$PLAYWRIGHT_BROWSERS_PATH" ] && ls "$PLAYWRIGHT_BROWSERS_PATH" 2>/dev/null | grep -qi chrom; then echo "chromium: found in $PLAYWRIGHT_BROWSERS_PATH"; else echo "installing chromium ..."; npx playwright install chromium || { echo "FAILED: chromium download blocked. Set CHROMIUM_PATH to an existing Chromium (see README)"; exit 1; }; fi
echo "setup done. Next: sh tools/selftest.sh"
