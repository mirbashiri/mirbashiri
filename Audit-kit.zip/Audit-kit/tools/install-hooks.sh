#!/bin/sh
# Installs the Audit-kit versioning hook for this clone: git config core.hooksPath <kit>/hooks (relative to the repo root).
ROOT=$(git rev-parse --show-toplevel) || { echo "not inside a git repository"; exit 1; }
KIT=$(cd "$(dirname "$0")/.." && pwd)
REL=${KIT#"$ROOT"/}
chmod +x "$KIT/hooks/pre-commit"
git -C "$ROOT" config core.hooksPath "$REL/hooks" && echo "hooks installed: core.hooksPath=$REL/hooks (every commit that touches $REL gets version +0.01)"
