#!/usr/bin/env node
// RTL / Persian / Arabic checks on a rendered page. Usage: node tools/rtl-check.js <page|url> --out DIR [--min-font 12]
// Finds: missing html dir/lang, RTL text rendered LTR, Latin/digit runs inside RTL text without isolation (bidi reordering risk),
// letter-spacing on RTL text, middle dot "·" and mirrored comparison signs in RTL text, left-aligned RTL text, small RTL fonts,
// mixed digit systems (Persian/Arabic-Indic vs Latin) in one element, tabular-nums missing on numeric cells. Heuristics: confirm in the screenshot.
const path = require("path"), fs = require("fs"); let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found: sh tools/setup.sh"); process.exit(2); }
const a = process.argv.slice(2), opt = (n, d) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : d; }, vals = ["--out", "--min-font"], pg = a.find((x, i) => !x.startsWith("--") && !vals.includes(a[i - 1]));
if (!pg) { console.error("usage: node tools/rtl-check.js <page|url> --out DIR"); process.exit(2); }
const out = path.resolve(opt("--out", "rtl-out")), minFont = +opt("--min-font", 12); fs.mkdirSync(out, { recursive: true });
(async () => { const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}), p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  await p.goto(/^https?:\/\//.test(pg) ? pg : "file://" + path.resolve(pg), { waitUntil: "load" }); await p.waitForTimeout(400); await p.evaluate(() => document.fonts && document.fonts.ready);
  const r = await p.evaluate(minFont => {
    const RTL = /[֐-ࣿיִ-﷿ﹰ-﻿]/, vis = e => { const cs = getComputedStyle(e), r = e.getBoundingClientRect(); return cs.display !== "none" && cs.visibility !== "hidden" && r.width > 0 && r.height > 0; };
    const tag = e => e.tagName.toLowerCase() + (e.className && typeof e.className === "string" ? "." + e.className.trim().split(/\s+/)[0] : "");
    const els = [...document.body.querySelectorAll("*")].filter(e => !["SCRIPT", "STYLE", "SVG", "PATH"].includes(e.tagName.toUpperCase()) && [...e.childNodes].some(n => n.nodeType === 3 && RTL.test(n.textContent)) && vis(e));
    const ex = (l, n = 6) => [...new Set(l)].slice(0, n), res = { htmlDir: document.documentElement.dir || "(none)", htmlLang: document.documentElement.lang || "(none)", rtlElements: els.length, issues: {} }, add = (k, v) => (res.issues[k] = res.issues[k] || []).push(v);
    for (const e of els) { const cs = getComputedStyle(e), txt = e.textContent.trim().slice(0, 30), t = `${tag(e)} "${txt}"`;
      if (cs.direction !== "rtl") add("rtlTextRenderedLtr", t);
      if (cs.letterSpacing !== "normal" && parseFloat(cs.letterSpacing) !== 0) add("letterSpacing", t + " " + cs.letterSpacing);
      if (parseFloat(cs.fontSize) < minFont) add("underMinFont", t + " " + cs.fontSize);
      if (/·|•/.test(e.textContent)) add("middleDotInRtl", t);
      if (/[≥≤><]/.test(e.textContent)) add("comparisonSignsInRtl(check mirroring)", t);
      if (cs.direction === "rtl" && cs.textAlign === "left") add("rtlTextLeftAligned", t);
      const own = [...e.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join(" ");
      if (/[A-Za-z][A-Za-z0-9\-_.]{1,}/.test(own) && RTL.test(own) && cs.unicodeBidi === "normal" && !e.closest("bdi,[dir=ltr]")) add("latinRunInRtlNotIsolated", t);
      const fa = /[۰-۹]/.test(e.textContent), ar = /[٠-٩]/.test(e.textContent), la = /[0-9]/.test(e.textContent); if ((fa && la) || (fa && ar) || (ar && la)) add("mixedDigitSystems", t);
    }
    res.numericNoTabular = [...document.querySelectorAll("td,th,[class*=num],[class*=value]")].filter(e => vis(e) && /^[\s\-+−$€%.,\d۰-۹٠-٩]+$/.test(e.textContent.trim()) && e.textContent.trim().length > 1 && !/tabular-nums/.test(getComputedStyle(e).fontVariantNumeric)).length;
    for (const k in res.issues) res.issues[k] = { count: res.issues[k].length, examples: ex(res.issues[k]) }; return res; }, minFont);
  await p.screenshot({ path: path.join(out, "rtl.png"), fullPage: true }); await b.close(); fs.writeFileSync(path.join(out, "report.json"), JSON.stringify(r, null, 1));
  let md = `# RTL report — ${pg}\n\n- html dir: **${r.htmlDir}**, lang: **${r.htmlLang}** (RTL pages should set both)\n- elements with RTL text: **${r.rtlElements}**\n- numeric cells without tabular-nums: ${r.numericNoTabular}\n\n`;
  if (!r.rtlElements) md += "No Arabic/Persian/Hebrew text found: nothing to check.\n"; else if (!Object.keys(r.issues).length) md += "No RTL issues found by these heuristics. Still look at rtl.png (bidi order, bracket direction, number placement).\n"; else { md += "| issue | count | examples |\n|---|---|---|\n"; for (const [k, v] of Object.entries(r.issues)) md += `| ${k} | ${v.count} | ${v.examples.join("; ")} |\n`; }
  md += "\nHeuristics only: `latinRunInRtlNotIsolated` and `comparisonSigns` need a visual check. Rules: references/rtl-persian.md. Screenshot: rtl.png\n"; fs.writeFileSync(path.join(out, "report.md"), md); console.log(md); })();
