#!/usr/bin/env node
// Feeds a page worst-case data and reports what BREAKS compared with its normal (demo) render. From emilkowalski/skills "break-ui" (Phase 3-4).
//   node tools/worst-case.js <page|url> --out DIR [--fixtures DIR] [--how hook|route|text] [--states worst,empty,one,huge] [--widths 1440,720,320]
//        [--route "GLOB=file.json|dotted.key" ...] [--only CSS] [--repeat CSS] [--times 1000] [--rtl] [--wait 400]
// HOW THE DATA GETS IN (all three keep the component untouched: skill Hard Rule 2 "change the data, not the component"):
//  hook  (default when --fixtures is given): before the page's scripts run we set  window.__AK_DATA__ = { state: "worst", data: <DIR/worst.json> }.
//        Your page/app reads it at its fixture boundary, e.g.  const data = (window.__AK_DATA__ && window.__AK_DATA__.data) || demoData;
//        (dev-only: guard it with your dev flag so it never ships). Fixtures come from tools/break-data.js.
//  route: --route "**/api/members*=members" answers matching network requests with JSON: the value after "=" is a file path, or a dotted key inside the state's fixture.
//  text : no fixture, no code change: after load, visible text leaves are rewritten with worst-case shaped text (numbers get 8+ digits, names/labels get long realistic strings,
//        emails/URLs get long ones; --only CSS limits it to your data region). --repeat CSS (e.g. "tbody tr") drives empty / one / huge by removing or cloning those elements.
//        HEURISTIC: it cannot tell data from fixed UI copy, so it stresses both: prefer --only. It rewrites text nodes only, never markup or CSS.
// For each width x state it compares against the page's own demo render and lists regressions: page-level sideways scroll, text silently clipped, truncated with no way to read it,
// text spilling out of its box, actions pushed off-screen, squished avatars/icons (small fixed-size media, <= 128px in the demo, whose aspect ratio changed), wrapped badges/buttons, raw NaN/undefined/null/[object Object]/float noise,
// "1 members"-style plurals, a missing empty-state message, DOM size in the huge state. Severity: Broken / Ugly / Fragile (skill's scale). Exit code 1 = Broken or Ugly found.
// 200% zoom is approximated by the 720px width (1440/2); real browser zoom, images/404 avatars, locale formats, dark mode are NOT exercised. Everything here is a heuristic: confirm in the PNGs.
const path = require("path"), fs = require("fs"), cp = require("child_process"); let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found: sh tools/setup.sh"); process.exit(2); }
const a = process.argv.slice(2), opt = (n, d) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : d; }, optAll = n => a.flatMap((x, i) => x === n ? [a[i + 1]] : []), vals = ["--out", "--fixtures", "--how", "--states", "--widths", "--route", "--only", "--repeat", "--times", "--wait"], pg = a.find((x, i) => !x.startsWith("--") && !vals.includes(a[i - 1]));
if (!pg) { console.error("usage: node tools/worst-case.js <page|url> --out DIR [--fixtures DIR] [--how hook|route|text] [--states worst,empty,one,huge] [--widths 1440,720,320]"); process.exit(2); }
const out = path.resolve(opt("--out", "worst-out")), fx = opt("--fixtures") && path.resolve(opt("--fixtures")), how = opt("--how", fx ? "hook" : "text"), states = opt("--states", "worst,empty,one,huge").split(","), widths = opt("--widths", "1440,720,320").split(",").map(Number), routes = optAll("--route"), only = opt("--only", ""), repeat = opt("--repeat", ""), times = +opt("--times", 1000), wait = +opt("--wait", 400);
fs.mkdirSync(out, { recursive: true }); if (how !== "text" && !fx) { console.error("--how " + how + " needs --fixtures DIR (run tools/break-data.js first)"); process.exit(2); }
const url = /^https?:\/\//.test(pg) ? pg : "file://" + path.resolve(pg);
const load = s => JSON.parse(fs.readFileSync(path.join(fx, s + ".json"), "utf8"));
// ---------- in-page: text stressor (text method) ----------
const stressFn = ({ state, only, repeat, times }) => {
  const NAMES = ["Aleksandra Wiśniewska-Kowalczyk", "Christopher Alexander Montgomery III", "Konstantin Oberhauser-Wettstein", "María José de la Cruz y Fernández"], LABELS = ["Paramètres de confidentialité et de sécurité", "Benachrichtigungseinstellungen", "Invitation expired 12 days ago"];
  const rep = repeat ? [...document.querySelectorAll(repeat)] : [];
  if (state === "empty" || state === "one" || state === "huge") { if (!rep.length) return { note: "no --repeat elements: nothing to change for " + state }; const parents = new Map(); rep.forEach(e => { const p = e.parentElement; (parents.get(p) || parents.set(p, []).get(p)).push(e); });
    for (const [p, list] of parents) { if (state === "empty") list.forEach(e => e.remove()); else if (state === "one") list.slice(1).forEach(e => e.remove()); else { const last = list[list.length - 1]; for (let i = list.length; i < times; i++) { const c = list[i % list.length].cloneNode(true); last.after(c); } } } return { changed: rep.length }; }
  const scope = only ? [...document.querySelectorAll(only)] : [document.body], seen = new Set(), leaves = []; scope.forEach(s => (s.matches ? [s] : []).concat([...s.querySelectorAll("*")]).forEach(e => { if (seen.has(e) || /^(SCRIPT|STYLE|NOSCRIPT|SVG|PATH|OPTION|CODE|PRE)$/i.test(e.tagName)) return; seen.add(e); if (e.children.length === 0 && e.textContent.trim() && getComputedStyle(e).display !== "none") leaves.push(e); }));
  let n = 0, ni = 0, li = 0; for (const e of leaves) { const t = e.textContent.trim(); let r = null;
    if (/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(t)) r = "bartholomew.fitzgerald@northwind-industries-holdings.example.com";
    else if (/^https?:\/\//i.test(t)) r = "https://example.com/workspaces/acme/projects/q3-launch/docs/9f8e7d6c5b4a?tab=comments&filter=unresolved";
    else if (/^[^\d]*[\d][\d.,\s]*[^\d]*$/.test(t) && /\d/.test(t) && t.length <= 20) { const m = t.match(/^(\D*?)([\d][\d.,]*)(\D*)$/); if (m) { const sep = /,/.test(m[2]), pct = /%/.test(m[3]); r = m[1] + (pct ? "142.5" : sep ? "12,345,678.90" : "12345678.9") + m[3]; } }
    else if (/^[A-Z0-9][A-Z0-9._-]{0,9}$/.test(t)) r = null;
    else if (t.length <= 3 && !/\s/.test(t)) r = null;
    else if (/^\p{Lu}[\p{L}'’.-]+(\s+\p{Lu}[\p{L}'’.-]+){1,2}$/u.test(t) && t.length < 32) r = NAMES[ni++ % NAMES.length];
    else if (t.length <= 28) r = LABELS[li++ % LABELS.length];
    else if (t.length < 160) r = t + " " + t;
    if (r !== null && r !== t) { const tn = [...e.childNodes].find(x => x.nodeType === 3 && x.textContent.trim()); if (tn) { tn.textContent = r; n++; } } }
  return { changed: n };
};
// ---------- in-page: probe ----------
const probeFn = () => {
  const vis = e => { const cs = getComputedStyle(e); return cs.display !== "none" && cs.visibility !== "hidden"; }, keyOf = e => { const p = []; let x = e; while (x && x !== document.body) { p.push(x.tagName.toLowerCase() + ":" + ([...x.parentElement.children].indexOf(x) + 1)); x = x.parentElement; } return p.reverse().join(">"); };
  const BAD = /^(SCRIPT|STYLE|NOSCRIPT|HEAD|META|LINK|TITLE|PATH|G|DEFS|TSPAN|BR)$/i, els = [...document.body.querySelectorAll("*")].filter(e => !BAD.test(e.tagName) && vis(e)).slice(0, 3500);
  const lines = e => { const tops = []; for (const n of e.childNodes) if (n.nodeType === 3 && n.textContent.trim()) { const r = document.createRange(); r.selectNodeContents(n); for (const b of r.getClientRects()) if (b.width > 0) tops.push(b.top); } if (!tops.length) return 0; tops.sort((x, y) => x - y); const lh = parseFloat(getComputedStyle(e).lineHeight) || parseFloat(getComputedStyle(e).fontSize) * 1.3; let c = 1, last = tops[0]; for (const t of tops) if (t - last > lh * 0.6) { c++; last = t; } return c; };
  const rec = els.map(e => { const cs = getComputedStyle(e), r = e.getBoundingClientRect(), own = [...e.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join("").trim(), p = e.parentElement, pr = p ? p.getBoundingClientRect() : null, pcs = p ? getComputedStyle(p) : null, cls = typeof e.className === "string" ? e.className : "";
    return { k: keyOf(e), tag: e.tagName.toLowerCase(), cls: cls.trim().split(/\s+/)[0] || "", x: Math.round(r.left + scrollX), y: Math.round(r.top + scrollY), w: Math.round(r.width * 10) / 10, h: Math.round(r.height * 10) / 10, own: own.slice(0, 70), sw: e.scrollWidth, cw: e.clientWidth, ov: cs.overflowX, to: cs.textOverflow, title: !!(e.getAttribute("title") || e.getAttribute("aria-label")), inter: /^(A|BUTTON|INPUT|SELECT|TEXTAREA|SUMMARY)$/.test(e.tagName) || e.getAttribute("role") === "button" || e.hasAttribute("tabindex"), media: /^(IMG|SVG|CANVAS|VIDEO)$/i.test(e.tagName) || /avatar|icon|logo|thumb|photo|portrait/i.test(cls), badge: /badge|tag|chip|pill|status|btn|button/i.test(cls) || e.tagName === "BUTTON", lines: own ? lines(e) : 0, pr: pr ? Math.round(pr.right * 10) / 10 : null, pov: pcs ? pcs.overflowX : "visible", disp: cs.display }; });
  return { els: rec, sw: document.documentElement.scrollWidth, iw: innerWidth, sh: document.documentElement.scrollHeight, nodes: document.querySelectorAll("*").length, text: document.body.innerText.slice(0, 200000) };
};
// ---------- comparison ----------
const FIX = { squish: "flex-shrink: 0 on the avatar, icon and any fixed-size box", clip: "min-width: 0 on the flex/grid text column (minmax(0, 1fr)); overflow-wrap: anywhere on the string; or wrap instead of overflow:hidden", spill: "min-width: 0 on the text column; overflow-wrap: anywhere on that element", off: "min-width: 0 on the middle content, flex-shrink: 0 on the trailing action", badge: "white-space: nowrap; flex-shrink: 0 on the badge, and decide what yields instead", trunc: "title attribute or tooltip, and the full value elsewhere (detail view)", raw: "guard null/undefined; Intl.NumberFormat for numbers; never render raw values", plural: "Intl.PluralRules or separate strings per count", empty: "an empty state that says what to do next", hscroll: "find the widest element (see the other rows): min-width: 0 / overflow-wrap", dom: "virtualize or paginate, and say which" };
const sel = e => e.tag + (e.cls ? "." + e.cls : "");
function compare(base, st, state, width) {
  const F = [], bk = new Map(base.els.map(e => [e.k, e])), add = (sev, type, e, what, val) => F.push({ sev, type, where: e ? sel(e) : "page", value: val || (e ? e.own : ""), what, fix: FIX[type], state, width });
  if (st.sw > st.iw + 1 && st.sw > base.sw + 1) add("Broken", "hscroll", null, base.sw > base.iw + 1 ? `page already scrolled sideways in the demo (${base.sw}px) and gets wider (${st.sw}px of ${st.iw}px)` : `page scrolls sideways (scrollWidth ${st.sw}px > ${st.iw}px)`, "");
  for (const e of st.els) { const b = bk.get(e.k), hasText = !!e.own;
    if (hasText && e.sw > e.cw + 1 && /hidden|clip/.test(e.ov) && !(b && b.sw > b.cw + 1)) { if (e.to === "ellipsis") { if (!e.title) add("Fragile", "trunc", e, `truncated with an ellipsis (${e.sw}px of text in ${e.cw}px) and no title/aria-label`); } else add("Broken", "clip", e, `text cut off silently (${e.sw}px of text in ${e.cw}px box, overflow ${e.ov})`); }
    if (hasText && e.pr != null && e.x + e.w > e.pr + 1.5 && /visible/.test(e.pov) && e.disp !== "inline" && !(b && b.x + b.w > b.pr + 1.5) && e.w > 0) add("Ugly", "spill", e, `text runs ${Math.round(e.x + e.w - e.pr)}px past its container`);
    if (e.inter && (e.x + e.w > st.iw + 1 || e.x < -1) && !(b && !(b.x + b.w > base.iw + 1 || b.x < -1))) add("Broken", "off", e, `control is outside the viewport (right edge ${Math.round(e.x + e.w)}px of ${st.iw}px)`, e.own || "(icon button)");
    if (e.media && b && b.w > 0 && b.h > 0 && e.h > 0 && Math.max(b.w, b.h) <= 128) { const r0 = b.w / b.h, r1 = e.w / e.h; if (Math.abs(r1 - r0) / r0 > 0.08) add("Ugly", "squish", e, `aspect ratio changed ${r0.toFixed(2)} -> ${r1.toFixed(2)} (${b.w}x${b.h} -> ${e.w}x${e.h})`, ""); }
    if (e.badge && hasText && e.lines > 1 && !(b && b.lines > 1)) add("Ugly", "badge", e, `wraps onto ${e.lines} lines`); }
  const raw = st.text.match(/\b(NaN|undefined|null|\[object Object\]|Infinity)\b|\d\.\d{9,}/g) || [], rawBase = base.text.match(/\b(NaN|undefined|null|\[object Object\]|Infinity)\b|\d\.\d{9,}/g) || [];
  if (raw.length > rawBase.length) add("Broken", "raw", null, `${raw.length - rawBase.length} raw value(s) rendered as text`, [...new Set(raw)].slice(0, 4).join(", "));
  const pl = (st.text.match(/\b1 [A-Za-z]{3,}s\b/g) || []).filter(x => !base.text.includes(x)); if (pl.length) add("Ugly", "plural", null, "singular count with a plural noun", [...new Set(pl)].join(", "));
  if (state === "empty") { const had = base.text.length, now = st.text.length; if (now < had * 0.9 && !/\b(no |nothing|empty|none|yet|not found|get started|add |invite|create)/i.test(st.text.replace(base.text, ""))) add("Fragile", "empty", null, "list emptied and no new empty-state message appeared (looked for no/nothing/empty/none/yet/add/invite/create in the new text)"); }
  if (state === "huge" && st.nodes > 5000) add("Fragile", "dom", null, `${st.nodes} DOM nodes (demo: ${base.nodes}); page height ${st.sh}px`);
  return F;
}
(async () => {
  const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}), all = [], shots = [], held = [], baseNotes = [], hookUnread = new Set();
  const open = async (w, state) => { const p = await b.newPage({ viewport: { width: w, height: 900 } }), errs = []; p.on("pageerror", e => errs.push(String(e)));
    if (state !== "demo" && how === "hook") await p.addInitScript(([s, d]) => { const v = { state: s, data: d }; Object.defineProperty(window, "__AK_DATA__", { configurable: true, get() { window.__AK_READ__ = true; return v; } }); window.__AK_STATE__ = s; }, [state, load(state)]);
    if (state !== "demo" && (how === "route" || routes.length)) for (const r of routes) { const i = r.lastIndexOf("="), glob = r.slice(0, i), v = r.slice(i + 1); let body; if (fs.existsSync(v)) body = JSON.parse(fs.readFileSync(v, "utf8")); else { body = load(state); for (const k of v.split(".").filter(Boolean)) body = body && body[k]; } await p.route(glob, route => route.fulfill({ json: body })); }
    await p.goto(url, { waitUntil: "load" }).catch(e => errs.push("goto " + e.message)); await p.waitForTimeout(wait);
    if (state !== "demo" && how === "text") await p.evaluate(`(${stressFn.toString()})(${JSON.stringify({ state, only, repeat, times })})`);
    await p.waitForTimeout(150); if (state !== "demo" && how === "hook" && !(await p.evaluate(() => !!window.__AK_READ__))) hookUnread.add(state); return { p, errs }; };
  for (const w of widths) {
    const { p: bp } = await open(w, "demo"); const base = await bp.evaluate(`(${probeFn.toString()})()`); await bp.close(); if (base.sw > base.iw + 1) baseNotes.push(`demo render at ${w}px already scrolls sideways (${base.sw}px): fix this first, it is not caused by the worst-case data`);
    const runs = states.map(s => [s, false]); if (a.includes("--rtl") && w === widths[Math.min(1, widths.length - 1)]) runs.push(["worst", true]);
    for (const [s, rtl] of runs) { if (how === "hook" && !fs.existsSync(path.join(fx, s + ".json"))) { console.error("missing fixture " + s + ".json"); continue; }
      const { p, errs } = await open(w, s); if (rtl) await p.evaluate(() => { document.documentElement.dir = "rtl"; }); await p.waitForTimeout(100);
      const st = await p.evaluate(`(${probeFn.toString()})()`), label = rtl ? "worst+rtl" : s, f = compare(base, st, label, w); errs.forEach(e => f.push({ sev: "Broken", type: "error", where: "page", value: e.slice(0, 80), what: "page error while rendering this state", fix: "guard against missing fields (null checks) at the render boundary", state: label, width: w }));
      const shot = path.join(out, `${label.replace("+", "-")}-${w}.png`); await p.screenshot({ path: shot, fullPage: s !== "huge" }); shots.push([`${label} ${w}`, shot]); await p.close(); all.push(...f); if (!f.length) held.push(`${label} @${w}px`); }
  }
  await b.close();
  if (hookUnread.size) { const m = `# Worst-case report: HOOK NOT USED\n\nThe page never read window.__AK_DATA__ in state(s) ${[...hookUnread].join(", ")}, so the fixtures were NOT applied and any "no findings" would be meaningless. Wire the page (const data = (window.__AK_DATA__ && window.__AK_DATA__.data) || demoData;), or use --how text / --route.\n`; fs.writeFileSync(path.join(out, "report.md"), m); console.log(m); process.exit(2); }
  // aggregate identical findings
  const groups = new Map(); for (const f of all) { const key = [f.sev, f.type, f.where].join("|"); const g = groups.get(key) || { ...f, n: 0, at: new Set(), vals: [], per: {} }, rk = `${f.state}@${f.width}`; g.per[rk] = (g.per[rk] || 0) + 1; g.n = Math.max(...Object.values(g.per)); g.at.add(rk); if (f.value && g.vals.length < 2 && !g.vals.includes(f.value)) g.vals.push(f.value); groups.set(key, g); }
  const rank = { Broken: 0, Ugly: 1, Fragile: 2 }, rows = [...groups.values()].sort((x, y) => rank[x.sev] - rank[y.sev] || y.n - x.n);
  let md = `# Worst-case report — ${pg}\n\nMethod: **${how}**${fx ? ` (fixtures ${fx})` : ""}${only ? `, only ${only}` : ""}${repeat ? `, repeat ${repeat}` : ""} · states: ${states.join(", ")}${a.includes("--rtl") ? ", worst+rtl" : ""} · widths: ${widths.join(", ")}px (720px ~ 200% zoom). Compared with the page's own demo render at each width.\n\n`;
  md += rows.length ? `## Part 1: what broke (worst first)\n\n| # | Severity | Where | Worst-case value | What happens | Seen in | Fix (skill signature table) |\n|---|---|---|---|---|---|---|\n` + rows.map((g, i) => `| ${i + 1} | ${g.sev} | \`${g.where}\`${g.n > 1 ? ` (up to ${g.n} per render)` : ""} | ${g.vals.map(v => "`" + String(v).replace(/\|/g, "/") + "`").join(", ") || "-"} | ${g.what} | ${[...g.at].slice(0, 4).join(", ")}${g.at.size > 4 ? ", ..." : ""} | ${g.fix || ""} |`).join("\n") + "\n" : "## Part 1: what broke\n\nNothing detected by these heuristics in the exercised states.\n";
  if (baseNotes.length) md += `\n**Already broken in the demo render (not counted above):**\n` + baseNotes.map(x => "- " + x).join("\n") + "\n";
  md += `\n## Part 3: what held up\n${held.length ? held.map(x => "- " + x + ": no regression vs demo").join("\n") : "- (every exercised state had at least one finding)"}\n\nSeverity: **Broken** = content unreadable/cut, action unreachable, wrong value shown. **Ugly** = readable but visibly wrong. **Fragile** = fine now, one step from breaking. Part 2 (decisions: truncate vs wrap, empty-field text) is for you: see the mode checklist.\n\n**Not exercised:** broken-image avatars, loading/error states, locale number formats, relative-time text, dark mode, real browser zoom, user-generated HTML. Screenshots: ${out}/<state>-<width>.png\n`;
  fs.writeFileSync(path.join(out, "report.md"), md); fs.writeFileSync(path.join(out, "report.json"), JSON.stringify({ page: pg, how, states, widths, findings: rows.map(g => ({ sev: g.sev, type: g.type, where: g.where, count: g.n, values: g.vals, what: g.what, seen: [...g.at] })), held }, null, 1));
  const narrow = shots.filter(s => s[0].endsWith(" " + Math.min(...widths))).map(s => s); if (narrow.length > 1) cp.spawnSync("node", [path.join(__dirname, "contact-sheet.js"), path.join(out, "sheet.png"), ...narrow.map(s => s[1]), "--cols", String(Math.min(narrow.length, 5)), "--labels", narrow.map(s => s[0]).join(",")], { stdio: "ignore" });
  console.log(md); process.exit(rows.some(g => g.sev !== "Fragile") ? 1 : 0);
})();
