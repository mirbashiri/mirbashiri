#!/usr/bin/env node
// Motion audit from emilkowalski/skills "review-animations" (+STANDARDS.md): lists what animates and checks it against the skill's measurable rules. Usage:
//   node tools/motion-check.js <page|url> --out DIR [--max-ms 300] [--hover 25] [--config FILE]
// STATIC (CSSOM + computed style, tools/lib/checks.js): `transition: all`, transitions/keyframes on layout properties (width/height/margin/padding/top/left...),
//   ease-in on UI, durations above --max-ms (skill: "UI animations stay under 300ms"; infinite loops such as spinners are not counted), uniform scale(0),
//   :hover rules that move things but are not inside @media (hover: hover), and no @media (prefers-reduced-motion) rule at all while motion exists.
// OBSERVED (real browser): hovers up to --hover elements that have a transition and records the CSSTransition objects that actually start
//   (property, duration, easing) via element.getAnimations(); then reloads with prefers-reduced-motion: reduce and reports what still MOVES
//   (transform/translate/scale/rotate/top/left/... keyframes on running animations or hover transitions) - the skill says reduced motion keeps opacity/colour and drops movement.
// HEURISTIC / LIMITS: cannot know how often an element is used (the skill's frequency rule: keyboard/100+ per day => no animation), whether the origin of a popover is
//   right, whether motion is justified, or how it FEELS (skill: check in slow motion / frame by frame / on a device). Those stay manual: see the mode checklist.
//   Hover is exercised only on elements that already have a transition; JS-driven (rAF, Web Animations started by script) motion is seen only if running at load.
// Exit code 1 = at least one issue found (check semantics).
const path = require("path"), fs = require("fs"); let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found: sh tools/setup.sh"); process.exit(2); }
const { runStatic } = require("./lib/run-checks.js");
const a = process.argv.slice(2), opt = (n, d) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : d; }, vals = ["--out", "--max-ms", "--hover", "--config"], pg = a.find((x, i) => !x.startsWith("--") && !vals.includes(a[i - 1]));
if (!pg) { console.error("usage: node tools/motion-check.js <page|url> --out DIR [--max-ms 300] [--hover 25]"); process.exit(2); }
let cfg = { minTapPx: 24, minInputPx: 16, maxUiMotionMs: 300, maxMeasureCh: 80 }; try { cfg = { ...cfg, ...JSON.parse(fs.readFileSync(opt("--config", path.join(__dirname, "..", "audit.config.json")), "utf8")) }; } catch {}
if (opt("--max-ms")) cfg.maxUiMotionMs = +opt("--max-ms");
const out = path.resolve(opt("--out", "motion-out")), nHover = +opt("--hover", 25); fs.mkdirSync(out, { recursive: true });
const url = /^https?:\/\//.test(pg) ? pg : "file://" + path.resolve(pg), MOVE = /^(transform|translate|scale|rotate|top|left|right|bottom|inset.*|margin.*|width|height)$/;
const running = () => document.getAnimations().map(an => { const ef = an.effect, t = ef && ef.getTiming ? ef.getTiming() : {}, kf = ef && ef.getKeyframes ? ef.getKeyframes() : [], props = new Set(); kf.forEach(k => Object.keys(k).forEach(p => { if (!["offset", "easing", "composite", "computedOffset"].includes(p)) props.add(p); }));
  return { kind: an.constructor.name, prop: an.transitionProperty || an.animationName || "", props: [...props], duration: t.duration, iterations: t.iterations === Infinity ? "infinite" : t.iterations, easing: t.easing, target: ef && ef.target ? (ef.target.tagName.toLowerCase() + (typeof ef.target.className === "string" && ef.target.className.trim() ? "." + ef.target.className.trim().split(/\s+/)[0] : "")) : "" }; });
(async () => {
  const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  const run = async reduced => {
    const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: reduced ? "reduce" : "no-preference" }), p = await ctx.newPage(); await p.goto(url, { waitUntil: "load" }).catch(() => {}); await p.waitForTimeout(500);
    const atLoad = await p.evaluate(running), stat = reduced ? null : await runStatic(p, cfg);
    const cand = await p.evaluate(() => { const vis = e => { const cs = getComputedStyle(e), r = e.getBoundingClientRect(); return cs.display !== "none" && cs.visibility !== "hidden" && r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < innerHeight * 3; }; const seen = new Set(), out = [];
      [...document.querySelectorAll("body *")].forEach((e, i) => { const cs = getComputedStyle(e); if (!vis(e) || !cs.transitionDuration.split(",").some(d => parseFloat(d) > 0)) return; const k = e.tagName + "." + (typeof e.className === "string" ? e.className : ""); if (seen.has(k)) return; seen.add(k); e.setAttribute("data-mc", String(out.length)); out.push(k); }); return out; });
    const hovered = []; for (let i = 0; i < Math.min(cand.length, nHover); i++) { const h = await p.$(`[data-mc="${i}"]`); if (!h) continue; await h.scrollIntoViewIfNeeded().catch(() => {}); await p.mouse.move(0, 0); await p.waitForTimeout(40); await h.hover({ timeout: 1500 }).catch(() => {}); await p.waitForTimeout(25); const an = await h.evaluate(e => e.getAnimations({ subtree: false }).map(an => ({ kind: an.constructor.name, prop: an.transitionProperty || an.animationName || "", dur: an.effect.getTiming().duration, easing: an.effect.getTiming().easing }))); hovered.push({ el: cand[i], started: an }); }
    await ctx.close(); return { atLoad, stat, hovered, candidates: cand.length };
  };
  const normal = await run(false), reduced = await run(true); await b.close();
  const st = normal.stat.motion, moves = reduced.atLoad.filter(x => x.iterations !== "infinite" && (x.props.some(pp => MOVE.test(pp)) || MOVE.test(x.prop))), loopMoves = reduced.atLoad.filter(x => x.iterations === "infinite" && (x.props.some(pp => MOVE.test(pp)) || MOVE.test(x.prop))).map(x => `${x.target} ${x.prop}`), movesHover = reduced.hovered.flatMap(h => h.started.filter(s => MOVE.test(s.prop)).map(s => `${h.el} ${s.prop}`));
  const loopsNormal = normal.atLoad.filter(x => x.iterations === "infinite").length, loopsReduced = reduced.atLoad.filter(x => x.iterations === "infinite").length;
  const observedLong = normal.hovered.flatMap(h => h.started.filter(s => s.dur > cfg.maxUiMotionMs).map(s => `${h.el} ${s.prop} ${Math.round(s.dur)}ms`));
  const rows = [
    ["no `transition: all`", st.transitionAll, st.transitionAllExamples], ["no layout-property transitions", st.layoutProps, st.layoutPropsExamples], ["no ease-in on UI", st.easeIn, st.easeInExamples],
    [`finite durations <= ${cfg.maxUiMotionMs}ms`, st.overMax, st.overMaxExamples], ["no keyframes on layout properties", st.keyframesLayout, st.keyframesLayoutExamples], ["no uniform scale(0)", st.scale0, st.scale0Examples],
    ["hover motion gated by (hover: hover)", st.hoverMotionUngated, st.hoverMotionUngatedExamples], ["prefers-reduced-motion rule exists when motion exists", st.reducedMotionMissing ? 1 : 0, st.reducedMotionMissing ? ["no @media (prefers-reduced-motion) rule found"] : []],
    ["no one-shot movement left under prefers-reduced-motion (observed; loops listed below, not counted)", moves.length + movesHover.length, [...moves.map(x => `${x.target} ${x.prop || x.props.join("+")} (${x.iterations === "infinite" ? "loop" : x.duration + "ms"})`), ...movesHover].slice(0, 6)]];
  const issues = rows.filter(r => r[1] > 0).length;
  let md = `# Motion check — ${pg}\n\n**${issues} of ${rows.length} rules have findings.** Thresholds: UI motion <= ${cfg.maxUiMotionMs}ms (skill: "UI animations stay under 300ms").\n\n| rule (skill STANDARDS) | count | examples |\n|---|---|---|\n` + rows.map(r => `| ${r[0]} | ${r[1] > 0 ? "**" + r[1] + "**" : "0"} | ${r[2].join("; ") || "-"} |`).join("\n") +
    `\n\n## What animates (inventory)\n- Declared transitions with duration > 0: **${st.transitions}**; keyframe animations running at load: **${st.animationsFinite}** finite + **${st.animationsInfinite}** infinite (loops such as spinners).\n- Elements with a transition: ${normal.candidates}; hovered ${normal.hovered.length} (cap --hover ${nHover}). Transitions actually started on hover:\n` +
    (normal.hovered.filter(h => h.started.length).map(h => `  - ${h.el}: ${h.started.map(s => `${s.prop} ${Math.round(s.dur)}ms ${s.easing}`).join(", ")}`).join("\n") || "  - (none started)") +
    `\n- Observed hover transitions longer than ${cfg.maxUiMotionMs}ms: ${observedLong.length ? observedLong.join("; ") : "none"}.\n\n## prefers-reduced-motion (observed in a second render with reduce)\n- Looping animations at load: ${loopsNormal} normal -> ${loopsReduced} reduced. Animations still running at load: ${normal.atLoad.length} -> ${reduced.atLoad.length}. Hover transitions started: ${normal.hovered.reduce((n, h) => n + h.started.length, 0)} -> ${reduced.hovered.reduce((n, h) => n + h.started.length, 0)}.\n- Looping movement still running under reduce: ${loopMoves.length ? loopMoves.join('; ') : 'none'} (not counted: a loading indicator may be legitimate; confirm it is one).\n- Skill: reduced motion means fewer/gentler animations, **not zero**: keep opacity/colour feedback, drop movement.\n` +
    (normal.stat.css.unreadable ? `\n> ${normal.stat.css.unreadable} stylesheet(s) unreadable through the CSSOM: rule-based findings may be incomplete.\n` : "") +
    `\n**Not judged by this tool (manual, see mode checklist):** is each animation justified; frequency (keyboard / 100+ per day => none); transform-origin of popovers; interruptibility (keyframes vs transitions for rapid triggers); asymmetric press/release timing; stagger; cohesion; how it feels (slow-motion / frame-by-frame / real device).\n`;
  fs.writeFileSync(path.join(out, "report.md"), md); fs.writeFileSync(path.join(out, "report.json"), JSON.stringify({ page: pg, maxMs: cfg.maxUiMotionMs, static: st, hovered: normal.hovered, reduced: { atLoad: reduced.atLoad, hovered: reduced.hovered }, issues }, null, 1)); console.log(md); process.exit(issues ? 1 : 0);
})();
