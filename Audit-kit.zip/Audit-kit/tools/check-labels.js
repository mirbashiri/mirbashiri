// Label checker for skills-lab tests: text/text overlaps, text overflowing its box (data-box="id" on <text>, id on <rect>),
// text leaving the viewBox, and Persian text under 11.5px. Usage: NODE_PATH=$(npm root -g) node tools/check-labels.js <file.html> [...]
const path = require("path"), { chromium } = require("playwright");
(async () => {
  const b = await chromium.launch(); let fail = 0;
  for (const f of process.argv.slice(2)) {
    const p = await b.newPage({ viewport: { width: 1400, height: 900 } }); await p.goto("file://" + path.resolve(f)); await p.evaluate(() => document.fonts.ready);
    const r = await p.evaluate(() => {
      const svg = document.querySelector("svg"), vb = svg.viewBox.baseVal, out = [], T = [...svg.querySelectorAll("text")].map(t => ({ t, s: t.textContent.trim(), b: t.getBBox(), fa: /[؀-ۿ]/.test(t.textContent) }));
      const hit = (a, c, pad = 1) => a.x < c.x + c.width - pad && c.x < a.x + a.width - pad && a.y < c.y + c.height - pad && c.y < a.y + a.height - pad;
      for (let i = 0; i < T.length; i++) for (let j = i + 1; j < T.length; j++) if (hit(T[i].b, T[j].b)) out.push(`overlap: "${T[i].s}" × "${T[j].s}"`);
      for (const x of T) {
        if (x.b.x < vb.x || x.b.y < vb.y || x.b.x + x.b.width > vb.x + vb.width || x.b.y + x.b.height > vb.y + vb.height) out.push(`outside viewBox: "${x.s}"`);
        const fs = parseFloat(getComputedStyle(x.t).fontSize); if (x.fa && fs < 11.5) out.push(`persian under 11.5px (${fs}): "${x.s}"`);
        const id = x.t.getAttribute("data-box"); if (id) { const r = document.getElementById(id).getBBox(); if (x.b.x < r.x + 2 || x.b.x + x.b.width > r.x + r.width - 2) out.push(`overflows box ${id}: "${x.s}"`); }
      }
      for (const el of svg.querySelectorAll("rect[id]")) { const r = el.getBBox(); if (r.x < vb.x || r.y < vb.y || r.x + r.width > vb.x + vb.width || r.y + r.height > vb.y + vb.height) out.push(`box outside viewBox: #${el.id}`); }
      return { n: T.length, out };
    });
    console.log(`${path.basename(f)}: ${r.n} labels, ${r.out.length} problems`); r.out.forEach(m => console.log("  - " + m)); fail += r.out.length; await p.close();
  }
  await b.close(); process.exit(fail ? 1 : 0);
})();
