// Label checker (screen-space, all <svg> on the page): text/text overlaps, text overflowing its box (data-box="id" on <text>, id on <rect>),
// text leaving the viewBox, and Persian text under 11.5px. Usage: NODE_PATH=$(npm root -g) node tools/check-labels.js <file.html> [...]
const path = require("path"), { chromium } = require("playwright");
(async () => {
  const b = await chromium.launch(); let fail = 0;
  for (const f of process.argv.slice(2)) {
    const p = await b.newPage({ viewport: { width: 1400, height: 900 } }); await p.goto("file://" + path.resolve(f)); await p.evaluate(() => document.fonts.ready);
    const r = await p.evaluate(() => {
      // Screen-space geometry (getBoundingClientRect) so transforms/nested groups do not cause false positives. Checks every <svg> with text.
      const out = []; let n = 0; const hit = (a, c, pad = 1) => a.left < c.right - pad && c.left < a.right - pad && a.top < c.bottom - pad && c.top < a.bottom - pad;
      [...document.querySelectorAll("svg")].forEach((svg, si) => { const sr = svg.getBoundingClientRect(), T = [...svg.querySelectorAll("text")].filter(t => t.textContent.trim() && t.getBoundingClientRect().width > 0).map(t => ({ t, s: t.textContent.trim(), r: t.getBoundingClientRect(), fa: /[؀-ۿ]/.test(t.textContent) })); n += T.length; const tag = svg => `svg#${si + 1}`;
        for (let i = 0; i < T.length; i++) for (let j = i + 1; j < T.length; j++) if (hit(T[i].r, T[j].r)) out.push(`${tag()} overlap: "${T[i].s}" × "${T[j].s}"`);
        for (const x of T) { if (x.r.left < sr.left - 1 || x.r.top < sr.top - 1 || x.r.right > sr.right + 1 || x.r.bottom > sr.bottom + 1) out.push(`${tag()} outside svg box: "${x.s}"`);
          const fs = parseFloat(getComputedStyle(x.t).fontSize) * (x.t.getScreenCTM()?.a || 1); if (x.fa && fs < 11.5) out.push(`${tag()} persian under 11.5px (${fs.toFixed(1)}): "${x.s}"`);
          const id = x.t.getAttribute("data-box"); if (id) { const r = document.getElementById(id).getBoundingClientRect(); if (x.r.left < r.left + 2 || x.r.right > r.right - 2) out.push(`${tag()} overflows box ${id}: "${x.s}"`); } } });
      return { n, out };
    });
    console.log(`${path.basename(f)}: ${r.n} labels, ${r.out.length} problems`); r.out.forEach(m => console.log("  - " + m)); fail += r.out.length; await p.close();
  }
  await b.close(); process.exit(fail ? 1 : 0);
})();
