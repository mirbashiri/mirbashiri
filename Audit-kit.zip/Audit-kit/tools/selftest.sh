#!/bin/sh
# Verifies the kit works here. Run from anywhere. Prints exactly what is missing and how to fix it.
cd "$(dirname "$0")/.." || exit 1
ok=1
echo "node: $(node --version 2>&1)"
node -e "process.exit(+process.versions.node.split('.')[0] >= 18 ? 0 : 1)" || { echo "FAIL: Node >= 18 required"; exit 1; }
echo "1) palette validator (ESM, runs on any Node >= 18 via .mjs)"
if node tools/validate_palette.mjs "#0aa0ba,#7a5af0,#b8741a,#d24fb8" --mode dark --surface "#151819" | grep -q "ALL CHECKS PASS"; then echo "   OK"; else echo "   FAIL: validator did not pass the known-good palette"; ok=0; fi
echo "2) playwright"
if node -e "require('playwright')" 2>/dev/null; then echo "   OK (found)"; else echo "   MISSING -> run: sh tools/setup.sh   (or NODE_PATH=\$(npm root -g) if installed globally)"; ok=0; fi
if [ "$ok" = 1 ]; then
  echo "3) audit runner on examples/sample-page.html"
  if node tools/audit.js examples/sample-page.html --out "${TMPDIR:-/tmp}/audit-selftest" >/tmp/audit-selftest.log 2>&1; then grep -E "min font px|low-contrast" /tmp/audit-selftest.log | head -2; echo "   OK"; else echo "   FAIL (see /tmp/audit-selftest.log)"; tail -5 /tmp/audit-selftest.log; ok=0; fi
  echo "4) sweep on examples/ (sample page only)"
  if node tools/sweep.js examples --exclude "example-|checks-|break-demo|variants/|toast-" --out "${TMPDIR:-/tmp}/sweep-selftest" >/tmp/sweep-selftest.log 2>&1 && grep -q "# App sweep" /tmp/sweep-selftest.log; then echo "   OK"; else echo "   FAIL (see /tmp/sweep-selftest.log)"; tail -5 /tmp/sweep-selftest.log; ok=0; fi
  echo "5) static checks: the bad fixture must FAIL, the clean one must PASS (mobile, motion, typography, copy)"
  T="${TMPDIR:-/tmp}/ak-selftest"; mkdir -p "$T"
  if node tools/audit.js examples/checks-bad.html --out "$T/cb" --no-mobile --fail-on mobile,motion,typography,copy >"$T/cb.log" 2>&1; then echo "   FAIL: checks-bad.html passed (checks cannot fail)"; ok=0; else grep -q "FAIL (--fail-on): mobile=" "$T/cb.log" && echo "   OK (bad fixture fails)" || { echo "   FAIL: unexpected error (see $T/cb.log)"; ok=0; }; fi
  if node tools/audit.js examples/checks-good.html --out "$T/cg" --no-mobile --fail-on mobile,hoverGate,motion,reducedMotion,typography,copy >"$T/cg.log" 2>&1; then echo "   OK (clean fixture passes)"; else echo "   FAIL: checks-good.html reported findings (see $T/cg.log)"; ok=0; fi
  echo "6) mobile-check / motion-check / completeness exit codes"
  node tools/mobile-check.js examples/checks-bad.html --out "$T/m1" >/dev/null 2>&1; r1=$?; node tools/mobile-check.js examples/checks-good.html --out "$T/m2" >/dev/null 2>&1; r2=$?
  node tools/motion-check.js examples/checks-bad.html --out "$T/o1" >/dev/null 2>&1; r3=$?; node tools/motion-check.js examples/checks-good.html --out "$T/o2" >/dev/null 2>&1; r4=$?
  printf '<html><body><!-- ... -->\n<script>function a( {</script>\n' > "$T/trunc.html"; node tools/completeness.js "$T/trunc.html" >/dev/null 2>&1; r5=$?; node tools/completeness.js examples/checks-good.html >/dev/null 2>&1; r6=$?
  if [ "$r1$r2$r3$r4$r5$r6" = "101010" ]; then echo "   OK (bad=1, clean=0 for each tool)"; else echo "   FAIL: exit codes $r1 $r2 $r3 $r4 $r5 $r6 (expected 1 0 1 0 1 0)"; ok=0; fi
  echo "6b) motion-check sees transitions set by JavaScript at runtime (bad must FAIL, compliant must PASS)"
  node tools/motion-check.js examples/motion-js-bad.html --out "$T/j1" >/dev/null 2>&1; j1=$?; node tools/motion-check.js examples/motion-js-good.html --out "$T/j2" >/dev/null 2>&1; j2=$?
  if [ "$j1$j2" = "10" ] && grep -q "div.bar width 600ms" "$T/j1/report.md"; then echo "   OK (script-set 600ms ease-in width: flagged; 180ms ease-out transform: passes)"; else echo "   FAIL: exit codes $j1 $j2 (expected 1 0) or the driven event is missing in $T/j1/report.md"; ok=0; fi
  echo "6c) version consistency (VERSION, CHANGELOG, README, landing page)"
  if node tools/bump-version.js --check >"$T/ver.log" 2>&1; then echo "   OK ($(cat VERSION))"; else echo "   FAIL: $(tr '\n' ' ' < "$T/ver.log")"; ok=0; fi
  echo "7) worst-case data: fragile page must FAIL, robust page must PASS"
  node tools/break-data.js examples/break-demo.json --out "$T/bd" --rows 8 >/dev/null 2>&1
  node tools/worst-case.js examples/break-demo-bad.html --fixtures "$T/bd" --states worst,one --widths 1440,320 --out "$T/w1" >/dev/null 2>&1; w1=$?; node tools/worst-case.js examples/break-demo-good.html --fixtures "$T/bd" --states worst,one,empty --widths 1440,320 --out "$T/w2" >/dev/null 2>&1; w2=$?
  if [ "$w1$w2" = "10" ]; then echo "   OK (fragile=1, robust=0)"; else echo "   FAIL: exit codes $w1 $w2 (expected 1 0)"; ok=0; fi
  echo "8) prototype-variants picker"
  if node tools/variants.js examples/variants/variants.json --out "$T/v1" --no-mobile 2>&1 | grep -q "6 ok, 0 failed"; then echo "   OK"; else echo "   FAIL (see $T/v1/variants.md)"; ok=0; fi
fi
[ "$ok" = 1 ] && echo "ALL OK" || { echo "NOT READY: fix the items above"; exit 1; }
