#!/bin/sh
# Verifies the kit works here. Run from anywhere. Prints exactly what is missing and how to fix it.
cd "$(dirname "$0")/.." || exit 1
ok=1
echo "node: $(node --version 2>&1)"
node -e "process.exit(+process.versions.node.split('.')[0] >= 18 ? 0 : 1)" || { echo "FAIL: Node >= 18 required"; exit 1; }
echo "1) palette validator (ESM, runs on any Node >= 18 via .mjs)"
if node tools/validate_palette.mjs "#0aa0ba,#7a5af0,#b8741a,#d24fb8" --mode dark --surface "#151819" | grep -q "ALL CHECKS PASS"; then echo "   OK"; else echo "   FAIL: validator did not pass the known-good palette"; ok=0; fi
echo "2) playwright"
if node -e "require('playwright')" 2>/dev/null; then echo "   OK (found)"; else echo "   MISSING -> run: sh tools/setup.sh   (or NODE_PATH=\$(npm root -g) if installed globally)"; ok=0; fi
if [ "$ok" = 1 ]; then
  echo "3) audit runner on examples/sample-page.html"
  if node tools/audit.js examples/sample-page.html --out "${TMPDIR:-/tmp}/audit-selftest" >/tmp/audit-selftest.log 2>&1; then grep -E "min font px|low-contrast" /tmp/audit-selftest.log | head -2; echo "   OK"; else echo "   FAIL (see /tmp/audit-selftest.log)"; tail -5 /tmp/audit-selftest.log; ok=0; fi
  echo "4) sweep on examples/ (sample page only)"
  if node tools/sweep.js examples --exclude "example-" --out "${TMPDIR:-/tmp}/sweep-selftest" >/tmp/sweep-selftest.log 2>&1 && grep -q "# App sweep" /tmp/sweep-selftest.log; then echo "   OK"; else echo "   FAIL (see /tmp/sweep-selftest.log)"; tail -5 /tmp/sweep-selftest.log; ok=0; fi
fi
[ "$ok" = 1 ] && echo "ALL OK" || { echo "NOT READY: fix the items above"; exit 1; }
