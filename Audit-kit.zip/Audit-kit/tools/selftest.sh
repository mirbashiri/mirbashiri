#!/bin/sh
# Verifies the kit works in this environment (run from the kit root).
set -e
export NODE_PATH="${NODE_PATH:-$(npm root -g)}"
echo "1) palette validator"; node tools/validate_palette.js "#0aa0ba,#7a5af0,#b8741a,#d24fb8" --mode dark --surface "#151819" | tail -4
echo "2) audit runner on examples/sample-page.html"; node tools/audit.js examples/sample-page.html --out /tmp/audit-selftest | sed -n 5,12p
echo "OK: tools run. Expect min font 12, 0 low-contrast, 0 flat violations for the sample."
