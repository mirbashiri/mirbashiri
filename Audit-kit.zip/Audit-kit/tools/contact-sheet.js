#!/usr/bin/env node
// Labelled grid of images. Usage: node tools/contact-sheet.js <out.png> <img1> <img2> ... [--cols 3] [--labels "a,b,c"] [--width 2400]
const path = require("path"), fs = require("fs"); let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found: sh tools/setup.sh"); process.exit(2); }
const a = process.argv.slice(2), opt = (n, d) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : d; }, vals = ["--cols", "--labels", "--width"], pos = a.filter((x, i) => !x.startsWith("--") && !vals.includes(a[i - 1])), [out, ...imgs] = pos;
if (!out || !imgs.length) { console.error("usage: node tools/contact-sheet.js out.png img1 img2 ... [--cols N] [--labels a,b]"); process.exit(2); }
const cols = +opt("--cols", Math.min(3, imgs.length)), labels = (opt("--labels", "") || "").split(",").filter(Boolean), W = +opt("--width", 2400), esc = s => s.replace(/[<>&]/g, c => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" }[c]));
const mime = f => /\.jpe?g$/i.test(f) ? "image/jpeg" : /\.webp$/i.test(f) ? "image/webp" : /\.svg$/i.test(f) ? "image/svg+xml" : "image/png";
(async () => { const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}), p = await b.newPage({ viewport: { width: W, height: 800 } });
  await p.setContent(`<body style="margin:0;background:#1a1a1a;font:600 20px system-ui,sans-serif;color:#eee"><div style="display:grid;grid-template-columns:repeat(${cols},1fr);gap:28px;padding:28px">${imgs.map((f, i) => `<div><div style="padding:0 0 10px">${esc(labels[i] || path.basename(f))}</div><img src="data:${mime(f)};base64,${fs.readFileSync(f).toString("base64")}" style="width:100%;display:block;border:1px solid #444;background:#fff"></div>`).join("")}</div>`);
  await p.waitForTimeout(400); fs.mkdirSync(path.dirname(path.resolve(out)), { recursive: true }); await p.screenshot({ path: out, fullPage: true }); await b.close(); console.log("saved " + out); })();
