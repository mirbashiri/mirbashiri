#!/usr/bin/env node
// Render every slide/poster-panel of an HTML deck + per-slide checks + contact sheet.
// Usage: node tools/slides.js <deck.html|url> --out DIR [--selector ".slide,section"] [--width 1920] [--height 1080] [--keys N] [--next-key ArrowRight|ArrowLeft] [--min-font 12]
//  --selector: elements that are slides (default ".slide, section.slide, [data-slide], section"). If fewer than 2 match, falls back to pressing ArrowRight N times (--keys, default 12) and screenshotting the viewport.
const path = require("path"), fs = require("fs"), cp = require("child_process"); let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found: sh tools/setup.sh"); process.exit(2); }
const a = process.argv.slice(2), opt = (n, d) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : d; }, vals = ["--out", "--selector", "--width", "--height", "--keys", "--min-font", "--next-key"], pg = a.find((x, i) => !x.startsWith("--") && !vals.includes(a[i - 1]));
if (!pg) { console.error("usage: node tools/slides.js <deck.html> --out DIR"); process.exit(2); }
const out = path.resolve(opt("--out", "slides-out")), W = +opt("--width", 1920), H = +opt("--height", 1080), minFont = +opt("--min-font", 12), sel = opt("--selector", ".slide, section.slide, [data-slide], section"); fs.mkdirSync(out, { recursive: true });
const measure = (el, minFont) => { const q = [...el.querySelectorAll("*")].filter(e => [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())); const sz = q.map(e => parseFloat(getComputedStyle(e).fontSize)); const r = el.getBoundingClientRect(); const over = q.filter(e => { const b = e.getBoundingClientRect(); return b.right > r.right + 2 || b.bottom > r.bottom + 2 || b.left < r.left - 2 || b.top < r.top - 2; }).length; return { texts: q.length, minFont: sz.length ? Math.min(...sz) : null, underMin: sz.filter(s => s < minFont).length, overflowingText: over, words: q.map(e => e.textContent.trim()).join(" ").split(/\s+/).filter(Boolean).length, w: Math.round(r.width), h: Math.round(r.height) }; };
(async () => { const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}), p = await b.newPage({ viewport: { width: W, height: H } }), errs = []; p.on("pageerror", e => errs.push(String(e)));
  await p.goto(/^https?:\/\//.test(pg) ? pg : "file://" + path.resolve(pg), { waitUntil: "load" }); await p.waitForTimeout(500); await p.evaluate(() => document.fonts && document.fonts.ready);
  const els = await p.$$(sel), rows = [], files = [], nextKey = opt("--next-key", "ArrowRight"), fn = measure.toString();
  const vis = async el => (await el.boundingBox()) && (await el.evaluate(e => getComputedStyle(e).display !== "none" && getComputedStyle(e).visibility !== "hidden" && +getComputedStyle(e).opacity > 0));
  const visible = []; for (const e of els) if (await vis(e)) visible.push(e);
  const allVisible = els.length >= 2 && visible.length === els.length, stepper = els.length >= 2 && !allVisible, n = els.length >= 2 ? els.length : +opt("--keys", 12);
  for (let i = 0; i < n; i++) {
    const f = path.join(out, `slide-${String(i + 1).padStart(2, "0")}.png`); let target = null;
    if (allVisible) { target = els[i]; await target.scrollIntoViewIfNeeded(); await p.waitForTimeout(120); } else { for (const e of els) if (await vis(e)) { const bb = await e.boundingBox(); if (bb && bb.width > W * 0.5 && bb.x >= -2 && bb.x < W * 0.5) { target = e; break; } } }
    if (target) { await target.screenshot({ path: f }); rows.push(await target.evaluate((el, [fnStr, m]) => (new Function("el", "m", "return (" + fnStr + ")(el, m)"))(el, m), [fn, minFont])); } else { await p.screenshot({ path: f }); rows.push({ note: "viewport capture (no slide element identified)" }); }
    files.push(f); if (!allVisible) { await p.keyboard.press(nextKey); await p.waitForTimeout(350); }
  }
  await b.close();
  let md = `# Slides report — ${pg}\n\nMode: ${els.length < 2 ? "keyboard fallback (no multi-slide selector matched; viewport captured after each key press, duplicates not removed)" : stepper ? "stepper (" + els.length + " slides, one visible at a time, advanced with " + nextKey + ")" : "all slides visible, element screenshots (" + els.length + ")"}. Min font threshold ${minFont}px. Page errors: ${errs.length}.\n\n| slide | texts | min font | under min | text outside slide box | words | size |\n|---|---|---|---|---|---|---|\n`;
  rows.forEach((r, i) => { md += `| ${i + 1} | ${r.texts ?? ""} | ${r.minFont ?? ""} | ${r.underMin ?? ""} | ${r.overflowingText ?? ""} | ${r.words ?? ""} | ${r.w ? r.w + "x" + r.h : r.note || ""} |\n`; });
  fs.writeFileSync(path.join(out, "report.md"), md); fs.writeFileSync(path.join(out, "report.json"), JSON.stringify({ rows, errors: errs }, null, 1));
  cp.spawnSync("node", [path.join(__dirname, "contact-sheet.js"), path.join(out, "sheet.png"), ...files, "--cols", "3", "--labels", files.map((f, i) => "slide " + (i + 1)).join(",")], { stdio: "ignore" }); console.log(md + "\nSaved slides + sheet.png in " + out); })();
