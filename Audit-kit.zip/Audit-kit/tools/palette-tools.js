#!/usr/bin/env node
// Palette helpers. Usage:
//   node tools/palette-tools.js matrix <palette.json> [--max 24]   WCAG contrast matrix of every colour pair (marks >=4.5 / >=3 / below)
//   node tools/palette-tools.js css <palette.json>                 :root{--path-to-key:#hex} block from any JSON (nested keys joined with -)
//   node tools/palette-tools.js list <palette.json>                flat list of key -> hex
// palette.json: any JSON whose leaf strings are #hex colours (nested objects fine).
const fs = require("fs"), a = process.argv.slice(2), [cmd, file] = a; if (!cmd || !file) { console.error("usage: node tools/palette-tools.js matrix|css|list <palette.json>"); process.exit(2); }
const j = JSON.parse(fs.readFileSync(file, "utf8")), flat = [], walk = (o, p) => { if (typeof o === "string") { if (/^#[0-9a-f]{3}([0-9a-f]{3})?$/i.test(o)) flat.push([p.join("-"), o.length === 4 ? "#" + [...o.slice(1)].map(c => c + c).join("") : o.toLowerCase()]); } else if (o && typeof o === "object") for (const [k, v] of Object.entries(o)) if (!k.startsWith("_")) walk(v, [...p, k]); }; walk(j, []);
const lum = h => { const f = v => (v /= 255) <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4), [r, g, b] = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); return .2126 * f(r) + .7152 * f(g) + .0722 * f(b); }, cr = (x, y) => { const p = lum(x), q = lum(y); return (Math.max(p, q) + .05) / (Math.min(p, q) + .05); };
if (!flat.length) { console.error("no #hex colours found in " + file); process.exit(1); }
if (cmd === "list") flat.forEach(([k, h]) => console.log(k.padEnd(32), h));
else if (cmd === "css") console.log(":root{\n" + flat.map(([k, h]) => `  --${k.replace(/[^a-z0-9-]/gi, "-").toLowerCase()}: ${h};`).join("\n") + "\n}");
else if (cmd === "matrix") { const max = +(a[a.indexOf("--max") + 1] || 24), L = flat.slice(0, max); let md = `Contrast matrix (${L.length} of ${flat.length} colours). Text needs >= 4.5, large text/graphics >= 3. Cells: ratio; ** = >= 4.5, * = >= 3.\n\n| |${L.map(([k]) => k).join("|")}|\n|---|${L.map(() => "---").join("|")}|\n`; for (const [k, h] of L) md += `| **${k}** ${h} |${L.map(([k2, h2]) => k === k2 ? "·" : (r => r.toFixed(1) + (r >= 4.5 ? "**" : r >= 3 ? "*" : ""))(cr(h, h2))).join("|")}|\n`; console.log(md); if (flat.length > max) console.log(`(${flat.length - max} colours not shown; use --max)`); }
else { console.error("unknown command " + cmd); process.exit(2); }
