#!/usr/bin/env node
// Completeness check for what an AGENT built (anti-truncation), from taste-skill "output-skill" (banned placeholder patterns) -
// the same patterns, applied to the output file instead of promised in a prompt. No browser needed.
//   node tools/completeness.js <file...> [--json] [--allow "regex,regex"]
// Finds, with file:line: placeholder comments (`// ...`, `/* ... */`, `<!-- ... -->`, `// rest of code`, `// implement here`, `// TODO`, `// similar to above`,
// `// continue pattern`, `// add more as needed`), a line that is only `...`, truncation prose ("for brevity", "the rest follows", "similarly for the remaining",
// "let me know if you want me to continue", "I'll leave that as an exercise", "[PAUSED ..."), Lorem ipsum, and STRUCTURAL truncation:
// HTML without </html>/</body>, unclosed <script>/<style>, inline <script> that does not compile (vm.Script syntax check), unbalanced CSS braces, a file that ends mid-line.
// HEURISTIC: regex over text. `and so on` is only flagged in comments. `TODO` is only flagged in comments or markdown. A deliberate TODO in your own backlog is a finding too
// (use --allow to exempt). It proves nothing about whether the content is RIGHT, only that it is not visibly cut short. Exit code 1 = findings.
const fs = require("fs"), vm = require("vm"), path = require("path");
const a = process.argv.slice(2), files = a.filter((x, i) => !x.startsWith("--") && a[i - 1] !== "--allow"), json = a.includes("--json"), allow = (a[a.indexOf("--allow") + 1] || "").split(",").filter(x => x && a.includes("--allow")).map(x => new RegExp(x, "i"));
if (!files.length) { console.error("usage: node tools/completeness.js <file...> [--json] [--allow regex,regex]"); process.exit(2); }
const COMMENT = [/\/\/\s*\.\.\.\s*$/i, /\/\/\s*(rest of (the )?(code|file|implementation)|implement (here|me)|similar to above|continue (the )?pattern|add more as needed|remaining (code|items))\b/i, /\/\*\s*\.\.\.\s*\*\//, /<!--\s*(\.\.\.|rest of[^>]*|add more[^>]*|similar to above|more (items|cards|rows|sections)[^>]*)\s*-->/i, /(^|\s)(\/\/|\/\*|<!--|#)\s*TODO\b/, /(\/\/|\/\*|<!--)\s*(and so on|etc\.?)\s*(\*\/|-->)?\s*$/i, /(\/\/|\/\*|<!--)\s*\[?continue here\]?/i];
const PROSE = [/\bfor brevity\b/i, /\bthe rest (follows|is the same|of the (code|file|items) (follows|is similar))\b/i, /\bsimilarly for the (remaining|rest|other)\b/i, /let me know if you want me to continue/i, /i can provide more details if needed/i, /i'?ll leave (that|this|it) as an exercise/i, /\[PAUSED\b/i, /\blorem ipsum\b/i, /\[continue here\]/i];
const res = [];
for (const f of files) {
  let t; try { t = fs.readFileSync(f, "utf8"); } catch (e) { res.push({ file: f, error: e.message, findings: [] }); continue; }
  const ext = path.extname(f).toLowerCase(), fnd = [], add = (line, kind, text) => { if (allow.some(r => r.test(text))) return; fnd.push({ line, kind, text: text.trim().slice(0, 100) }); }, lines = t.split("\n");
  lines.forEach((ln, i) => { const L = i + 1;
    if (/^\s*(\.\.\.|…)\s*$/.test(ln)) add(L, "bare ellipsis line", ln);
    for (const r of COMMENT) if (r.test(ln)) { add(L, "placeholder comment", ln); break; }
    for (const r of PROSE) if (r.test(ln)) { add(L, "truncation prose / placeholder text", ln); break; } });
  if (/\.(html?|svg)$/.test(ext)) {
    const lc = t.toLowerCase(), n = (re) => (lc.match(re) || []).length;
    if (/\.html?$/.test(ext)) { if (!/<\/html\s*>/.test(lc)) add(lines.length, "structure", "no closing </html>: file looks cut off"); if (!/<\/body\s*>/.test(lc)) add(lines.length, "structure", "no closing </body>"); }
    if (n(/<script\b/g) !== n(/<\/script\s*>/g)) add(lines.length, "structure", `unbalanced <script> tags (${n(/<script\b/g)} open / ${n(/<\/script\s*>/g)} close)`);
    if (n(/<style\b/g) !== n(/<\/style\s*>/g)) add(lines.length, "structure", `unbalanced <style> tags (${n(/<style\b/g)} open / ${n(/<\/style\s*>/g)} close)`);
    const re = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi; let m; while ((m = re.exec(t))) { if (/\bsrc=/.test(m[1]) || /type\s*=\s*["'](?!module|text\/javascript|application\/javascript)/i.test(m[1]) || !m[2].trim()) continue; const line = t.slice(0, m.index).split("\n").length; try { new vm.Script(m[2], { filename: f }); } catch (e) { if (!/import|export|await/.test(e.message)) add(line, "structure", "inline <script> does not compile: " + e.message); } }
    const sre = /<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi; while ((m = sre.exec(t))) { const css = m[1].replace(/\/\*[\s\S]*?\*\//g, "").replace(/(["'])(?:\\.|(?!\1).)*\1/g, ""); const o = (css.match(/{/g) || []).length, c = (css.match(/}/g) || []).length; if (o !== c) add(t.slice(0, m.index).split("\n").length, "structure", `unbalanced braces in <style> (${o} { / ${c} })`); }
  } else if (ext === ".css") { const css = t.replace(/\/\*[\s\S]*?\*\//g, ""), o = (css.match(/{/g) || []).length, c = (css.match(/}/g) || []).length; if (o !== c) add(lines.length, "structure", `unbalanced braces (${o} { / ${c} })`); }
  else if (/\.(js|mjs|cjs)$/.test(ext)) { try { new vm.Script(t.replace(/^#!.*/, ""), { filename: f }); } catch (e) { if (!/import|export|await/.test(e.message)) add(lines.length, "structure", "does not compile: " + e.message); } }
  else if (ext === ".json") { try { JSON.parse(t); } catch (e) { add(lines.length, "structure", "invalid JSON: " + e.message); } }
  if (t.length && !/\n$/.test(t) && /[,({\[:=]\s*$/.test(t)) add(lines.length, "structure", "file ends mid-statement (last char is an opener or separator)");
  res.push({ file: f, bytes: t.length, lines: lines.length, findings: fnd });
}
const total = res.reduce((n, r) => n + r.findings.length, 0);
if (json) console.log(JSON.stringify(res, null, 1)); else { for (const r of res) { console.log(`\n${r.file}: ${r.error ? "ERROR " + r.error : `${r.lines} lines, ${r.findings.length} finding(s)`}`); r.findings.slice(0, 40).forEach(f => console.log(`  ${f.line}: [${f.kind}] ${f.text}`)); } console.log(`\n${total ? "INCOMPLETE-LOOKING: " + total + " finding(s)" : "No placeholder or truncation patterns found"} (heuristic: regex + syntax checks, see tool header).`); }
process.exit(total ? 1 : 0);
