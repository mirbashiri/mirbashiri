#!/usr/bin/env node
// Whole-app sweep: audit many pages, then rank them and find cross-page inconsistencies.
// Usage: node tools/sweep.js <start-url | folder-with-html | list.txt> [--depth 2] [--max 30] [--out DIR] [--config FILE] [--mode NAME] [--no-mobile] [--exclude REGEX]
//  --exclude: skip files/URLs matching the regex (e.g. 'template|partial|/src/' to skip HTML fragments).
//  - URL: crawls same-origin <a href> links breadth-first (needs network to the app). Pages behind login are NOT reached; give a list file or a folder instead.
//  - folder: every .html under it.   - list.txt: one file path or URL per line.
// Runs tools/audit.js per page (so all its checks/config apply), then writes DIR/summary.md + DIR/summary.json.
const fs = require("fs"), path = require("path"), cp = require("child_process");
const args = process.argv.slice(2), opt = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; }, flag = n => args.includes(n);
const vals = new Set(["--depth", "--max", "--out", "--config", "--mode", "--exclude"]), target = args.find((a, i) => !a.startsWith("--") && !vals.has(args[i - 1]));
if (!target) { console.error("usage: node tools/sweep.js <start-url | folder | list.txt> [--depth N] [--max N] [--out DIR] [--config FILE] [--mode NAME]"); process.exit(2); }
const out = path.resolve(opt("--out", "sweep-out")), max = +opt("--max", 30), depth = +opt("--depth", 2); fs.mkdirSync(out, { recursive: true });
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? (e.name === "node_modules" || e.name.startsWith(".") ? [] : walk(path.join(d, e.name))) : /\.html?$/i.test(e.name) ? [path.join(d, e.name)] : []);
(async () => {
  let pages = [];
  if (/^https?:\/\//.test(target)) {
    let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found: sh tools/setup.sh"); process.exit(2); }
    const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}), origin = new URL(target).origin, seen = new Set(), q = [[target, 0]];
    const norm = u => { const x = new URL(u); x.hash = ""; return x.href.replace(/\/$/, ""); };
    while (q.length && pages.length < max) {
      const [u, d] = q.shift(), k = norm(u); if (seen.has(k)) continue; seen.add(k);
      const pg = await b.newPage(); let ok = true; await pg.goto(u, { waitUntil: "load", timeout: 20000 }).catch(() => { ok = false; });
      if (ok) { pages.push(u); if (d < depth) { const links = await pg.evaluate(() => [...document.querySelectorAll("a[href]")].map(a => a.href)); for (const l of links) { try { const x = new URL(l); if (x.origin === origin && !/\.(pdf|png|jpe?g|svg|zip|css|js|ico|webp)$/i.test(x.pathname) && !seen.has(norm(l))) q.push([l, d + 1]); } catch {} } } }
      await pg.close();
    }
    await b.close();
  } else if (fs.existsSync(target) && fs.statSync(target).isDirectory()) pages = walk(target).slice(0, max);
  else if (fs.existsSync(target) && /\.txt$/.test(target)) pages = fs.readFileSync(target, "utf8").split("\n").map(s => s.trim()).filter(s => s && !s.startsWith("#")).slice(0, max);
  else if (fs.existsSync(target)) pages = [target];
  else { console.error("not found: " + target); process.exit(2); }
  if (opt("--exclude")) { const re = new RegExp(opt("--exclude")); pages = pages.filter(x => !re.test(x)); }
  if (!pages.length) { console.error("no pages found"); process.exit(1); }
  console.log(`sweeping ${pages.length} page(s)`);
  const res = [];
  pages.forEach((pg, i) => {
    const slug = String(i + 1).padStart(2, "0") + "_" + (pg.replace(/^https?:\/\//, "").replace(/\W+/g, "_").slice(-40) || "page"), dir = path.join(out, slug);
    const a = [path.join(__dirname, "audit.js"), pg, "--out", dir]; for (const f of ["--config", "--mode"]) if (opt(f)) a.push(f, opt(f)); if (flag("--no-mobile")) a.push("--no-mobile");
    const r = cp.spawnSync("node", a, { encoding: "utf8", timeout: 180000 });
    try { res.push({ page: pg, dir, report: JSON.parse(fs.readFileSync(path.join(dir, "report.json"), "utf8"))[0] }); } catch { res.push({ page: pg, dir, failed: (r.stderr || r.stdout || "").slice(-200) }); }
    process.stdout.write(".");
  });
  console.log();
  const score = m => m.lowContrast.length * 2 + m.under12 + m.tapCount + Math.min(m.consistency.spacing.offGridCount * 0.1, 10) + (m.consistency.colours.offToken ? m.consistency.colours.offToken.length : 0) + m.errors.length * 3 + (m.hScroll ? 5 : 0) + m.a11y.imgNoAlt + m.a11y.btnNoName + m.a11y.inputNoLabel + (m.flat.gradient + m.flat.rgba + m.flat.shadow) * 0.5 + m.placeholders.length * 0.5;
  const rows = res.map(r => { if (r.failed) return { page: r.page, failed: r.failed }; const ms = Object.entries(r.report.modes), worst = ms.map(([k, m]) => [k, score(m)]).sort((a, b) => b[1] - a[1])[0], m0 = ms[0][1];
    return { page: r.page, dir: r.dir, score: +worst[1].toFixed(1), worstMode: worst[0], lowContrast: Math.max(...ms.map(([, m]) => m.lowContrast.length)), underMin: Math.max(...ms.map(([, m]) => m.under12)), tap: Math.max(...ms.map(([, m]) => m.tapCount)), offGrid: m0.consistency.spacing.offGridCount, offToken: m0.consistency.colours.offToken ? m0.consistency.colours.offToken.length : null, hScroll: ms.some(([, m]) => m.hScroll), errors: Math.max(...ms.map(([, m]) => m.errors.length)), themeOk: r.report.themeSwitchEffective, fonts: m0.consistency.fonts, radii: m0.consistency.radii, colours: m0.consistency.colours.top.map(c => c[0]), shots: ms.map(([, m]) => m.screenshot) }; });
  const ok = rows.filter(r => !r.failed).sort((a, b) => b.score - a.score), union = k => [...new Set(ok.flatMap(r => r[k]))];
  const texts = {}; res.forEach(r => r.report && Object.values(r.report.modes).forEach(m => m.lowContrast.forEach(t => { const key = t.replace(/^[\d.]+:1 \(need [\d.]+\) /, ""); (texts[key] = texts[key] || new Set()).add(r.page); })));
  const repeated = Object.entries(texts).filter(([, s]) => s.size > 1).map(([t, s]) => `${t} (${s.size} pages)`).slice(0, 8);
  let md = `# App sweep — ${pages.length} pages\n\nPages ranked by weighted issue score (higher = worse; weights are rough: contrast x2, errors x3, off-grid x0.1 capped at 10). The score ranks, it does not prove severity: read each page's report.\n\n| # | page | score | worst mode | low contrast | under min font | small taps | off-grid spacing | off-token colours | h-scroll | errors | theme switch works |\n|---|---|---|---|---|---|---|---|---|---|---|---|\n`;
  ok.forEach((r, i) => { md += `| ${i + 1} | ${r.page} | ${r.score} | ${r.worstMode} | ${r.lowContrast} | ${r.underMin} | ${r.tap} | ${r.offGrid} | ${r.offToken ?? "n/a"} | ${r.hScroll ? "YES" : "no"} | ${r.errors} | ${r.themeOk ? "yes" : "NO"} |\n`; });
  rows.filter(r => r.failed).forEach(r => { md += `\n**FAILED to audit:** ${r.page} — ${r.failed}\n`; });
  const fam = union("fonts"), rad = union("radii");
  md += `\n## Cross-page consistency\n- Font families used across the app: **${fam.length}** (${fam.join(", ")}). More than 2–3 usually means drift.\n- Border radii used across the app: **${rad.length}** (${rad.join(", ")} px). Many distinct radii = inconsistent components.\n- Distinct top colours across pages: **${union("colours").length}**.\n`;
  if (repeated.length) md += `- Same low-contrast text on several pages (fix once, in the shared component): ${repeated.join("; ")}\n`;
  if (ok.some(r => !r.themeOk)) md += `- **Theme switching had no effect on:** ${ok.filter(r => !r.themeOk).map(r => r.page).join(", ")} — their light/dark rows are the same page.\n`;
  md += `\nPer-page reports and screenshots: ${out}/<nn>_<page>/report.md + PNGs. Judgement checks (hierarchy, colour meaning, chart form) still need the checklist; this sweep only measures.\n`;
  fs.writeFileSync(path.join(out, "summary.md"), md); fs.writeFileSync(path.join(out, "summary.json"), JSON.stringify(rows, null, 1)); console.log(md);
})();
