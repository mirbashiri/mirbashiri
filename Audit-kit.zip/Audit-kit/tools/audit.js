#!/usr/bin/env node
// Audit-kit runner: measure first, judge second. App-agnostic; thresholds come from audit.config.json.
// Setup once: sh tools/setup.sh   (or global playwright + NODE_PATH=$(npm root -g)). Set CHROMIUM_PATH to use an existing Chromium binary.
// Usage:  node tools/audit.js <page.html|http(s)://url> [more pages...] [--out DIR] [--config FILE] [--no-mobile] [--wait MS]
// For each page renders every theme x viewport in audit.config.json (theme via ?theme= AND data-theme attribute by default),
// saves full-page PNGs and measures: text sizes, contrast, flat-rule violations, overflow, small tap targets, a11y basics,
// placeholder cards, SVG colours (feed them to validate_palette.mjs), RTL/Persian rules. Writes DIR/report.json + DIR/report.md.
// Everything printed is MEASURED. Judgement (hierarchy, density, meaning of colour) is yours: see AUDIT-CHECKLIST.md.
const path = require("path"), fs = require("fs");
let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found. Fix: sh tools/setup.sh   (installs it next to the kit), or npm i -g playwright && NODE_PATH=$(npm root -g) node tools/audit.js ..."); process.exit(2); }
const args = process.argv.slice(2), flag = n => args.includes(n), opt = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };
const skipVals = new Set(["--out", "--wait", "--config"]); const pages = args.filter((a, i) => !a.startsWith("--") && !skipVals.has(args[i - 1]));
if (!pages.length) { console.error("give at least one page (file or URL)"); process.exit(2); }
const cfgPath = opt("--config", path.join(__dirname, "..", "audit.config.json")); let cfg = {}; try { cfg = JSON.parse(fs.readFileSync(cfgPath, "utf8")); } catch { console.error("note: no readable config at " + cfgPath + ", using defaults"); }
cfg = { minFontPx: 12, minTapPx: 24, contrastNormal: 4.5, contrastLarge: 3, flatDesign: false, themes: ["dark", "light"], themeStrategies: ["query", "attribute", "class", "emulate"], themeQueryParam: "theme", themeAttribute: "data-theme", themeClassTarget: ["html", "body"], themeClassMap: null, themeStorageKey: null, themeStorageValues: null, viewports: { desktop: [1440, 900], mobile: [390, 844] }, mobile: true, ...cfg };
const outDir = path.resolve(opt("--out", "audit-out")), wait = +opt("--wait", 300), [dw, dh] = cfg.viewports.desktop, modes = cfg.themes.map(t => [t, dw, dh]); if (cfg.mobile && !flag("--no-mobile")) modes.push([cfg.themes[0] + "-mobile", ...cfg.viewports.mobile]);
fs.mkdirSync(outDir, { recursive: true });
const rgb = c => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return { r: p[0], g: p[1], b: p[2], a: p[3] ?? 1 }; };
const lum = ({ r, g, b }) => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b); };
const cr = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
const inPage = ({ minFont, minTap }) => {
  const skip = ["SCRIPT", "STYLE", "SVG", "PATH", "NOSCRIPT"], vis = e => { const cs = getComputedStyle(e); if (cs.display === "none" || cs.visibility === "hidden") return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const effBg = el => { let e = el; while (e) { const c = getComputedStyle(e).backgroundColor, m = c.match(/rgba?\(([^)]+)\)/); if (m) { const p = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); if ((p[3] ?? 1) > 0.5) return c; } e = e.parentElement; } return "rgb(255,255,255)"; };
  const textEls = [...document.body.querySelectorAll("*")].filter(e => !skip.includes(e.tagName.toUpperCase()) && [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && vis(e));
  const inVp = e => { const r = e.getBoundingClientRect(); return r.top < innerHeight && r.bottom > 0; };
  const sizes = textEls.map(e => parseFloat(getComputedStyle(e).fontSize)), vp = textEls.filter(inVp);
  const svgT = [...document.querySelectorAll("svg text")].filter(vis).map(t => parseFloat(getComputedStyle(t).fontSize) * (t.getScreenCTM()?.a || 1));
  const med = a => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
  const ph = textEls.filter(e => /^(—|–|-|n\/a|n=0|0\/0)$/i.test(e.textContent.trim()) || /insufficient|not tracked|no data|\(0\/\d\)/i.test(e.textContent)).map(e => e.textContent.trim().slice(0, 40));
  const flat = { gradient: [], rgba: [], shadow: [] }, tag = e => e.tagName.toLowerCase() + (e.className && typeof e.className === "string" ? "." + e.className.trim().split(/\s+/)[0] : "");
  document.querySelectorAll("body *").forEach(e => { const cs = getComputedStyle(e); if (/gradient/.test(cs.backgroundImage)) flat.gradient.push(tag(e)); if (cs.boxShadow !== "none" && vis(e)) flat.shadow.push(tag(e)); if (/rgba\([^)]*,\s*0?\.\d+\)/.test(cs.backgroundColor + cs.borderTopColor)) flat.rgba.push(tag(e)); });
  const uniq = a => [...new Set(a)].slice(0, 12);
  const tap = [...document.querySelectorAll("a[href],button,[role=button],input,select,textarea,[tabindex]")].filter(vis).filter(e => { const r = e.getBoundingClientRect(); return r.width < minTap || r.height < minTap; }).map(e => `${tag(e)} ${Math.round(e.getBoundingClientRect().width)}x${Math.round(e.getBoundingClientRect().height)} "${(e.textContent || e.getAttribute("aria-label") || "").trim().slice(0, 20)}"`);
  const a11y = { imgNoAlt: document.querySelectorAll("img:not([alt])").length, btnNoName: [...document.querySelectorAll("button,[role=button]")].filter(b => !(b.textContent.trim() || b.getAttribute("aria-label") || b.getAttribute("title"))).length, inputNoLabel: [...document.querySelectorAll("input,select,textarea")].filter(i => i.type !== "hidden" && !(i.labels && i.labels.length) && !i.getAttribute("aria-label") && !i.getAttribute("aria-labelledby")).length, positiveTabindex: document.querySelectorAll("[tabindex]:not([tabindex='0']):not([tabindex^='-'])").length, noLang: !document.documentElement.lang, noTitle: !document.title.trim(), h1: document.querySelectorAll("h1").length };
  const fa = textEls.filter(e => /[؀-ۿ]/.test(e.textContent));
  const rtl = { faElements: fa.length, faUnder12: fa.filter(e => parseFloat(getComputedStyle(e).fontSize) < minFont).length, faLetterSpacing: fa.filter(e => { const l = getComputedStyle(e).letterSpacing; return l !== "normal" && parseFloat(l) !== 0; }).length, faMiddleDot: fa.filter(e => /·/.test(e.textContent)).length, faInLtrBlock: fa.filter(e => getComputedStyle(e).direction === "ltr" && getComputedStyle(e).textAlign !== "center").length };
  const svgColors = { fill: uniq([...document.querySelectorAll("svg [fill]")].map(e => e.getAttribute("fill")).filter(c => /^#[0-9a-f]{3,8}$/i.test(c))), stroke: uniq([...document.querySelectorAll("svg [stroke]")].map(e => e.getAttribute("stroke")).filter(c => /^#[0-9a-f]{3,8}$/i.test(c))) };
  const tables = document.querySelectorAll("table").length, svgs = document.querySelectorAll("svg").length, canvases = document.querySelectorAll("canvas").length;
  return { textEls: textEls.length, vpNumeric: vp.filter(e => /\d/.test(e.textContent)).length, minPx: Math.min(...sizes), medianPx: med(sizes), maxPx: Math.max(...sizes), under12: sizes.filter(s => s < minFont).length, under12vp: vp.filter(e => parseFloat(getComputedStyle(e).fontSize) < minFont).length, distinctSizes: new Set(sizes.map(Math.round)).size, svgTextMinPx: svgT.length ? Math.min(...svgT) : null, placeholders: ph, flat: { gradient: flat.gradient.length, rgba: flat.rgba.length, shadow: flat.shadow.length, examples: { gradient: uniq(flat.gradient), rgba: uniq(flat.rgba), shadow: uniq(flat.shadow) } }, hScroll: document.documentElement.scrollWidth > innerWidth + 1, pageHeight: document.documentElement.scrollHeight, tap: tap.slice(0, 10), tapCount: tap.length, a11y, rtl, svgColors, charts: { svgs, canvases, tables },
    contrastInputs: textEls.map(e => ({ t: e.textContent.trim().slice(0, 28), fg: getComputedStyle(e).color, bg: effBg(e), size: parseFloat(getComputedStyle(e).fontSize), bold: +getComputedStyle(e).fontWeight >= 700 })) };
};
(async () => {
  const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}), report = [];
  for (const pg of pages) {
    const isUrl = /^https?:\/\//.test(pg), url = isUrl ? pg : "file://" + path.resolve(pg), name = (isUrl ? new URL(pg).pathname.replace(/\W+/g, "_") || "page" : path.basename(pg, path.extname(pg))) || "page", res = { page: pg, modes: {} };
    for (const [mode, w, h] of modes) {
      const theme = mode.split("-")[0], p = await b.newPage({ viewport: { width: w, height: h } }), errs = []; p.on("pageerror", e => errs.push(String(e))); p.on("requestfailed", r => errs.push("req " + r.url().slice(0, 80)));
      const S = cfg.themeStrategies, cmap = cfg.themeClassMap || Object.fromEntries(cfg.themes.map(t => [t, t]));
      if (S.includes("emulate")) await p.emulateMedia({ colorScheme: theme === "dark" ? "dark" : "light" });
      if (S.includes("storage") && cfg.themeStorageKey) await p.addInitScript(([k, v]) => { try { localStorage.setItem(k, v); } catch {} }, [cfg.themeStorageKey, (cfg.themeStorageValues || {})[theme] || theme]);
      const target = S.includes("query") ? url + (url.includes("?") ? "&" : "?") + cfg.themeQueryParam + "=" + theme : url;
      await p.goto(target, { waitUntil: "load" }).catch(e => errs.push("goto " + e.message)); await p.waitForTimeout(wait);
      await p.evaluate(([S, attr, cls, map, all, tgt, theme]) => { const els = tgt.map(t => t === "html" ? document.documentElement : document.querySelector(t)).filter(Boolean);
        if (S.includes("attribute")) document.documentElement.setAttribute(attr, theme);
        if (S.includes("class")) els.forEach(e => { Object.values(map).forEach(c => e.classList.remove(c)); e.classList.add(map[theme] || theme); }); }, [S, cfg.themeAttribute, null, cmap, cfg.themes, cfg.themeClassTarget, theme]);
      await p.waitForTimeout(150); await p.evaluate(() => document.fonts && document.fonts.ready);
      const r = await p.evaluate(`(${inPage.toString()})(${JSON.stringify({ minFont: cfg.minFontPx, minTap: cfg.minTapPx })})`);
      r.lowContrast = r.contrastInputs.map(o => { const f = rgb(o.fg), g = rgb(o.bg); if (!f || !g) return null; const ratio = cr(f, g), need = o.size >= 24 || (o.size >= 18.66 && o.bold) ? 3 : 4.5; return ratio < need ? `${ratio.toFixed(2)}:1 (need ${need}) "${o.t}"` : null; }).filter(Boolean); delete r.contrastInputs; r.errors = errs; r.pageBg = await p.evaluate(() => { for (const e of [document.body, document.documentElement]) { const c = getComputedStyle(e).backgroundColor; if (!/rgba\(.*,\s*0\)|transparent/.test(c)) return c; } return "rgb(255, 255, 255)"; });
      const shot = path.join(outDir, `${name}.${mode}.png`); await p.screenshot({ path: shot, fullPage: true }); r.screenshot = shot; res.modes[mode] = r; await p.close();
    }
    { const bgs = {}; for (const [k, m] of Object.entries(res.modes)) if (!k.endsWith("-mobile")) bgs[k] = m.pageBg; const vals = Object.values(bgs); res.themeSwitchEffective = vals.length < 2 || new Set(vals).size > 1; res.themeBackgrounds = bgs; }
    report.push(res);
  }
  await b.close(); fs.writeFileSync(path.join(outDir, "report.json"), JSON.stringify(report, null, 1));
  let md = "# Measured audit report (generated by tools/audit.js)\n\nEverything below is measured, not judged. Judgement goes in your audit using AUDIT-TEMPLATE.md. Thresholds: "+JSON.stringify({minFontPx:cfg.minFontPx,minTapPx:cfg.minTapPx,contrast:[cfg.contrastNormal,cfg.contrastLarge],flatDesign:cfg.flatDesign})+"\n\n";
  for (const r of report) {
    md += `\n## ${r.page}\n\n| metric | ${Object.keys(r.modes).join(" | ")} |\n|---|${Object.keys(r.modes).map(() => "---").join("|")}|\n`;
    const rows = [["min font px", m => +m.minPx.toFixed(1)], [`text < ${cfg.minFontPx}px (total / first viewport)`, m => `${m.under12} / ${m.under12vp}`], ["SVG text min px", m => m.svgTextMinPx && +m.svgTextMinPx.toFixed(1)], ["distinct font sizes", m => m.distinctSizes], ["numbers in first viewport", m => m.vpNumeric], ["low-contrast texts", m => m.lowContrast.length], [`gradient / rgba / shadow${cfg.flatDesign ? " (FAIL if >0: flatDesign)" : " (info)"}`, m => `${m.flat.gradient} / ${m.flat.rgba} / ${m.flat.shadow}`], ["placeholder texts", m => m.placeholders.length], ["horizontal scroll", m => m.hScroll ? "YES" : "no"], ["page height px", m => m.pageHeight], [`tap targets < ${cfg.minTapPx}px`, m => m.tapCount], ["a11y: img no alt / btn no name / input no label", m => `${m.a11y.imgNoAlt} / ${m.a11y.btnNoName} / ${m.a11y.inputNoLabel}`], ["a11y: lang missing / title missing / h1 count", m => `${m.a11y.noLang} / ${m.a11y.noTitle} / ${m.a11y.h1}`], ["charts: svg / canvas / table", m => `${m.charts.svgs} / ${m.charts.canvases} / ${m.charts.tables}`], ["Persian/Arabic text (if any): elements / under min / letter-spacing / middle-dot / in LTR block", m => `${m.rtl.faElements} / ${m.rtl.faUnder12} / ${m.rtl.faLetterSpacing} / ${m.rtl.faMiddleDot} / ${m.rtl.faInLtrBlock}`], ["page errors", m => m.errors.length]];
    if (!r.themeSwitchEffective) md += `\n> **WARNING: theme switching had no visible effect** (page background identical in every theme: ${JSON.stringify(r.themeBackgrounds)}). The light/dark rows are the same page. Set themeStrategies, themeClassMap or themeStorageKey in audit.config.json for this app, or audit each theme by hand.\n`;
    for (const [l, f] of rows) md += `| ${l} | ${Object.values(r.modes).map(f).join(" | ")} |\n`;
    for (const [k, m] of Object.entries(r.modes)) { if (m.lowContrast.length) md += `\n**${k} low contrast:** ${m.lowContrast.slice(0, 6).join("; ")}\n`; if (m.placeholders.length) md += `\n**${k} placeholders:** ${m.placeholders.slice(0, 8).join(", ")}\n`; if (m.tap.length) md += `\n**${k} small tap targets:** ${m.tap.slice(0, 5).join("; ")}\n`; if (m.errors.length) md += `\n**${k} errors:** ${m.errors.slice(0, 4).join("; ")}\n`; const sc = [...m.svgColors.fill, ...m.svgColors.stroke]; if (sc.length) md += `\n**${k} SVG colours (feed to validate_palette.mjs):** ${[...new Set(sc)].join(",")}\n`; }
  }
  fs.writeFileSync(path.join(outDir, "report.md"), md); console.log(md); console.log(`\nSaved: ${outDir}/report.md, report.json and PNG screenshots. LOOK at the PNGs before writing the audit.`);
})();
