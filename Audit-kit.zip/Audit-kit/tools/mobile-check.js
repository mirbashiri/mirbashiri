#!/usr/bin/env node
// Mobile / touch checks from emilkowalski/skills "mobile-native" that can be read from a rendered page. Usage:
//   node tools/mobile-check.js <page|url> --out DIR [--width 390] [--height 844] [--config FILE]
// Opens the page in Chromium with phone emulation (isMobile, hasTouch, DPR 3) and reports, as measured facts:
//   viewport meta (missing, user-scalable=no / maximum-scale<=1, viewport-fit=cover), layout width vs device width (a page with no
//   width=device-width meta lays out at ~980px), inputs/textarea/select with font-size < 16px (iOS zooms the page on focus),
//   `100vh` height rules (use dvh/svh), :hover rules not gated by (hover: hover), user-select:none on <body>, safe-area use vs viewport-fit,
//   horizontal scroll, tap targets under the config minimum and under 44px (the 44px figure is the kit's own M6 note, not from the skill).
//   Info only: -webkit-tap-highlight-color, theme-color per scheme, touch-action:manipulation, overscroll-behavior.
// HEURISTIC / LIMITS: static CSS + one emulated render. Chromium emulation does NOT reproduce sticky hover, tap delay, rubber-banding, the URL-bar effect on
// vh, the software keyboard or safe-area insets (the skill says so too: "test on real hardware"). We tapped a hover-styled element in emulation and :hover
// did not stick, so the ungated-hover finding is a CSS-reading rule, not a reproduced bug. Exit code 1 = at least one issue found (check semantics).
const path = require("path"), fs = require("fs"); let chromium; try { ({ chromium } = require("playwright")); } catch { console.error("playwright not found: sh tools/setup.sh"); process.exit(2); }
const { runStatic } = require("./lib/run-checks.js");
const a = process.argv.slice(2), opt = (n, d) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : d; }, vals = ["--out", "--width", "--height", "--config"], pg = a.find((x, i) => !x.startsWith("--") && !vals.includes(a[i - 1]));
if (!pg) { console.error("usage: node tools/mobile-check.js <page|url> --out DIR [--width 390 --height 844]"); process.exit(2); }
let cfg = { minTapPx: 24, minInputPx: 16, maxUiMotionMs: 300, maxMeasureCh: 80 }; try { cfg = { ...cfg, ...JSON.parse(fs.readFileSync(opt("--config", path.join(__dirname, "..", "audit.config.json")), "utf8")) }; } catch {}
const out = path.resolve(opt("--out", "mobile-out")), W = +opt("--width", 390), H = +opt("--height", 844); fs.mkdirSync(out, { recursive: true });
(async () => {
  const b = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}), ctx = await b.newContext({ viewport: { width: W, height: H }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 }), p = await ctx.newPage(), errs = []; p.on("pageerror", e => errs.push(String(e)));
  await p.goto(/^https?:\/\//.test(pg) ? pg : "file://" + path.resolve(pg), { waitUntil: "load" }).catch(e => errs.push("goto " + e.message)); await p.waitForTimeout(400); await p.evaluate(() => document.fonts && document.fonts.ready);
  const checks = await runStatic(p, cfg);
  const live = await p.evaluate(([minTap]) => { const vis = e => { const cs = getComputedStyle(e), r = e.getBoundingClientRect(); return cs.display !== "none" && cs.visibility !== "hidden" && r.width > 0 && r.height > 0; };
    const taps = [...document.querySelectorAll("a[href],button,[role=button],input:not([type=hidden]),select,textarea")].filter(vis).map(e => e.getBoundingClientRect());
    return { layoutWidth: document.documentElement.clientWidth, scrollWidth: document.documentElement.scrollWidth, innerWidth, hoverNone: matchMedia("(hover: none)").matches, pointerCoarse: matchMedia("(pointer: coarse)").matches, taps: taps.length, tapUnderMin: taps.filter(r => r.width < minTap || r.height < minTap).length, tapUnder44: taps.filter(r => r.width < 44 || r.height < 44).length }; }, [cfg.minTapPx]);
  await p.screenshot({ path: path.join(out, "mobile.png"), fullPage: true }); await b.close();
  const m = checks.mobile, vp = m.viewport, rows = [];
  const add = (id, bad, what, ev) => rows.push({ id, bad, what, ev });
  add("viewport meta present", !vp.present, "A viewport meta exists (without it phones lay the page out at ~980px and shrink it)", vp.present ? vp.content : "missing");
  add("layout width = device width", live.layoutWidth > W + 1, "Layout width equals the device width", `layout ${live.layoutWidth}px vs device ${W}px`);
  add("zoom not disabled", vp.zoomDisabled, "Zoom is not disabled: user-scalable=no / maximum-scale<=1 is an accessibility failure (skill Hard Rule 4); fix the input font size instead", vp.content || "-");
  add("inputs >= " + cfg.minInputPx + "px", m.inputsUnder16 > 0, "Inputs are 16px or larger (iOS Safari zooms into smaller ones on focus and does not zoom back)", `${m.inputsUnder16} of ${m.inputCount}: ${m.inputsUnder16Examples.join("; ") || "-"}`);
  add("no 100vh height rules", m.vh100Count > 0, "No 100vh heights (100vh is the largest viewport on mobile; use 100dvh for an app shell, 100svh for a hero)", m.vh100.join("; ") || "-");
  add(":hover gated by (hover: hover)", m.hoverUngatedCount > 0, "Every :hover rule sits inside @media (hover: hover) (ungated hover sticks after a tap on real phones)", `${m.hoverUngatedCount} rule(s): ${m.hoverUngated.slice(0, 5).join("; ") || "-"}`);
  add("body not user-select:none", m.userSelectNoneBody, "Body text stays selectable (only controls get user-select:none)", m.userSelectNoneBody ? "body is none" : "ok");
  add("safe area: cover => env()", m.safeArea.coverWithoutEnv, "If viewport-fit=cover is set, env(safe-area-inset-*) is used (else fixed bars sit under the notch / home indicator)", String(m.safeArea.coverWithoutEnv));
  add("safe area: env() => cover", m.safeArea.envWithoutCover, "If env(safe-area-inset-*) is used, viewport-fit=cover is set (else every inset is 0)", String(m.safeArea.envWithoutCover));
  add("no horizontal scroll", live.scrollWidth > W + 1, "No sideways scroll at phone width", `scrollWidth ${live.scrollWidth}px vs ${W}px`);
  add("tap targets >= " + cfg.minTapPx + "px", live.tapUnderMin > 0, "Tap targets at least the config minimum", `${live.tapUnderMin} of ${live.taps}`);
  const issues = rows.filter(r => r.bad), info = [`tap targets under 44px: ${live.tapUnder44} of ${live.taps} (kit's M6 note: prefer 44px on mobile; not from the skill)`, `-webkit-tap-highlight-color: ${m.info.tapHighlight} (skill: set it to transparent and give every tappable element its own :active state; the browser default is a translucent highlight)`, `theme-color tags: ${m.info.themeColorTags}${m.info.themeColorPerScheme ? " (per scheme)" : " (skill: one per prefers-color-scheme)"}`, `touch-action: manipulation present: ${m.info.touchActionManipulation}`, `overscroll-behavior present: ${m.info.overscrollBehavior}`, `emulation: (hover: none) ${live.hoverNone}, (pointer: coarse) ${live.pointerCoarse}`];
  let md = `# Mobile check — ${pg}\n\nEmulated phone ${W}x${H} (touch, DPR 3). **${issues.length} issue(s)** from ${rows.length} checks.\n\n| check | result | why it matters | evidence |\n|---|---|---|---|\n` + rows.map(r => `| ${r.id} | ${r.bad ? "**ISSUE**" : "ok"} | ${r.what} | ${r.ev} |`).join("\n") + `\n\n**Info (not counted):**\n` + info.map(x => "- " + x).join("\n") + (checks.css.unreadable ? `\n\n> ${checks.css.unreadable} stylesheet(s) unreadable through the CSSOM: CSS-rule checks may be incomplete.` : "") + (errs.length ? `\n\nPage errors: ${errs.slice(0, 3).join("; ")}` : "") + `\n\n**Not verifiable here:** sticky hover, tap delay, rubber-banding, URL-bar/vh behaviour, keyboard, safe-area insets, real touch feel. Test on a phone (skill: "real hardware is the bar"). Screenshot: mobile.png\n`;
  fs.writeFileSync(path.join(out, "report.md"), md); fs.writeFileSync(path.join(out, "report.json"), JSON.stringify({ page: pg, width: W, height: H, live, mobile: m, issues: issues.map(r => r.id) }, null, 1)); console.log(md); process.exit(issues.length ? 1 : 0);
})();
