# Your app's rules (fill this in — the audit judges against it)

An audit is only as good as the rules it checks against. Replace the examples below with your own, or copy `profiles/example-synek/rules.md` as a worked example. Agents: if this file is still unfilled, audit against generic best practice (WCAG, `references/`) and **say so**.

## Brand / tokens
- Theme(s): <dark / light / both>. Tokens file: <path>. Rule: use tokens, never raw hex.
- Colour meaning (e.g. green = good, red = bad, one accent colour): <…>

## Style rules
- Flat design? <yes/no> (if yes set `"flatDesign": true` in `audit.config.json`: gradients/rgba/shadows become failures)
- Minimum text size: <px> (set `minFontPx`)
- Language / direction: <LTR / RTL / both>

## Layout & content rules
- One primary element per page: <yes/no>
- Banned UI words (e.g. internal build notes): <…>

## Known data caveats
- <sample data? approximate values?>
