# algorithmic-art

- **منبع:** https://github.com/anthropics/skills/tree/dbd4588/skills/algorithmic-art
- **کامیت:** `dbd4588` · **لایسنس:** Apache-2.0
- **وضعیت:** کپی شده، تست نشده
