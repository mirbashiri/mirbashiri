# Leonxlnx/taste-skill (MIT)

- **Upstream:** the "Taste Skill" repository (MIT, Copyright (c) 2026 Leonxlnx; see `LICENSE`). The copy given to us had no git metadata and its README names no GitHub path we could verify, so the exact URL and commit are not recorded [unknown].
- **Copied (text only):** `redesign-skill/SKILL.md`, `output-skill/SKILL.md` plus `output-skill/research-laziness/` (the repo's `research/laziness` notes), `taste-skill/SKILL.md`, `minimalist-skill/SKILL.md`, `brutalist-skill/SKILL.md`.
- **Omitted:** README banners/sponsor images, taste-skill-v1, gpt-tasteskill, soft-skill, image-to-code-skill, imagegen-frontend-web/mobile, brandkit, stitch-skill (need image generation / Stitch, or are style packs the kit cannot measure). Reasons: `docs/skills-integration.md`.
- **Used by:** mode `polish-check` and the typography/copy rows of `tools/audit.js` (redesign-skill, taste-skill 4.5 / 9.D / 9.G), `tools/completeness.js` (output-skill), `prototype-variants` and `site-build` as optional style directions (minimalist, brutalist).
- **Kit note:** the research notes quote effect sizes for prompt tricks ("$200 tip", "+45%") that we did NOT reproduce; the kit does not rely on them.
