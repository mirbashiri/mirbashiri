# diagram-design

- **منبع:** https://github.com/cathrynlavery/diagram-design/tree/356c86b/skills/diagram-design
- **کامیت:** `356c86b` · **لایسنس:** MIT
- **وضعیت:** تست ۰۱ (quadrant فارسی) انجام شد
