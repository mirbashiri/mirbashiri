# claude-design-skill

- **منبع:** https://github.com/jiji262/claude-design-skill/tree/35a20e5/
- **کامیت:** `35a20e5` · **لایسنس:** MIT
- **وضعیت:** کپی شده، تست نشده
