# emilkowalski/skills (MIT)

- **Upstream:** https://github.com/emilkowalski/skills (MIT, Copyright (c) 2026 Emil Kowalski; see `LICENSE`). The copy given to us had no git metadata, so no commit hash is recorded [unknown].
- **Copied (text only):** `break-ui/` (SKILL.md, CATALOG.md), `mobile-native/SKILL.md`, `review-animations/` (SKILL.md, STANDARDS.md), `improve-animations/` (SKILL.md, AUDIT.md, PLAN-TEMPLATE.md), `find-animation-opportunities/SKILL.md`, `emil-design-eng/SKILL.md`, `prototype/` (SKILL.md, PICKER.md), `performance-cheatsheet.md`.
- **Omitted:** README images and screenshots, the Persian README, and the skills the kit does not use: animate, animate-expo (React Native), animation-vocabulary, apple-design, ask-sonner, pick-ui-library, write-swift. Reasons: `docs/skills-integration.md`.
- **Used by:** modes `break-test` (break-ui), `mobile-check` (mobile-native), `motion-review` (review-animations, improve-animations, find-animation-opportunities, emil-design-eng), `prototype-variants` (prototype).
- **Kit note:** some advice in these files (translucent shadows instead of borders, rgba/backdrop-blur picker) contradicts the kit's flat defaults. It is optional per app; see `docs/skills-integration.md`.
