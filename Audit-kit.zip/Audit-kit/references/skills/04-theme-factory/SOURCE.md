# theme-factory

- **منبع:** https://github.com/anthropics/skills/tree/dbd4588/skills/theme-factory
- **کامیت:** `dbd4588` · **لایسنس:** Apache-2.0
- **وضعیت:** کپی شده، تست نشده
