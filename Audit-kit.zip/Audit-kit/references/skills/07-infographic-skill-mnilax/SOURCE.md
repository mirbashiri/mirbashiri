# infographic-skill

- **منبع:** https://github.com/Mnilax/infographic-skill/tree/33d704f/
- **کامیت:** `33d704f` · **لایسنس:** MIT
- **وضعیت:** کپی شده؛ اسکریپت‌ها خوانده/اجرا نشده (نیاز به npm: @resvg/resvg-js, docx)
