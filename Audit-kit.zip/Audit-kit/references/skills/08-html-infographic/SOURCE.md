# html-infographic

- **منبع:** https://github.com/mitchelfletcher11/html-infographic (کامیت `7469d26`)
- **لایسنس:** ندارد → **کپی نشد** (بدون لایسنس، اجازهٔ بازنشر نداریم). فقط لینک.
- خلاصه: یک فایل HTML تک‌صفحه با SVG و انیمیشن Anime.js، فونت Inter، تم تیره.
