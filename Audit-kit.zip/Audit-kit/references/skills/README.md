# Copied design skills (text only)

Copies of `SKILL.md`, licences, and small reference/script files of ten open-source design skills, so agents can follow them offline. **Omitted on purpose** (size): fonts, templates, images, large assets (canvas-design fonts, diagram-design assets, amigoscode templates, theme-showcase PDF). Each folder's `SOURCE.md` has the upstream repo and commit to fetch the full skill.
Test results for each skill: the Synek `skills-lab/README.md` (not included in this kit). Status: copied, behaviour verified only where the original skills-lab tests say so.
