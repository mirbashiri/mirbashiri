# Copied design skills (text only)

Copies of `SKILL.md`, licences, and small reference/script files of **twelve** open-source skill packs (ten originals + emilkowalski/skills + taste-skill), so agents can follow them offline. **Omitted on purpose** (size): fonts, templates, images, large assets (canvas-design fonts, diagram-design assets, amigoscode templates, theme-showcase PDF, upstream README images). Each folder's `SOURCE.md` has the upstream repo and what was copied or omitted.

| folder | skills copied | used by |
|---|---|---|
| `01`-`10` | canvas-design, frontend-design, algorithmic-art, theme-factory, brand-guidelines, diagram-design, infographic skills | poster, infographic, diagram, deck, art, brand, themes, site-build modes |
| `11-emilkowalski/` | break-ui, mobile-native, review-animations, improve-animations, find-animation-opportunities, emil-design-eng, prototype | `break-test`, `mobile-check`, `motion-review`, `prototype-variants` |
| `12-taste-skill/` | redesign-skill, output-skill (+ laziness research), taste-skill, minimalist-skill, brutalist-skill | `polish-check`, `completeness.js`, optional style directions |

Which skills were adopted, adapted or skipped, and why: [`docs/skills-integration.md`](../../docs/skills-integration.md). Test results for the original ten: the Synek `skills-lab/README.md` (not included in this kit). Status: copied, behaviour verified only where the original skills-lab tests or `docs/skills-integration.md` say so.
