# infographics-skill

- **منبع:** https://github.com/amigoscode/infographics-skill/tree/90b4791/
- **کامیت:** `90b4791` · **لایسنس:** MIT
- **وضعیت:** کپی شده؛ نیاز به کلید Gemini — اینجا قابل اجرا نیست
