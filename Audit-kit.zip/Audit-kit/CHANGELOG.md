# Changelog

Version rule (see IRON-RULES.md): starts at 1.00; every edit that is committed adds 0.01 (1.00 → 1.01 → … → 1.99 → 2.00). Entries are written by `tools/bump-version.js`.

## v1.00 — 2026-10-15 — baseline
Versioning introduced. State at this version: 22 modes in 5 groups, tools (audit, sweep, kit runner, interact, rtl, slides, themes, mobile, motion with page driving, break-data/worst-case, variants, completeness, palette, images), docs/, landing page (docs/index.html), GitHub examples (CI, Pages, pre-commit), references (10 + 2 skill packs, text only). Fresh-agent tests: 13 of 22 modes.
