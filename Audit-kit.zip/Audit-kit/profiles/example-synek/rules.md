# Synek design rules (what "correct" means in an audit)

- **Flat:** no gradients, no rgba, no shadows. Tints are solid `-tint` tokens. Logos are used as-is (their internal opacity is an accepted exception, owner decision 2026-10-13).
- **Colour meaning:** green = profit, red = loss (money only). Cyan = long, violet = short. Amber = warning only. One accent per app. Palettes are fixed by the owner; do not propose new brand colours (chart-series colours may be proposed after validation).
- **Themes:** Graphite (dark, default) and Paper Teal (light). Tokens in `../tokens/tokens.css`, roles and contrast in `../tokens/palette.json`. Use tokens, never raw hex, in pages.
- **Type:** ≥ 12px everywhere (SVG and Persian included); few distinct sizes; tabular numerals for numbers.
- **Charts:** form before colour; ≤ 24px bars; 2px lines; 2px gaps; tooltip + keyboard parity + table twin; direct labels where CVD distance is low (see `dataviz/`).
- **Layout:** one primary element per page; sortable table instead of many tiny tiles; group identical rows; no-data state in one line, not a whole card.
- **No build-process language in UI** ("Phase B", "needs decision #11", "Not tracked").
- **Persian/RTL:** see `synek-fa.md` (per-element `dir`, no letter-spacing, word-spacing 0.15–0.2em, no `·` in Persian text, Latin IDs isolated).
- **Known data caveats:** shadow-mode data; Trade-archive and Analytics sample values are approximations.
