# Mode: app-sweep — the whole app

**Goal:** audit every reachable page, rank them, and find problems that exist *across* pages (inconsistent fonts, radii, colours; the same defect repeated in a shared component). **Read-only: change nothing.**

**Inputs (ask only if missing):** the app: a start URL (crawl), a folder of HTML, or a `list.txt` of pages/URLs (one per line). For pages behind login, the user must supply a list/folder or saved HTML; the crawler does not log in.

## Steps
1. `sh tools/selftest.sh` (once).
2. `node tools/sweep.js <start-url|folder|list.txt> --mode app-sweep --out sweep-out [--depth 2 --max 30 --exclude 'template|partial']`. Exclude HTML fragments/templates, otherwise they are audited as pages.
3. Read `sweep-out/summary.md`. Take the 3–5 worst pages and re-run them with mobile: `node tools/audit.js <page> --out deep/<name>` (mobile is off in app-sweep for speed).
4. Look at the screenshots of the worst pages and of one typical page.
5. Separate findings into **(a) shared** (appear on several pages, fix once in a component/token: repeated low-contrast text, drifting radii, extra font families, off-token colours) and **(b) page-specific**.
6. Check the nav/header/footer across pages in screenshots: same position, same states?
7. Write `sweep-out/app-audit.md`.

## Output (fixed format)
```
# App audit — <app> — <date>
Scope: pages found/audited/skipped (why) · crawl depth · logged-in pages not covered
## Worst first
## Shared problems (fix once)   | problem | pages affected | evidence | fix | confidence |
## Page ranking (from summary.md) + one line per page
## Page-specific top 3 for the 3–5 worst pages
## Not verified
```

## Done when
The page count in the report matches what you actually audited; skipped/failed pages are named; shared problems cite at least two pages each.
