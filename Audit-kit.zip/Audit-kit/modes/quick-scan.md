# Mode: quick-scan — small errors on ONE page

**Goal:** find the small, concrete defects on a single page: wrong/odd font sizes and families, off-token or off-palette colours, low contrast, inconsistent or off-grid spacing, inconsistent radii, tiny tap targets, a11y basics. **Read-only: change nothing.**

**Inputs (ask the user only if missing):** the page (file path or URL). Optional: `RULES.md` filled, tokens file (set `tokensFile` in `audit.config.json` so off-token colours are detected).

## Steps
1. `sh tools/selftest.sh` (once). If it fails, fix per its message or report what could not run.
2. `node tools/audit.js <page> --mode quick-scan --out audit-out` → `report.md`, `report.json`, screenshots (every theme + mobile).
3. **Look at the screenshots.** Numbers don't show everything.
4. For each defect category in the report build a fix list. Be exact: element selector, current value, expected value (from tokens/`RULES.md`, or the nearest scale step if none).
   - Fonts: sizes under the minimum; more than 5–6 distinct sizes; more than 2 families; mixed sizes for the same role.
   - Colours: texts under contrast; hex values not in tokens (`off-token`), near-duplicates (e.g. `#777` vs `#767676`); meaning-colours used decoratively (per `RULES.md`).
   - Spacing: off-grid values (listed in report), same role with different paddings, uneven gaps in a repeated list.
   - Radii: more than 2–3 distinct values.
   - Tap targets, a11y (alt, labels, lang, title, h1).
5. If chart colours exist, run `node tools/validate_palette.mjs "<hexes>" --mode <dark|light> --surface "<hex>"` per theme.
6. Write `audit-out/quick-scan.md` using the table below; sort by visibility (what a user notices first), not by count.

## Output (fixed format)
```
# Quick scan — <page> — <date>
Scope · tools run · what you could not run
## Worst first (1–3 sentences, plain)
## Fix list
| # | category | where (selector/area) | now | should be | confidence | effort (S/M/L) |
## Measured summary (paste the table from report.md)
## Not verified
```
Every row has a confidence tag [certain]/[likely]/[guess]. "should be" must come from tokens/RULES or a stated assumption.

## Done when
Every number you quote exists in `report.md` or a screenshot you looked at; unverified items are listed.
