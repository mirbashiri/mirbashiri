# Mode: chart-review — every chart on a page

**Goal:** judge each chart for form, colour, marks, labels, interaction, and measure what can be measured. Read-only.

## Steps
1. `node tools/audit.js <page> --out audit-out` and look at the PNGs (note `charts: svg/canvas/table` row).
2. List the charts: question each answers → form used → better form? (`references/dataviz/choosing-a-form.md`).
3. Palette: take the SVG colours from the report per chart (only colours that share a plot) → `node tools/validate_palette.mjs "<hexes>" --mode dark|light --surface "<hex>"`. Status colours (good/bad) are checked as text/contrast, not as a categorical palette.
4. Marks and anatomy (`references/dataviz/marks-and-anatomy.md`, `anti-patterns.md`): thick saturated blocks, gradients, dual axes, 3D, truncated axes, single-bar histograms, labels overlapping (`node tools/check-labels.js <svg-page.html>` if the charts are SVG).
5. Interaction (`references/dataviz/interaction.md`): tooltip, keyboard parity, table twin — only claim what you actually tried.
6. Write `audit-out/chart-review.md`: per chart `| chart | question | form ok? | palette result | marks issues | interaction | fix | confidence |`, worst first, then Not verified.
