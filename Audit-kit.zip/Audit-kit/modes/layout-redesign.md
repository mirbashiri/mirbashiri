# Mode: layout-redesign — audit the layout, then deliver an edited page image

**Goal:** audit a page's layout (hierarchy, density, structure, chart form, colour meaning), propose a better layout, **build it as a separate redesigned page**, render it, prove with measurements that it is not worse, and hand over a before/after image. The original is never overwritten.

**Inputs (ask only if missing):** the page + its real data (do not invent data); `RULES.md` filled (tokens, colour meaning, banned words); whether the user wants (A) a mockup image/HTML only [default] or (B) the change applied to the app's real source (only if the user says so and the source is available).

## Steps
1. `sh tools/selftest.sh` (once).
2. **Before:** `node tools/audit.js <page> --mode quick-scan --out redesign/before` (all themes + mobile). Look at the PNGs.
3. **Audit the layout** with `AUDIT-CHECKLIST.md` Step 3 + `references/skills/02-frontend-design/SKILL.md` + `references/dataviz/anti-patterns.md`: what is the page *for*? Is that the biggest/first thing? Equal-weight cards? Dead space? Repeated identical rows? Wrong chart forms? Build-process language? Decorative colour?
4. **Plan:** write `redesign/plan.md`: 3–7 changes, each = finding (with evidence) → change → expected effect. Keep the data and the page's job unchanged. One primary element per page; group repeated rows; no-data states in one line; sortable table instead of many small tiles, where it fits.
5. **Build:** create `redesign/after/index.html` (self-contained; tokens from the app's tokens file, never raw hex; real data embedded; same theme mechanism so the audit can switch themes). Do not touch the original.
6. **After:** `node tools/audit.js redesign/after/index.html --mode quick-scan --out redesign/after-audit`. Compare to `before`: contrast, min font, tap targets, off-grid, off-token, a11y, h-scroll, page height, first-viewport numbers. **Any metric that got worse must be explained in the report** (or fixed).
7. **Image:** `node tools/shot.js redesign/after/index.html redesign/after-dark.png --theme dark --full` (and light/mobile), then `node tools/compare.js redesign/before/<page>.dark.png redesign/after-dark.png redesign/before-after-dark.png`.
8. Look at the images yourself. Fix overlaps/clipping, re-render.
9. Write `redesign/redesign-report.md`.

## Deliverables (in `redesign/`)
- `before-after-dark.png` (+ light/mobile if the app has them) — the image the user asked for
- `after/index.html` — the redesigned page (mockup unless option B)
- `plan.md`, `redesign-report.md` (changes · metrics before/after table · what is mockup vs real code · not verified)

## Rules
- Redesign the layout, not the brand: colours/logo/palette stay as in `RULES.md`/tokens unless the user asks.
- Never invent data. Missing data → say so on the page and in the report.
- The mockup is not the app: state clearly that real-app behaviour (routing, state, API) was not implemented or tested.
- Tag claims [certain]/[likely]/[guess]; unpleasant findings first.

## Done when
The before/after image exists and you looked at it; the metrics table shows no unexplained regression; "Not verified" lists interactions you did not test.
