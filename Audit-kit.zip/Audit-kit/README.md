# Audit-kit — measure and improve the quality of any app's pages

A self-contained kit any agent (or person) can drop into any project to audit pages **with measurements, not opinions**, and report in one fixed format. App-agnostic: your app's own rules go in `RULES.md` and `audit.config.json`. Nothing outside this folder is required.

## Start here
1. Fill in `RULES.md` (5 minutes) and adjust `audit.config.json` if needed.
2. Paste `PROMPT.md` to the agent with the pages to audit.
3. The agent follows `AUDIT-CHECKLIST.md` and writes `audit-out/audit.md` from `AUDIT-TEMPLATE.md`.

## Contents
| path | what | why |
|---|---|---|
| `PROMPT.md` | prompt to paste | one-step start |
| `RULES.md` | **your** app's rules (template) | what "correct" means for this app |
| `audit.config.json` | thresholds: min font, tap size, contrast, flat design on/off, themes, viewports | tune without editing code |
| `AUDIT-CHECKLIST.md` | ordered method: rules → capture → mechanical checks M1–M11 → judgement → write → limits | keeps agents from judging by eye |
| `AUDIT-TEMPLATE.md` | output format | comparable audits |
| `tools/audit.js` | renders every theme × viewport, screenshots, measures fonts, contrast, tap targets, a11y basics, overflow, placeholders, style-rule violations, SVG colours, RTL/Persian rules | the measuring instrument |
| `tools/validate_palette.js` (+ `.py`) | chart-palette validator: lightness band, chroma floor, colour-blind distance, contrast | computes instead of eyeballing |
| `tools/check-labels.js` | SVG label overlap/overflow | for SVG charts/diagrams |
| `tools/selftest.sh` | checks tools run here | run first |
| `references/dataviz/*.md` | chart anti-patterns, choosing a form, colour formula, marks, interaction | judgement rules for charts |
| `references/frontend-design/SKILL.md` | layout principles, AI-default tells | judgement rules for layout |
| `profiles/example-synek/` | a worked example of an app profile (rules, tokens, palette, Persian/RTL rules) | copy its structure for your app |
| `examples/example-audit.md` | a finished audit of five real pages | depth/style to match |
| `examples/example-ab-test.md` | how a comparison test is reported with caveats | honesty standard |
| `examples/sample-page.html` | known-good page for `selftest.sh` | calibration |

## Requirements
Node ≥ 18 and Playwright with Chromium (`NODE_PATH=$(npm root -g)` if installed globally). Pages open locally; live URLs need network access.

## Quick use
```
cd Audit-kit
sh tools/selftest.sh
NODE_PATH=$(npm root -g) node tools/audit.js /path/page1.html https://host/page2 --out audit-out
node tools/validate_palette.js "#0aa0ba,#7a5af0" --mode dark --surface "#151819"
```
Flags: `--out DIR`, `--config FILE`, `--no-mobile`, `--wait MS` (async rendering).

### Theme switching (works with most apps)
`audit.js` applies every strategy listed in `themeStrategies` (default: `query`, `attribute`, `class`, `emulate`):
| strategy | what it does | tested with |
|---|---|---|
| `query` | opens `page?theme=dark` (name in `themeQueryParam`) | yes |
| `attribute` | sets `<html data-theme="dark">` (name in `themeAttribute`) | yes |
| `class` | toggles `dark`/`light` class on `html`/`body` (`themeClassTarget`, custom names via `themeClassMap`, e.g. `{"dark":"theme-night","light":"theme-day"}`) | yes (default names) |
| `emulate` | emulates `prefers-color-scheme` | yes |
| `storage` | sets `localStorage[themeStorageKey]` before load (`themeStorageValues` maps theme→value) | yes |

**Safety net:** after rendering, the runner compares the page background across themes. If identical, the report shows a **WARNING: theme switching had no visible effect**, so a "light" screenshot that is really dark is never silently trusted. Then set the strategy for your app, or audit each theme by hand.

## Limits (be honest about them)
- It cannot judge hierarchy, meaning of colour, or whether a chart form fits the question; the checklist makes the agent justify those from screenshots.
- It does not test interactions (hover, keyboard, sort/filter); the agent must state what it did not click.
- Contrast uses computed colours on solid backgrounds; text over images or semi-transparent layers can be misjudged.
- Theme switching that depends on a user action (a toggle button, a login-bound preference) is not covered; use `storage`/`class` config or capture that theme manually.
- It audits; it does not redesign or change code.

## Provenance
`tools/validate_palette.*` and `references/dataviz/` are copied from the `dataviz` skill bundled with Claude Code (v2.1.296, 2026-10-13); check its licence before redistributing the kit publicly. `references/frontend-design/` is Anthropic's `frontend-design` skill (Apache-2.0; see its `LICENSE.txt`/`SOURCE.md`). Everything else (`tools/audit.js`, `check-labels.js`, templates, checklist) is original to this kit.
