# Audit-kit — measure and improve the quality of any app's pages

**Version <!-- ak-version -->v1.00<!-- /ak-version -->** · see [CHANGELOG.md](CHANGELOG.md) and [IRON-RULES.md](IRON-RULES.md) (every committed edit adds 0.01)

A self-contained kit any agent (or person) can drop into any project to audit pages **with measurements, not opinions**, and report in one fixed format. App-agnostic: your app's own rules go in `RULES.md` and `audit.config.json`. Nothing outside this folder is required.

**Full documentation:** [`docs/README.md`](docs/README.md) (getting started, the 22 modes with example images, tools reference, configuration, GitHub integration, evidence, limits). Landing page: `docs/index.html`.

## Start here (shortcuts)
Pick a mode from `MODES.md` and tell the agent: *"Use Audit-kit mode `quick-scan` on `<page>`"*. 22 modes: audit (quick-scan, app-sweep, chart-review, rtl-check, interaction-test, mobile-check, motion-review, break-test, polish-check), build/redesign (layout-redesign, site-build, theme-variants, controls-review, prototype-variants), static graphics (poster, infographic, diagram, deck, generative-art), brand & handoff (brand-kit, handoff-writer), meta (skill-ab). Run any with `node tools/kit.js run <mode> <target>`; it executes the automatic steps and writes a `RUNBOOK.md` with the checklist. The core is still fully manual: see below.

## Start here (manual)
1. Fill in `RULES.md` (5 minutes) and adjust `audit.config.json` if needed.
2. Paste `PROMPT.md` to the agent with the pages to audit.
3. The agent follows `AUDIT-CHECKLIST.md` and writes `audit-out/audit.md` from `AUDIT-TEMPLATE.md`.

## Contents
| path | what | why |
|---|---|---|
| `MODES.md` + `modes/` | ready-made jobs (quick-scan, app-sweep, layout-redesign, chart-review) | no need to explain the job each time |
| `PROMPT.md` | prompt to paste | one-step start |
| `RULES.md` | **your** app's rules (template) | what "correct" means for this app |
| `audit.config.json` | thresholds: min font, tap size, contrast, flat design on/off, themes, viewports | tune without editing code |
| `AUDIT-CHECKLIST.md` | ordered method: rules → capture → mechanical checks M1–M11 → judgement → write → limits | keeps agents from judging by eye |
| `AUDIT-TEMPLATE.md` | output format | comparable audits |
| `tools/audit.js` | renders every theme × viewport, screenshots, measures fonts, contrast, tap targets, a11y basics, overflow, placeholders, style-rule violations, spacing grid, colour/radius/font inventory (vs your tokens), SVG colours, RTL/Persian rules | the measuring instrument |
| `tools/kit.js` | runs a mode: `list`, `show`, `run`, `verify`, `index` | the mode runner |
| `tools/interact.js`, `tools/rtl-check.js`, `tools/slides.js`, `tools/themes.js`, `tools/contact-sheet.js`, `tools/palette-tools.js`, `tools/compare-metrics.js`, `tools/validate-report.js` | keyboard/hover, RTL, per-slide, theme variants, image grid, contrast matrix/CSS, before/after metrics, validator on audit output | the building blocks of the modes |
| `references/skills/` | text of the open-source design skills: ten originals + emilkowalski/skills + taste-skill (fonts/assets/images omitted) | poster, infographic, diagram, deck, art, brand, themes, mobile-check, motion-review, break-test, polish-check, prototype-variants modes |
| `tools/lib/checks.js`, `tools/mobile-check.js`, `tools/motion-check.js` | static mobile/touch, motion, typography and copy checks (rows in `audit.js`) + phone-emulation and motion reports | mobile-check, motion-review, polish-check modes |
| `tools/break-data.js`, `tools/worst-case.js` | realistic worst-case fixtures + injection into a page and a "what broke" diff | break-test mode |
| `tools/variants.js`, `tools/completeness.js` | flat variant switcher + per-variant measurement; anti-truncation scan of built files | prototype-variants, polish-check |
| `tools/sweep.js` | audits many pages (crawl / folder / list), ranks them, finds cross-page inconsistency | whole-app mode |
| `tools/shot.js`, `tools/compare.js` | screenshot a page; labelled before/after image | redesign deliverable |
| `tools/validate_palette.mjs` (+ `.py`, + `validate_palette.browser.js` for in-browser use) | chart-palette validator: lightness band, chroma floor, colour-blind distance, contrast | computes instead of eyeballing |
| `tools/check-labels.js` | SVG label overlap/overflow | for SVG charts/diagrams |
| `tools/selftest.sh` | checks tools run here | run first |
| `references/dataviz/*.md` | chart anti-patterns, choosing a form, colour formula, marks, interaction | judgement rules for charts |
| `references/skills/02-frontend-design/SKILL.md` | layout principles, AI-default tells | judgement rules for layout |
| `profiles/example-synek/` | a worked example of an app profile (rules, tokens, palette, Persian/RTL rules) | copy its structure for your app |
| `examples/example-audit.md` | a finished audit of five real pages | depth/style to match |
| `examples/example-ab-test.md` | how a comparison test is reported with caveats | honesty standard |
| `examples/sample-page.html` | known-good page for `selftest.sh` | calibration |

## Requirements and setup
Node ≥ 18 (check with `node --version`). Playwright + Chromium: run **`sh tools/setup.sh`** once (installs Playwright next to the kit, no global install; needs network once). Then `sh tools/selftest.sh` tells you exactly what is missing. Pages open locally; live URLs need network access.

**Offline / no network:** use a Playwright/Chromium that already exists: set `NODE_PATH=$(npm root -g)` for a global Playwright, and `CHROMIUM_PATH=/path/to/chromium` (or `PLAYWRIGHT_BROWSERS_PATH`) for the browser binary. Without any browser, `audit.js` cannot run: `validate_palette.mjs` and `check-labels`-free steps still work, and the agent must say the capture/measure step was not done instead of estimating numbers.

## Quick use
```
cd Audit-kit
sh tools/setup.sh      # once
sh tools/selftest.sh
node tools/audit.js /path/page1.html https://host/page2 --out audit-out
node tools/validate_palette.mjs "#0aa0ba,#7a5af0" --mode dark --surface "#151819"
```
Flags: `--out DIR`, `--config FILE`, `--no-mobile`, `--wait MS` (async rendering), `--fail-on KEYS`.

### Theme switching (works with most apps)
`audit.js` applies every strategy listed in `themeStrategies` (default: `query`, `attribute`, `class`, `emulate`):
| strategy | what it does | tested with |
|---|---|---|
| `query` | opens `page?theme=dark` (name in `themeQueryParam`) | yes |
| `attribute` | sets `<html data-theme="dark">` (name in `themeAttribute`) | yes |
| `class` | toggles `dark`/`light` class on `html`/`body` (`themeClassTarget`, custom names via `themeClassMap`, e.g. `{"dark":"theme-night","light":"theme-day"}`) | yes (default names) |
| `emulate` | emulates `prefers-color-scheme` | yes |
| `storage` | sets `localStorage[themeStorageKey]` before load (`themeStorageValues` maps theme→value) | yes |

**Safety net:** after rendering, the runner compares the page background across themes. If identical, the report shows a **WARNING: theme switching had no visible effect**, so a "light" screenshot that is really dark is never silently trusted. Then set the strategy for your app, or audit each theme by hand.

## Limits (be honest about them)
- It cannot judge hierarchy, meaning of colour, or whether a chart form fits the question; the checklist makes the agent justify those from screenshots.
- It does not test interactions (hover, keyboard, sort/filter); the agent must state what it did not click.
- Contrast uses computed colours on solid backgrounds; text over images or semi-transparent layers can be misjudged.
- Theme switching that depends on a user action (a toggle button, a login-bound preference) is not covered; use `storage`/`class` config or capture that theme manually.
- It audits; it does not redesign or change code.

## Provenance
`tools/validate_palette.*` and `references/dataviz/` are copied from the `dataviz` skill bundled with Claude Code (v2.1.296, 2026-10-13); check its licence before redistributing the kit publicly. `references/skills/02-frontend-design/` is Anthropic's `frontend-design` skill (Apache-2.0; see its `LICENSE.txt`/`SOURCE.md`). `references/skills/11-emilkowalski/` is emilkowalski/skills and `references/skills/12-taste-skill/` is taste-skill (both MIT, licence files kept; see `docs/skills-integration.md`). Everything else (`tools/audit.js`, `check-labels.js`, the new check/worst-case/variants tools, templates, checklist) is original to this kit.
