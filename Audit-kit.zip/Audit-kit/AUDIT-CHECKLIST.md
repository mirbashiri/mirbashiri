# Audit checklist — order matters

Rule 0: **measure first, judge second.** A claim without a number or a screenshot you looked at is a guess; label it [guess].
Confidence labels on every claim: **[certain]** (measured/seen) · **[likely]** (inferred) · **[guess]**. If most of a finding is a guess, say so first.

## Step 0 — Read the rules
Read `RULES.md` (the app's own rules) and `audit.config.json` (thresholds). If `RULES.md` is unfilled, audit against generic best practice and say so.

## Step 1 — Capture (≈2 min)
1. Get each page running (real app preferred; static HTML/screenshots only = say so, you can then audit looks, not code).
2. `node tools/audit.js <page(s)> --out audit-out` → dark, light, mobile PNGs + `report.md`.
3. **Open the PNGs and look at them.** Numbers don't show overlaps, dead space, or hierarchy.

## Step 2 — Mechanical checks (pass/fail, no opinion)
| # | Check | Source | Pass |
|---|---|---|---|
| M1 | Smallest text | audit.js | ≥ `minFontPx` from config (default 12px; SVG text and RTL text too) |
| M2 | Text contrast | audit.js | ≥ 4.5:1 (≥ 3:1 large) in **every** theme the app has |
| M3 | Style rule (only if `RULES.md`/config says flat) | audit.js | 0 gradients, 0 rgba fills/borders, 0 shadows |
| M4 | No horizontal scroll at mobile width | audit.js | false |
| M5 | Page errors / failed requests | audit.js | 0 |
| M6 | Tap targets | audit.js | none < `minTapPx` (default 24px; prefer 44px on mobile) |
| M7 | Basic a11y | audit.js | lang set, title set, 1 h1, no unlabeled inputs/buttons/imgs |
| M8 | Chart palette | `node tools/validate_palette.mjs "<hex,hex,..>" --mode dark --surface "<your chart surface hex>"` (and `--mode light ...`) using the SVG colours audit.js prints | all 5 checks PASS; CVD ΔE 6–8 only with direct labels/icons |
| M9 | SVG label collisions | `node tools/check-labels.js <svg-page.html>` | no overlaps / overflow |
| M10 | RTL/Persian/Arabic (only if the app has it) | audit.js RTL row + `profiles/example-synek/persian-rtl.md` | 0 letter-spacing, 0 `·`, 0 under min font |
| M11 | Placeholders | audit.js | dashes / "0/0" / "Not tracked" cells counted and justified |

## Step 3 — Judgement checks (say what you SAW)
Use `references/dataviz/anti-patterns.md`, `references/frontend-design/SKILL.md` and `RULES.md`.
- **Hierarchy:** is there one thing the page is *for*? Is it the largest/first thing? (Count equal-weight cards.)
- **Density:** first-viewport numbers; empty/stretched cards; no-data states that take a whole card.
- **Chart form:** right form for the question (form before colour)? table twin? tooltip + keyboard parity? thick saturated blocks? gradient funnels? single-bar histograms?
- **Colour meaning** (per `RULES.md`): is a meaning-colour (red/green/amber) used decoratively or for a neutral value (e.g. green on "0.00%")? Does every colour mean one thing?
- **Build-process language in UI:** "Phase A/B", "needs decision #…", "single-stage at startup" → delete.
- **Repeated identical rows** (e.g. 11 of 12 the same) → group.
- **Text breaking mid-word**, mixed time formats, negative zero (`−$0`), ambiguous arrows.
- **RTL (if present):** per-element `dir`, Latin IDs inside RTL text (bidi), `≥/≤` mirroring.

## Step 4 — Write it
Use `AUDIT-TEMPLATE.md`. Sort findings by impact: (1) wrong/misleading data or colour meaning, (2) can't read/operate, (3) structure/hierarchy, (4) polish. Each finding: **evidence** (number/screenshot region) + **fix** + **risk of the fix**.

## Step 5 — Be honest about limits
List what you did NOT verify (real data, other browsers, touch, screen readers, interactions). Do not claim "tested" for anything you only read in code.
Don't soften an unpleasant finding or hide it in paragraph three. If told you are wrong, change your position only for new evidence.
