# Iron rules (for anyone — human or agent — who edits Audit-kit itself)

These are not about auditing your app (that is `RULES.md`). They are about changing the kit. They are non-negotiable.

## 1. Versioning: +0.01 per committed edit
- The version starts at **1.00** (file `VERSION`). **Every committed edit to anything under `Audit-kit/` adds 0.01**: 1.00 → 1.01 → 1.02 … 1.99 → 2.00.
- One commit = one bump, however many files it touches. Never skip, never bump twice in one commit, never lower it.
- Each bump writes a `CHANGELOG.md` entry (date + a plain note of what changed), and updates the version shown in `README.md`, `docs/README.md` and the landing page `docs/index.html`.
- How: `node tools/bump-version.js --note "what changed"` (before committing, then `git add` the bumped files). The git hook `hooks/pre-commit` is the safety net: it bumps automatically with an auto-note if you forgot, and refuses a commit whose VERSION is not exactly +0.01. Install the hook once per clone: `sh tools/install-hooks.sh`.
- Check consistency any time: `node tools/bump-version.js --check` (also run by `tools/selftest.sh`). CI example: `docs/examples/version-check.yml`.
- Enforcement honesty: the hook is **local** (each clone must install it) and can be skipped with `--no-verify`; the CI example is what makes it binding on GitHub. Without installing either, this rule is only discipline.

## 2. Never commit a kit that fails its own self-test
`sh tools/selftest.sh` must end with `ALL OK` before every commit. A new tool or check ships with a fixture that makes it **fail** and one that makes it **pass**, wired into the selftest.

## 3. Docs, landing page and counts move with the code
A new or changed mode/tool/flag updates, in the same commit: `modes/*.json`, `MODES.md` (regenerate with `node tools/kit.js index`), `docs/modes.md`, `docs/tools.md`, `docs/configuration.md` if config changed, `docs/evidence.md`, and the landing page (`docs/index.html`) including counts ("N modes"). A number that appears in two places must agree.

## 4. Claims are evidence-backed and tagged
Every statement about behaviour comes from a run, with a tag: `[certain]` (measured/seen), `[likely]`, `[guess]`. What was **not** verified is written down (`docs/evidence.md`, test NOTES). "Tested by a fresh agent" means a new agent given only the one-line prompt and an isolated copy of the kit; anything else is "run through the tools".

## 5. Audit modes are read-only; build modes never overwrite the original
Audit modes change nothing in the target. Build/redesign modes write a **separate** new file. Brand colours, logos and data are never changed unless the owner says so; data is never invented.

## 6. Keep it app-agnostic and self-contained
No app names, tokens or paths hard-coded in tools or defaults (examples and `profiles/example-*` may). Dependencies stay: Node + Playwright. Third-party text keeps its licence file and a `SOURCE.md`; no binaries/fonts/images are copied in from skills.

## 7. Be honest in the report
Worst finding first. No "it works" without the command that proved it. A false positive or a blind spot found while testing is fixed or documented in `docs/limits-and-faq.md`, never hidden.
